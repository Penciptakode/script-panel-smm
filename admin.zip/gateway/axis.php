<?php
/* 
Script Topup Otomatis Via Pulsa TSEL
Creator : Salman El Faris
Editor : Muhammad Fahturrozi
 */
require_once "config.php";
require_once "EnvayaSMS.php";
require_once "../mainconfig.php";
$request = EnvayaSMS::get_request();
header("Content-Type: {$request->get_response_type()}");
if (!$request->is_validated($PASSWORD))
{
    header("HTTP/1.1 403 Forbidden");
    error_log("Invalid password");    
    echo $request->render_error_response("Invalid password");
    return;
}
$action = $request->get_action();
switch ($action->type)
{
    case EnvayaSMS::ACTION_INCOMING:    
        
        // Send an auto-reply for each incoming message.
    
        $type = strtoupper($action->message_type);
        $isi_pesan = $action->message;
     if($action->from == '168' AND preg_match("/Anda menerima Pulsa dari/i", $isi_pesan)) {
         $pesan_isi = $action->message;
         $insert_order = $db->query("INSERT INTO pesan_axis (isi, status, date) VALUES ('$pesan_isi', 'UNREAD', '$date')");
         $check_history_topup = $db->query("SELECT * FROM deposit WHERE name = 'Transfer Pulsa' AND provider = 'Axis' AND status = 'Pending' AND date = '$date'");
         if (mysqli_num_rows($check_history_topup) == 0) {
                error_log("History TopUp Not Found .");
         } else {          
             while($data_history_topup = mysqli_fetch_assoc($check_history_topup)) {
                        $id_history = $data_history_topup['code'];
                        $no_pegirim = $data_history_topup['nomor_pengirim'];
                        $username_user = $data_history_topup['username'];
                        $amount = $data_history_topup['saldo'];
                        $date_transfer = $data_history_topup['date'];
                        $date_type = $data_history_topup['place_from'];
                        $jumlah_transfer = $data_history_topup['jumlah'];
                        $cekpesan = preg_match("/Anda menerima Pulsa dari Rp $jumlah_transfer dari nomor $no_pegirim tgl $date_transfer/i", $isi_pesan);
                        if($cekpesan == true) {
                            if($date_type == 'WEB') {
                        $check_top = mysqli_query($db, "SELECT * FROM top_depo WHERE username = '$username_user'");
                        $data_top = mysqli_fetch_assoc($check_top);                                   
                            $update_history_topup = mysqli_query($db, "INSERT INTO balance_history (id, username, action, quantity, msg, date, time) VALUES ('', '$username_user', 'Add Balance', '$amount', 'Mendapatkan Saldo Melalui Deposit Otomatis VIA AXIS/XL TRANSFER Dengan ID Deposit : $id_history', '$date_transfer', '$time')");                            
                            $update_history_topup = $db->query("UPDATE deposit SET status = 'Success' WHERE code = '$id_history'");
                            $update_history_topup = $db->query("UPDATE users SET balance = balance+$amount WHERE username = '$username_user'");
                            }
                            if($update_history_topup == TRUE) {
                    if (mysqli_num_rows($check_top) == 0) {
                        $insert_topup = mysqli_query($db, "INSERT INTO top_depo (method, username, jumlah, total) VALUES ('Deposit', '$username_user', '$amount', '1')");
                    } else {
                        $insert_topup = mysqli_query($db, "UPDATE top_depo SET jumlah = ".$data_top['jumlah']."+$amount, total = ".$data_top['total']."+1 WHERE username = '$username_user' AND method = 'Deposit'");
                    }   
                            if($update_history_topup == TRUE) {
                                error_log("Saldo $username_user Telah Ditambahkan Sebesar $amount");
                            } else {    
                                error_log("System Error");
                            }
                        }
                        } else {
                            error_log("Data Transfer Pulsa Tidak Ada");
                        }
                }
         }
     } else {
        error_log("Received $type from {$action->from}");
        error_log(" message: {$action->message}");
     }                     
        
        return;
}