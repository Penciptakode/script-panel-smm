<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	include("../lib/header.php");
	$msg_type = "nothing";

	if (isset($_POST['order'])) {
		$post_service = $db->real_escape_string(trim(filter($_POST['service'])));
		$post_target = $db->real_escape_string(trim(filter($_POST['target'])));


		$check_service = mysqli_query($db, "SELECT * FROM services_pulsa WHERE sid = '$post_service' AND status = 'Active'");
		$data_service = mysqli_fetch_assoc($check_service);
    
        $check_orders = mysqli_query($db, "SELECT * FROM orders_pulsa WHERE data = '$post_target' AND status IN ('Pending','Processing')");
        $data_orders = mysqli_fetch_assoc($check_orders);		

		$price = $data_service['price'];
		$oid = random_number(3).random_number(4);
		$service = $data_service['service'];
        $provider = $data_service['provider'];
        $sid = $data_service['sid'];
        $pid = $data_service['pid'];
        $category = $data_service['category'];
        $check_provider = mysqli_query($db, "SELECT * FROM provider WHERE code = '$provider'");
        $data_provider = mysqli_fetch_assoc($check_provider);
        
		if (empty($post_service) || empty($post_target)) {
	    	$msg_type = "error";
		    $msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
		} else if (mysqli_num_rows($check_provider) == 0) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Server Sedang Mengalami Gangguan.<script>swal("Gagal!", "Server Sedang Mengalami Gangguan.", "error");</script>';
		} else if (mysqli_num_rows($check_service) == 0) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Layanan Tidak Tersedia.<script>swal("Gagal!", "Layanan Tidak Tersedia.", "error");</script>';
		} else if (mysqli_num_rows($check_orders) == 3) {
		    $msg_type = "error";
		    $msg_content = '<b>Gagal:</b> Terdapat Pesanan Dengan No.HP Yang Sama & Berstatus Pending.<script>swal("Gagal!", "Terdapat Pesanan Dengan No.HP Yang Sama & Berstatus Pending.", "error");</script>';		
		} else if ($data_user['balance'] < $price) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Saldo Anda Tidak Mencukupi Untuk Melakukan Pesanan Ini.<script>swal("Gagal!", "Saldo Anda Tidak Mencukupi Untuk Melakukan Pesanan Ini.", "error");</script>';
		} else {

			// api data
			$api_link = $data_provider['link'];
			$api_key = $data_provider['api_key'];
			// end api data
			
    	    
		    $poid = random_number(7);
		    
			if ($provider == "MANUAL") {
				$api_postdata = "";				
				$poid = $oid; 
			} else if ($provider == "DP-PULSA") {
				$postdata = "api_key=$api_key&service=$pid&phone=$post_target";
				$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, "https://serverh2h.com/order/pulsa");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$chresult = curl_exec($ch);
			$chresult;
			curl_close($ch);
			$json_result = json_decode($chresult, true);	
				$poid = $json_result['code_trx'];		
			} else {
				die("System Error!");
			}

				if ($json_result['error'] == true) {
				$msg_type = "error";
				$msg_content = $json_result['error']."<b> (1).";
			} else {
			    $check_top = mysqli_query($db, "SELECT * FROM top_users WHERE username = '$sess_username'");
			    $data_top = mysqli_fetch_assoc($check_top);
				$update_user = mysqli_query($db, "UPDATE users SET balance = balance-$price WHERE username = '$sess_username'");
				if ($update_user == TRUE) {
				    $insert_order = mysqli_query($db, "INSERT INTO balance_history (id, username, action, quantity, msg, date, time) VALUES ('', '$sess_username', 'Cut Balance', '$price', 'Pemesanan Pulsa Dengan ID Pesanan : $oid', '$date', '$time')");
					$insert_order = mysqli_query($db, "INSERT INTO orders_pulsa (oid, poid, user, service, data, price, status, date, place_from, provider) VALUES ('$oid', '$poid', '$sess_username', '$service', '$post_target', '$price', 'Pending', '$date', 'WEB', '$provider')");
					if ($insert_order == TRUE) {
    					if (mysqli_num_rows($check_top) == 0) {
    				        $insert_topup = mysqli_query($db, "INSERT INTO top_users (method, username, jumlah, total) VALUES ('Order', '$sess_username', '$price', '1')");
    				    } else {
    				        $insert_topup = mysqli_query($db, "UPDATE top_users SET jumlah = ".$data_top['jumlah']."+$price, total = ".$data_top['total']."+1 WHERE username = '$sess_username' AND method = 'Order'");
    				    }
    						$msg_type = "success";
    						$msg_content = "<b>Berhasil:</b> Pesanan Anda Telah Diterima.</b><br /><b>ID Pesanan:</b> $oid<br /><b>Nama Layanan:</b> $service<br /><b>Tujuan/Target:</b> $post_target<br /><b>Harga:</b> Rp ".number_format($price,0,',','.');
					} else {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> System Error.";
				    }
    			} else {
    				$msg_type = 'error';
    				$msg_content = "<b>Gagal</b> System Error.";
    			}
		    }
        }
    }
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
?>
                    <div class="col-md-12">
                        <br/>
                    </div>
<div class="row">
<div class="col-lg-12">
<div class="alert alert-success">
<h4 class="text-uppercase">
<i class="mdi mdi-bullhorn"></i> <b class="text-uppercase">Penting!</b></h3>
Halo <?php echo $sess_username; ?>, Sebelum Membuat Pesanan Disarankan Untuk Membaca <b>Informasi</b> Terlebih Dahulu, Jika Anda Masuk Menggunakan PC Maka <b>Informasi</b> Terletak Disebelah Kanan Form Pesanan, Jika Anda Masuk Menggunakan <i>Smartphone / Mobile Phone</i> Maka <b>Informasi</b> Terletak Dibagian Bawah Form Pesanan.
<br/>
Terima Kasih.
</div>
</div>
</div>
						<div class="row">
							<div class="col-md-7">
								<div class="card">
									<div class="card-header">
										<h4 class="header-title"><i class="mdi mdi-cart text-primary"></i> Pemesanan Baru</h4>
									</div>
									<div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
												<label class="col-md-2 control-label">Type</label>
												<div class="col-md-10">
												<select class="form-control" id="type" name="type">
													<option value="0">Pilih Salah Satu</option>
											<option value="EMONEY">Saldo E-Money</option>
													</select>
												</div>
											</div>	
											<div class="form-group">
												<label class="col-md-2 control-label">Kategori</label>
												<div class="col-md-10">
													<select class="form-control" id="category" name="category">
														<option value="0">Pilih Type Dahulu</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Layanan</label>
												<div class="col-md-10">
													<select class="form-control" id="service" name="service">
														<option value="0">Pilih Kategori Dahulu</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Tujuan</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="mdi mdi-cellphone-android mr-1 text-primary"></i>
                                                    </div>
                                                </div>
													<input type="text" name="target" class="form-control" placeholder="No HP /  ID Game / No Meter">
												</div>
											</div>
										</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Total Harga</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text text-primary">
                                                            Rp
                                                    </div>
                                                </div>
													<input type="text" class="form-control" id="price" value="0" readonly>
    												</div>
    											</div>
    										</div>
    										<div class="form-group">
    										<div class="col-md-10">
											<button type="reset" class="btn btn-danger waves-effect w-md waves-light">Ulangi</button>
											<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="order">Buat Pesanan</button>
											    </div>
											</div>    
										</form>
									</div>
								</div>
							</div>
                            <div class="col-md-5">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-information-outline text-primary"></i> Peraturan Pemesanan</h4>
                                    </div>
                                    <div class="card-body">
										<ul>
											<li>Pesan Pulsa/Kuota/Voucher Game. Masukkan Nomor Telepon Dengan Benar, Contoh 082136611003.</li>
											<li>Pesan Token PLN Masukkan Nomor Meter.</li>
											<li>Harap Masukan Target Dengan Benar, Tidak Ada Pengembalian Dana Untuk Kesalahan Pengguna Yang Pesanannya Sudah Terlajur Di Pesan.</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
						<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript">
$(document).ready(function() {
	$("#type").change(function() {
		var type = $("#type").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/tipe_salgo.php',
			data: 'type=' + type,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#category").html(msg);
			}
		});
	});
	$("#category").change(function() {
		var category = $("#category").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/order_service_pulsa.php',
			data: 'category=' + category,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#service").html(msg);
			}
		});
	});
	$("#service").change(function() {
		var service = $("#service").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/order_pulsa.php',
			data: 'service=' + service,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#price").val(msg);
			}
		});
	});
});
function get_total(quantity) {
	var rate = $("#rate").val();
	var result = eval(quantity) * rate;
	$('#total').val(result);
}
	</script>
<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$cfg_baseurl);
}
?>