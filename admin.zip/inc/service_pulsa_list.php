<?php
require("../mainconfig.php");

if (isset($_POST['category'])) {
	$post_cate = mysqli_real_escape_string($db, $_POST['category']);
	$check_service = mysqli_query($db, "SELECT * FROM services_pulsa WHERE category = '$post_cate' ORDER BY service ASC");
	if (mysqli_num_rows($check_service) != 0) {
	?>

                            <div class="table-responsive">
                                <table id="datatable-responsive" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
														<th>ID</th>
														<th>Operator</th>
														<th>Nama Layanan</th>
														<th>Harga</th>
														<th>Status</th>
													</tr>
												</thead>
												<tbody>
												    <?php
	                                                while ($data_service = mysqli_fetch_assoc($check_service)) {
													if($data_service['status'] == "Active") {
														$label = "success";
													} else if($data_service['status'] == "Not Active") {
														$label = "danger";
													}
	                                                ?>
	                                                <tr>
														<th scope="row"><?php echo $data_service['sid']; ?></th>
														<td><?php echo $data_service['category']; ?></td>					
														<td><?php echo $data_service['service']; ?></td>
														<td>Rp <?php echo number_format($data_service['price'],0,',','.'); ?></td>
														<td><label class="btn btn-xs btn-<?php echo $label; ?>"><?php echo $data_service['status']; ?></label></td>
													</tr>
												<?php
												} 
												?>
												</tbody>
											</table>
										</div>
<?php
	} else {
?>
<div class="text-center">
<div class="alert alert-info">Layanan Belum Tersedia</div>
</div>
<?php
	}
}