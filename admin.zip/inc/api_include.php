<?php
require("../mainconfig.php");

if (isset($_POST['api'])) {
	$post_cate = mysqli_real_escape_string($db, $_POST['api']);
	
if($post_cate =="api_sosial"){
 include("api_data/sosial.php");
}else if($post_cate =="api_pulsa"){
 include("api_data/pulsa.php");    
}else if($post_cate =="api_lainnya"){
 include("api_data/lainnya.php");   
}else if($post_cate =="api_voucher"){
 include("api_data/voucher.php");   
}else if($post_cate =="api_informasi_akun"){
 include("api_data/akun.php");   
}
} else {
?>
<option value="0">Error.</option>
<?php
}