<?php
require_once ("../mainconfig.php");
$nominal = $db->real_escape_string($_POST['jumlah']);
$menghitung = $nominal + 100;
echo ceil($menghitung);
?>