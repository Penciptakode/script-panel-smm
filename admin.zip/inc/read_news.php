<?php
session_start();
require("../mainconfig.php"); 
require("../lib/header.php");

if (isset($_SESSION['user'])) {
    $sess_username = $_SESSION['user']['username'];
    $check_user = $db->query("SELECT * FROM users WHERE username = '".$_SESSION['user']['username']."'");
    $data_user = $check_user->fetch_assoc();
    $check_username = $check_user->num_rows;
    if ($check_username == 0) {
        header("Location: ".$cfg_baseurl."logout.php");
    } else if ($data_user['status'] == "Suspended") {
        header("Location: ".$cfg_baseurl."logout.php");
    }
	$sess_username = $_SESSION['user']['username'];
	
    $update_news = $db->query("UPDATE users SET read_news = '1' WHERE username = '$sess_username'");
    }