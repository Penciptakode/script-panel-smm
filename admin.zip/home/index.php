<?php 
include("../mainconfig.php");
?>

<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <title><?php echo $cfg_webname; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php echo $cfg_webname ?> Adalah Sebuah Platform Bisnis Yang Menyediakan Berbagai Layanan Multy Media Marketing Yang Bergerak Terutama Di Indonesia. Dengan Bergabung Bersama Kami, Anda Dapat Menjadi Penyedia Jasa Sosial Media Atau Reseller Sosial Media Seperti Jasa Penambah Followers, Likes, Views, Subscribe, Dll.
Saat Ini Tersedia Berbagai Layanan Untuk Sosial Media Terpopuler Seperti Instagram, Facebook, Twitter, Youtube, Dll. Dan Kamipun Juga Menyediakan Panel Pulsa & PPOB Seperti Pulsa All Operator, Paket Data, Saldo Gojek/Grab, Token PLN, All Voucher Game Online, Dll.">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="<?php echo $cfg_baseurl; ?>home/images/logonya.png">

        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" type="text/css" href="css/materialdesignicons.min.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link href="../../stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    </head>

    <body>
        
<?php         
//Total Pengguna
$check_wuser = $db->query("SELECT * FROM users");
$count_wuser = mysqli_num_rows($check_wuser);

//Total Pesanan Sosial Media
$check_wsosmed = mysqli_query($db, "SELECT * FROM orders WHERE status = 'Success'");
$count_worder_sosmed = mysqli_num_rows($check_wsosmed);

//Total Pesanan Pulsa PPOB
$check_wpulsa = mysqli_query($db, "SELECT * FROM orders_pulsa WHERE status = 'Success'");
$count_worder_pulsa = mysqli_num_rows($check_wpulsa);

//Total Pesanan Game
$check_wgame = mysqli_query($db, "SELECT * FROM orders_game WHERE status = 'Success'");
$count_worder_game = mysqli_num_rows($check_wgame);

//Total Pesanan Voucher
$check_wvoucher = mysqli_query($db, "SELECT * FROM orders_voucher WHERE status = 'Success'");
$count_worder_voucher = mysqli_num_rows($check_wvoucher);
?>

        <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
            <div class="container-fluid">
                <!-- LOGO -->
                <a class="logo text-uppercase" href="#">
                    <img src="<?php echo $cfg_baseurl; ?>home/images/logonya.png" alt="" class="logo-light" height="50" />
                    <img src="<?php echo $cfg_baseurl; ?>home/images/logonya.png" alt="" class="logo-dark" height="50" />
                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="mdi mdi-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mx-auto navbar-center" id="mySidenav">
                        <li class="nav-item active">
                            <a href="#home" class="nav-link">Beranda</a>
                        </li>
                        <li class="nav-item">
                            <a href="#features" class="nav-link">Tentang Kami</a>
                        </li>
                    </ul>
                    <a href="<?php echo $cfg_baseurl; ?>auth/masuk" class="btn btn-primary navbar-btn">Masuk</a>
                </div>
            </div>
        </nav>
        <!-- Navbar End -->

        <!-- home start -->
        <section class="bg-home bg-gradient" id="home">
            <div class="home-center">
                <div class="home-desc-center">
                    <div class="container-fluid">
                        <div class="home-title">
                            <center><h1 class="mb-4 text-white"><?php echo $cfg_webname ?></h1>
                            <p class="text-white-50 home-desc"><?php echo $cfg_webname ?> Adalah Sebuah Platform Bisnis Yang Menyediakan Berbagai Layanan Multi Media Marketing Yang Bergerak Terutama Di Indonesia.<br />Dengan Bergabung Bersama Kami, Anda Dapat Menjadi Penyedia Jasa Sosial Media Atau Reseller Sosial Media Seperti Jasa Penambah Followers, Likes, Views, Subscribe, Dll.<br />Saat Ini Tersedia Berbagai Layanan Untuk Sosial Media Terpopuler Seperti Instagram, Facebook, Twitter, Youtube, Dll. Dan Kamipun Juga Menyediakan Panel Pulsa & PPOB Seperti Pulsa All Operator, Paket Data, Saldo Gojek/Grab, Token PLN, All Voucher Game Online, Dll.</p></center>
                            <div class="col-lg-12 text-center" style="margin: 30px 0 30px 0;">
                            <a href="<?php echo $cfg_baseurl ?>auth/masuk" class="btn btn-primary waves-effect waves-light"><i class="mdi mdi-login"></i> Masuk</a> 
                            <a href="<?php echo $cfg_baseurl ?>auth/daftar" class="btn btn-primary"><i class="mdi mdi-account-plus"></i> Daftar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- home end -->

        <!-- clients start -->
        <section>
            <div class="container-fluid">
                <div class="clients p-4 bg-white">
                    <div class="row text-center">
                        <div class="col-md-4">
                            <h2>163+</h2>
                            <p class="text-muted">Total Pengguna Aktif</p>
                        </div>
                        <div class="col-md-4">
                            <h2>1895+</h2>
                            <p class="text-muted">Total Pesanan Sosial Media</p>
                        </div>
                        <div class="col-md-4">
                            <h2>583+</h2>
                            <p class="text-muted">Total Pesanan Pulsa PPOB</p>
                        </div>
                    </div>
                </div>
            </div> <!-- end container-fluid -->
        </section>
        <!-- clients end -->

        <!-- features start -->
        <section class="section-sm" id="features">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-4">
                        <div class="features-box">
                            <div class="features-img mb-4">
                                <h1><i class="mdi mdi-thumb-up-outline fa fa-2x"></i></h1>
                            </div>
                            <h4 class="mb-2">Layanan Terbaik</h4>
                            <p class="text-muted">Kami Menyediakan Berbagai Layanan Terbaik Untuk Kebutuhan Sosial Media & Pulsa PPOB Untuk Anda.</p>
                        </div>
                    </div>
                    <!-- end col -->
                    <div class="col-lg-4">
                        <div class="features-box">
                            <div class="features-img mb-4">
                                <h1><i class="mdi mdi-lifebuoy fa fa-2x"></i></h1>
                            </div>
                            <h4 class="mb-2">Pelayanan Bantuan</h4>
                            <p class="text-muted">Kami Selalu Siap Membantu Jika Anda Membutuhkan Kami Dalam Penggunaan Layanan Kami.</p>
                        </div>
                    </div>
                    <!-- end col -->
                    <div class="col-lg-4">
                        <div class="features-box">
                            <div class="features-img mb-4">
                                <h1><i class="mdi mdi-desktop-mac fa fa-2x"></i></h1>
                            </div>
                            <h4 class="mb-2">Desain Web Responsive</h4>
                            <p class="text-muted">Kami Menggunakan Desain Website Yang Dapat Diakses Dari Berbagai <i>Device</i>, Daik Smartphone Android Maupun Deskop.</p>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->

                <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="features-box">
                            <div class="features-img mb-4">
                                <h1><i class="mdi mdi-flash fa fa-2x"></i></h1>
                            </div>
                            <h4 class="mb-3">API Pengguna</h4>
                            <p class="text-muted">Tersedia API Beserta Dokumentasinya Untuk Reseller Anda.</p>
                        </div>
                    </div>
                    <!-- end col -->
                    <div class="col-lg-4">
                        <div class="features-box">
                            <div class="features-img mb-4">
                                <h1><i class="mdi mdi-cart-outline fa fa-2x"></i></h1>
                            </div>
                            <h4 class="mb-3">Proses Pesanan</h4>
                            <p class="text-muted">Integrasi API Dari Penyedia Manapun Untuk Pemrosesan Pesanan Otomatis Atau Kelola Pesanan Secara Manual.</p>
                        </div>
                    </div>
                    <!-- end col -->
                    <div class="col-lg-4">
                        <div class="features-box">
                            <div class="features-img mb-4">
                                <h1><i class="mdi mdi-tune fa fa-2x"></i></h1>
                            </div>
                            <h4 class="mb-3">Kemudahan Penggunaan</h4>
                            <p class="text-muted">Kami Menyediakan Fitur Yang Mudah Di Mengerti Oleh Para Pengguna.</p>
                        </div>
                    </div>
                    <!-- end col -->
                </div> <!-- end row -->
            </div> <!-- end container-fluid -->
        </section>

        <footer class="bg-dark footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="float-center pull-center">
                            <p class="text-white-50">Copyright © 2020<b> <a class="text-white-50"><?php echo $cfg_webname ?></b> All Rights Reserved</a></b> </p>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- container-fluid -->
        </footer>
        <!-- footer end -->
        
        <!-- javascript -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery.easing.min.js"></script>
        <script src="js/scrollspy.min.js"></script>

        <!-- custom js -->
        <script src="js/app.js"></script>
    </body>