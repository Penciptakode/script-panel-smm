<?php
require("mainconfig.php");
 
$ip_dpedia = "172.105.239.47";
 
if( $_SERVER['REMOTE_ADDR'] == $ip_dpedia ){
   
    $data_masuk = $_POST['content'];
    $json = json_decode($data_masuk,TRUE);
    file_put_contents('callback_bagus.txt', $_POST['content']); // menyimpan dalam file txt
 
    $oid       = $json['oid'];
    $service    = $json['service'];
    $price      = $json['price'];
    $status     = $json['status'];
    $date       = $json['date'];
    $catatan    = $json['catatan'];
   
    $sql             = "UPDATE orders_pulsa SET sn = '$catatan' , status = '$status' WHERE poid = '$oid' AND provider = 'DP-PULSA'";
   
    $ok   = mysqli_query($db,$sql);
   
    if ( $ok == TRUE){
        echo json_encode([
            "status"    => "ok"
            ]);
           
    }else{
        echo json_encode([
            "status"    => "fail"
            ]);
    }
}