<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = $db->query("SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = $check_user->fetch_assoc();
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	include("../lib/header.php");
	$msg_type = "nothing";
	$ip = $_SERVER['REMOTE_ADDR'];

	if (isset($_POST['ganti_password'])) {
		$post_password = $db->real_escape_string(trim(filter($_POST['password'])));
		$post_npassword = $db->real_escape_string(trim(filter($_POST['npassword'])));
		$post_cnpassword = $db->real_escape_string(trim(filter($_POST['cnpassword'])));
		
		$verif_pass = password_verify($post_password, $data_user['password']);
		$hash_pass = password_hash($post_npassword,PASSWORD_DEFAULT);
		
		if (empty($post_password) || empty($post_npassword) || empty($post_cnpassword)) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
		} else if ($verif_pass <> $data_user['password']) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Kata Sandi Lama Salah.<script>swal("Gagal!", "Kata Sandi Lama Salah.", "error");</script>';
		} else if (strlen($post_npassword) < 5) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Kata Sandi Baru Telalu Pendek, Minimal 5 Karakter.<script>swal("Gagal!", "Kata Sandi Baru Telalu Pendek, Minimal 5 Karakter.", "error");</script>';
		} else if ($post_cnpassword <> $post_npassword) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Konfirmasi Kata Sandi Baru Tidak Sesuai.<script>swal("Gagal!", "Konfirmasi Kata Sandi Baru Tidak Sesuai.", "error");</script>';
		} else {
			$update_user = $db->query("UPDATE users SET password = '$hash_pass' WHERE username = '$sess_username'");
			$update_user = $db->query("INSERT INTO log (username, catatan, waktu) VALUES ('$sess_username', 'Anda Telah Melakukan Aktifitas Ganti Kata Sandi Dengan IP : $ip', '$date $time')");
			if ($update_user == TRUE) {
				$msg_type = "success";
				$msg_content = '<b>Berhasil:</b> Kata Sandi Berhasil Diubah.<script>swal("Berhasil!", "Kata Sandi Berhasil Diubah.", "success");</script>';
			} else {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> System Error.";
			}
		}
	} else if (isset($_POST['ganti_data'])) {
		$post_nama = $db->real_escape_string(trim(filter($_POST['nama'])));
		$post_email = $db->real_escape_string(trim(filter($_POST['email'])));
		$post_no_hp = $db->real_escape_string(trim(filter($_POST['no_hp'])));
		$post_password = $db->real_escape_string(trim(filter($_POST['password'])));
		
		$verif_pass = password_verify($post_password, $data_user['password']);
		
		if (empty($post_nama) || empty($post_email) || empty($post_no_hp) || empty($post_password)) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
		} else if ($verif_pass <> $data_user['password']) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Kata Sandi Salah.<script>swal("Gagal!", "Kata Sandi Salah.", "error");</script>';
		} else {
			$update_user = $db->query("UPDATE users SET nama = '$post_nama', email = '$post_email', no_hp = '$post_no_hp' WHERE username = '$sess_username'");
			$update_user = $db->query("INSERT INTO log (username, catatan, waktu) VALUES ('$sess_username', 'Anda Telah Melakukan Aktifitas Ubah Akun Dengan IP : $ip', '$date $time')");
			if ($update_user == TRUE) {
				$msg_type = "success";
				$msg_content = '<b>Berhasil:</b> Akun Berhasil Diubah.<script>swal("Berhasil!", "Akun Berhasil Diubah.", "success");</script>';
			} else {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> System Error.";
			}
		}
	} else if (isset($_POST['ganti_key'])) {
		$set_api_key = random(20);
		$update_user = $db->query("UPDATE users SET api_key = '$set_api_key' WHERE username = '$sess_username'");
		$update_user = $db->query("INSERT INTO log (username, catatan, waktu) VALUES ('$sess_username', 'Anda Telah Melakukan Aktifitas Ganti API Key Dengan IP : $ip', '$date $time')");
		if ($update_user == TRUE) {
			$msg_type = "success";
			$msg_content = '<b>Berhasil:</b> API Key Berhasil Diubah.<script>swal("Berhasil!", "API Key Berhasil Diubah.", "success");</script>';
		} else {
			$msg_type = "error";
			$msg_content = "<b>Gagal:</b> System Error.";
		}
	}
	
	$check_user = $db->query("SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
								<center><img src="<?php echo $cfg_baseurl ?>assets/images/businessman.svg" width="150px" alt="user-img" class="rounded-circle user-img"></img></center>    
                                    <center><h4 class="card-title text-center"><?php echo $data_user['username']; ?></h4></center>
                                            <p class="card-text"><b>Nama</b> : <?php echo $data_user['nama']; ?></p>
                                            <p class="card-text"><b>E-Mail</b> : <?php echo $data_user['email']; ?></p>
                                            <p class="card-text"><b>Nomor HP</b> : <?php echo $data_user['no_hp']; ?></p>
                                            <p class="card-text"><b>Sisa Saldo</b> : <?php echo number_format($data_user['balance'],0,',','.'); ?></p>
                                            <p class="card-text"><b>Level</b> : <span class="btn btn-rounded btn-primary"><?php echo $data_user['level']; ?></span></p>
                                            <p class="card-text"><b>Terdaftar Sejak</b> : <?php echo TanggalIndonesia($data_user['registered']); ?></p>
                                        </div>
                                    </div>
                                </div>
                        <div class="col-sm-12 col-lg-8">
                            <div class="card-box">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item">
                                        <a href="#password" data-toggle="tab" aria-expanded="false" class="nav-link active">
                                        <span class="d-block d-sm-none"><i class="mdi mdi-account-key text-primary"></i></span>
                                        <span class="d-none d-sm-block">Kata Sandi</span>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#name" data-toggle="tab" aria-expanded="false" class="nav-link">
                                        <span class="d-block d-sm-none"><i class="mdi mdi-account-card-details text-primary"></i></span>
                                        <span class="d-none d-sm-block">Data Akun</span>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#home" data-toggle="tab" aria-expanded="false" class="nav-link">
                                        <span class="d-block d-sm-none"><i class="fa fa-code text-primary"></i></span>
                                        <span class="d-none d-sm-block">Api Key</span>
                                        </a>
                                    </li>
                                </ul>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade active show" id="password">
                                <p class="mb-0">
                                <form class="form-horizontal" method="POST">
                                	<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Kata Sandi Lama</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="fa fa-lock text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="password" name="password" class="form-control" placeholder="Kata Sandi Lama">
                                        </div>
                                    </div>
                                </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Kata Sandi Baru</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="fa fa-lock text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="password" name="npassword" class="form-control" placeholder="Kata Sandi Baru">
                                        </div>
                                    </div>
                                </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Konfirmasi Kata Sandi Baru</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="fa fa-lock text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="password" name="cnpassword" class="form-control" placeholder="Konfirmasi Kata Sandi Baru">
                                        </div>
                                    </div>
                                </div>
                                    <div class="text-center">
                                            <button type="submit" name="ganti_password" class="btn btn-primary waves-effect w-md waves-light">Ganti Kata Sandi</button>
                                        </div>
                                    </form>
                                </p>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="name">
                                <p class="mb-0">
                                <form class="form-horizontal" method="POST">
                                	<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Nama</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="mdi mdi-account-card-details text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" value="<?php echo $data_user['nama']; ?>">
                                        </div>
                                    </div>
                                </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">E-Mail</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="fa fa-envelope text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="email" name="email" class="form-control" placeholder="E-Mail Aktif" value="<?php echo $data_user['email']; ?>">
                                        </div>
                                    </div>
                                </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Nomor HP</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="fa fa-phone text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="number" name="no_hp" class="form-control" placeholder="62" value="<?php echo $data_user['no_hp']; ?>">
                                        </div>
                                            <small class="text-danger">*Masukan Nomor HP Wajib Diawali Dengan 62</span></small>
                                    </div>
                                </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Kata Sandi</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="fa fa-lock text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="password" name="password" class="form-control" placeholder="Kata Sandi Anda">
                                        </div>
                                            <small class="text-danger">*Masukan Kata Sandi Anda Untuk Update Data Akun</span></small>
                                    </div>
                                </div>
                                    <div class="text-center">
                                            <button type="submit" name="ganti_data" class="btn btn-primary waves-effect w-md waves-light">Update</button>
                                        </div>
                                    </form>
                                </p>
                            </div>
                                <div role="tabpanel" class="tab-pane fade" id="home">
                                    <p class="mb-0">
                                	<form class="form-horizontal" method="POST">
                                	<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Api Key Anda</label>
                                        <div class="col-md-12">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                <i class="fa fa-code text-primary"></i>
                                            </div>
                                        </div>
                                            <input type="text" class="form-control" name="api" value="<?php echo $data_user['api_key']; ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                                    <div class="text-center">
                                            <button type="submit" name="ganti_key" class="btn btn-primary waves-effect w-md waves-light">Update</button>
                                        </div>
                                    </form>
                                </p>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$cfg_baseurl);
}
?>