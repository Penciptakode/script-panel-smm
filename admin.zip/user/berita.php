<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	include("../lib/header.php");
	$msg_type = "nothing";

	
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-newspaper text-primary"></i> Berita Terkini</h4>
                                    </div>
                                    <div class="card-body">

<?php
// start paging config
$check_news = $db->query("SELECT * FROM news ORDER BY id DESC LIMIT 10"); // edit
// end paging config
while ($data_news = mysqli_fetch_assoc($check_news)) {
$newsstr = "-".strlen($data_news['content']);
$newssensor = substr($data_news['content'],$slider_userstr,+100);	
if($data_news['type'] == "INFORMASI") {
$alert = "primary";
} else if($data_news['type'] == "PERINGATAN") {
$alert = "danger";
} else if($data_news['type'] == "EVENT") {
$alert = "warning";
} else if($data_news['type'] == "LAYANAN") {
$alert = "success";
}                                                        
?>
                            <div class="inbox-widget">
                                <div class="inbox-item">
                                <div class="inbox-item-img"><img src="<?php echo $cfg_baseurl ?>assets/images/news.png" class="rounded-circle" alt=""></div>
                                <h5 class="inbox-item-author mt-0 mb-1"><?php echo $data_news['title']; ?></h5>
                                <div><p class="inbox-item-text"><span class="badge badge-<?php echo $alert; ?>"><?php echo $data_news['type']; ?></span><br />
                                <br />
                                <?php echo nl2br ($newssensor."....."); ?><br/><br><a href="<?php echo $cfg_baseurl ?>user/news.php?id=<?php echo $data_news['id']; ?>" class="btn btn-rounded btn-primary">Selengkapnya</a></p>
                                </div>
                                </div>
                                <div class="text-right">
                                <div class="date" style="font-size:12px">
                                <p class="inbox-item-date"><?php echo TanggalIndonesia($data_news['date']); ?>, <?php echo $data_news['time']; ?></p>
                                </div>
                                <hr/>
                            </div>
                        </div>
<?php
}
?>
                                        </div>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->

<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$cfg_baseurl);
}
?>