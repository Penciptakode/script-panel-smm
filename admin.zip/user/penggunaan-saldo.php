<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	include("../lib/header.php");
	$msg_type = "nothing";

	
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);

    $total_usesaldo = mysqli_query($db, "SELECT SUM(quantity) AS total FROM balance_history WHERE username = '$sess_username' AND action = 'Cut Balance'");
    $total_us = mysqli_fetch_assoc($total_usesaldo);

    $total_insertsaldo = mysqli_query($db, "SELECT SUM(quantity) AS total FROM balance_history WHERE username = '$sess_username' AND action = 'Add Balance'");
    $total_is = mysqli_fetch_assoc($total_insertsaldo);

?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                    <div class="widget-rounded-circle card-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="avatar-lg rounded-circle bg-soft-primary border-primary border">
                                    <i class="ti-wallet font-22 avatar-title text-primary"></i>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-right">
                                <p class="text-success m-t-5 text-uppercase font-600 font-secondary">Total Pemakaian Saldo</p>
                                <h2 class="m-b-10"><span>Rp <?php echo number_format($total_us['total'],0,',','.'); ?> </span></h2>
                                <p class="text-success m-t-5 text-uppercase font-600 font-secondary">Total Penambahan Saldo</p>
                                <h2 class="m-b-10"><span>Rp <?php echo number_format($total_is['total'],0,',','.'); ?> </span></h2>                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-wallet text-primary"></i> Riwayat Penggunaan Saldo</h4>
                                    </div>
                                    <div class="card-body">
                                        <form method="GET">
                                            <input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
                                            <div class="row">
                                                <div class="form-group col-lg-4">
                                                    <label>Tampilkan Beberapa</label>
                                                    <select class="form-control" name="tampil">
                                                        <option value="10">Default</option>
                                                        <option value="20">10</option>
                                                        <option value="50">50</option>
                                                        <option value="100">100</option>
                                                    </select>
                                                </div>                                                
                                                <div class="form-group col-lg-4">
                                                    <label>Filter Tipe</label>
                                                    <select class="form-control" name="tipe">
                                                        <option value="">Semua</option>
                                                        <option value="Add Balance" >Penambahan Saldo</option>
                                                        <option value="Cut Balance" >Pengurangan Saldo</option>
                                                    </select>
                                                </div>                                                
                                                <div class="form-group col-lg-4">
                                                    <label>Submit</label>
                                                    <button type="submit" class="btn btn-block btn-primary">Filter</button>
                                                </div>
                                            </div>
                                        </form>
											<div class="table-responsive">
											<table id="datatable-responsive" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>	
													    <th>No</th>
														<th>Aksi</th>
														<th>Jumlah</th>									
														<th>Keterangan</th>
														<th>Tanggal & Waktu</th>

													</tr>
												</thead>
												<tbody>
<?php 
// start paging config
if (isset($_GET['tipe'])) {
    $cari_tipe = $db->real_escape_string(filter($_GET['tipe']));

    $cek_data = "SELECT * FROM balance_history WHERE action LIKE '%$cari_tipe%' AND username = '$sess_username' ORDER BY id DESC"; // edit
} else {
    $cek_data = "SELECT * FROM balance_history WHERE username = '$sess_username' ORDER BY id DESC"; // edit
}
if (isset($_GET['tipe'])) {
$cari_urut = $db->real_escape_string(filter($_GET['tampil']));
$records_per_page = $cari_urut; // edit
} else {
    $records_per_page = 10; // edit
}

$starting_position = 0;
if(isset($_GET["halaman"])) {
    $starting_position = ($db->real_escape_string(filter($_GET["halaman"]))-1) * $records_per_page;
}
$new_query = $cek_data." LIMIT $starting_position, $records_per_page";
$new_query = $db->query($new_query);
$no = $starting_position+1;
// end paging config
while ($view_data = $new_query->fetch_assoc()) {
    if ($view_data['action'] == "Add Balance") {
        $label = "success";
    } else if ($view_data['action'] == "Cut Balance") {
        $label = "danger";
    }
?>
                                    <tr>
                                        <th scope="row"><?php echo $no++ ?></th>
                                        <td><label class="btn btn-xs btn-<?php echo $label; ?>"><?php if($view_data['action'] == "Add Balance") { ?>Penambahan Saldo</i></span><?php } else { ?>Pengurangan Saldo</span><?php } ?></label></td>
                                        <td><?php echo $view_data['quantity']; ?></td>
                                        <td><?php echo $view_data['msg']; ?></td>
                                        <td><?php echo TanggalIndonesia($view_data['date']); ?>, <?php echo $view_data['time']; ?></td>
                                    </tr>   
<?php } ?>
                                    </tbody>
                                </table>
                            <br>
                                        <ul class="pagination">
<?php
// start paging link
if (isset($_GET['tipe'])) {
$cari_urut = $db->real_escape_string(filter($_GET['tampil']));
} else {
$cari_urut =  10;
}  
if (isset($_GET['tipe'])) {
    $cari_tipe = $db->real_escape_string(filter($_GET['tipe']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
    $self = $_SERVER['PHP_SELF'];
} else {
    $self = $_SERVER['PHP_SELF'];
}
$cek_data = $db->query($cek_data);
$total_records = mysqli_num_rows($cek_data);
echo "<li class='disabled page-item'><a class='page-link' href='#'>Total Data : ".$total_records."</a></li>";
if($total_records > 0) {
    $total_pages = ceil($total_records/$records_per_page);
    $current_page = 1;
    if(isset($_GET["halaman"])) {
        $current_page = $db->real_escape_string(filter($_GET["halaman"]));
        if ($current_page < 1) {
            $current_page = 1;
        }
    }
    if($current_page > 1) {
        $previous = $current_page-1;
    if (isset($_GET['tipe'])) {
    $cari_tipe = $db->real_escape_string(filter($_GET['tipe']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=1&tampil=".$cari_urut."&tipe=".$cari_tipe."'><<</a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$previous."&tampil=".$cari_urut."&tipe=".$cari_tipe."'><</a></li>";
} else {
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=1'><<</a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$previous."'><</a></li>";
}
}
    // limit page
    $limit_page = $current_page+3;
    $limit_show_link = $total_pages-$limit_page;
    if ($limit_show_link < 0) {
        $limit_show_link2 = $limit_show_link*2;
        $limit_link = $limit_show_link - $limit_show_link2;
        $limit_link = 3 - $limit_link;
    } else {
        $limit_link = 3;
    }
    $limit_page = $current_page+$limit_link;
    // end limit page
    // start page
    if ($current_page == 1) {
        $start_page = 1;
    } else if ($current_page > 1) {
        if ($current_page < 4) {
            $min_page  = $current_page-1;
        } else {
            $min_page  = 3;
        }
        $start_page = $current_page-$min_page;
    } else {
        $start_page = $current_page;
    }
    // end start page
    for($i=$start_page; $i<=$limit_page; $i++) {
    if (isset($_GET['tipe'])) {
    $cari_tipe = $db->real_escape_string(filter($_GET['tipe']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
        if($i==$current_page) {
            echo "<li class='active page-item'><a class='page-link' href='#'>".$i."</a></li>";
        } else {
            echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$i."&tampil=".$cari_urut."&tipe=".$cari_tipe."'>".$i."</a></li>";
        }
    } else {
        if($i==$current_page) {
            echo "<li class='active page-item'><a class='page-link' href='#'>".$i."</a></li>";
        } else {
            echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$i."'>".$i."</a></li>";
        }        
    }
    }
    if($current_page!=$total_pages) {
        $next = $current_page+1;
    if (isset($_GET['tipe'])) {
    $cari_tipe = $db->real_escape_string(filter($_GET['tipe']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$next."&tampil=".$cari_urut."&tipe=".$cari_tipe."'>></a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$total_pages."&tampil=".$cari_urut."&tipe=".$cari_tipe."'>>></a></li>";
} else {
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$next."'>></a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$total_pages."'>>></a></li>";
    }
}
}
// end paging link
?>
                                        </ul>
                                        
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$cfg_baseurl);
}
?>