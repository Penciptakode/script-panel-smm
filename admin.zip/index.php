<?php
session_start();
require("mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
    $sess_username = $_SESSION['user']['username'];
    $check_user = $db->query("SELECT * FROM users WHERE username = '$sess_username'");
    $data_user = $check_user->fetch_assoc();
    $check_username = $check_user->num_rows;
    if ($check_username == 0) {
        header("Location: ".$cfg_baseurl."logout.php");
    } else if ($data_user['status'] == "Suspended") {
        header("Location: ".$cfg_baseurl."logout.php");
    }

    //Ip Server
    $ip = $_SERVER['REMOTE_ADDR'];
    
    // Data Link Grub WhatsApp
    $link_grubwa = mysqli_query($db, "SELECT * FROM contact ORDER BY id DESC");
    $data_link = $link_grubwa->fetch_assoc();

    // Data Grafik Pesanan Sosial Media
    $check_order_today = $db->query("SELECT * FROM orders WHERE date ='($date)' and user = '$sess_username'");
    
    $oneday_ago = date('Y-m-d', strtotime("-1 day"));
    $check_order_oneday_ago = $db->query("SELECT * FROM orders WHERE date ='$oneday_ago' and user = '$sess_username'");
    
    $twodays_ago = date('Y-m-d', strtotime("-2 day"));
    $check_order_twodays_ago = $db->query("SELECT * FROM orders WHERE date ='$twodays_ago' and user = '$sess_username'");
    
    $threedays_ago = date('Y-m-d', strtotime("-3 day"));
    $check_order_threedays_ago = $db->query("SELECT * FROM orders WHERE date ='$threedays_ago' and user = '$sess_username'");
    
    $fourdays_ago = date('Y-m-d', strtotime("-4 day"));
    $check_order_fourdays_ago = $db->query("SELECT * FROM orders WHERE date ='$fourdays_ago' and user = '$sess_username'");
    
    $fivedays_ago = date('Y-m-d', strtotime("-5 day"));
    $check_order_fivedays_ago = $db->query("SELECT * FROM orders WHERE date ='$fivedays_ago' and user = '$sess_username'");
    
    $sixdays_ago = date('Y-m-d', strtotime("-6 day"));
    $check_order_sixdays_ago = $db->query("SELECT * FROM orders WHERE date ='$sixdays_ago' and user = '$sess_username'");   
    
    // Data Selesai
    
    // Data Grafik Pesanan Pulsa PPOB
    $check_order_pulsa_today = $db->query("SELECT * FROM orders_pulsa WHERE date ='$date' and user = '$sess_username'");
    
    $oneday_ago = date('Y-m-d', strtotime("-1 day"));
    $check_order_pulsa_oneday_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$oneday_ago' and user = '$sess_username'");
    
    $twodays_ago = date('Y-m-d', strtotime("-2 day"));
    $check_order_pulsa_twodays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$twodays_ago' and user = '$sess_username'");
    
    $threedays_ago = date('Y-m-d', strtotime("-3 day"));
    $check_order_pulsa_threedays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$threedays_ago' and user = '$sess_username'");
    
    $fourdays_ago = date('Y-m-d', strtotime("-4 day"));
    $check_order_pulsa_fourdays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$fourdays_ago' and user = '$sess_username'");
    
    $fivedays_ago = date('Y-m-d', strtotime("-5 day"));
    $check_order_pulsa_fivedays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$fivedays_ago' and user = '$sess_username'");
    
    $sixdays_ago = date('Y-m-d', strtotime("-6 day"));
    $check_order_pulsa_sixdays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$sixdays_ago' and user = '$sess_username'");
    
    // Data Selesai
    
    // Data Grafik Pesanan Game
    $check_order_game_today = $db->query("SELECT * FROM orders_game WHERE date ='$date' and user = '$sess_username'");
    
    $oneday_ago = date('Y-m-d', strtotime("-1 day"));
    $check_order_game_oneday_ago = $db->query("SELECT * FROM orders_game WHERE date ='$oneday_ago' and user = '$sess_username'");
    
    $twodays_ago = date('Y-m-d', strtotime("-2 day"));
    $check_order_game_twodays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$twodays_ago' and user = '$sess_username'");
    
    $threedays_ago = date('Y-m-d', strtotime("-3 day"));
    $check_order_game_threedays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$threedays_ago' and user = '$sess_username'");
    
    $fourdays_ago = date('Y-m-d', strtotime("-4 day"));
    $check_order_game_fourdays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$fourdays_ago' and user = '$sess_username'");
    
    $fivedays_ago = date('Y-m-d', strtotime("-5 day"));
    $check_order_game_fivedays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$fivedays_ago' and user = '$sess_username'");
    
    $sixdays_ago = date('Y-m-d', strtotime("-6 day"));
    $check_order_game_sixdays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$sixdays_ago' and user = '$sess_username'");
    
    // Data Selesai

    // Data Grafik Pesanan Voucher
    $check_order_voucher_today = $db->query("SELECT * FROM orders_voucher WHERE date ='$date' and user = '$sess_username'");
    
    $oneday_ago = date('Y-m-d', strtotime("-1 day"));
    $check_order_voucher_oneday_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$oneday_ago' and user = '$sess_username'");
    
    $twodays_ago = date('Y-m-d', strtotime("-2 day"));
    $check_order_voucher_twodays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$twodays_ago' and user = '$sess_username'");
    
    $threedays_ago = date('Y-m-d', strtotime("-3 day"));
    $check_order_voucher_threedays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$threedays_ago' and user = '$sess_username'");
    
    $fourdays_ago = date('Y-m-d', strtotime("-4 day"));
    $check_order_voucher_fourdays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$fourdays_ago' and user = '$sess_username'");
    
    $fivedays_ago = date('Y-m-d', strtotime("-5 day"));
    $check_order_voucher_fivedays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$fivedays_ago' and user = '$sess_username'");
    
    $sixdays_ago = date('Y-m-d', strtotime("-6 day"));
    $check_order_voucher_sixdays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$sixdays_ago' and user = '$sess_username'");
    
    // Data Selesai

    //Total Pemesanan Sosial Media
    $check_wsosmed = $db->query("SELECT SUM(price) AS total FROM orders WHERE user = '$sess_username'");
    $data_worder_sosmed = $check_wsosmed->fetch_assoc();
    $count_orders_sosmed = $db->query("SELECT * FROM orders WHERE user = '$sess_username'");
    $count_worder_sosmed = $count_orders_sosmed->num_rows;

    //Total Pemesanan Pulsa PPOB
    $check_wpulsa = $db->query("SELECT SUM(price) AS total FROM orders_pulsa WHERE user = '$sess_username'");
    $data_worder_pulsa = $check_wpulsa->fetch_assoc();
    $count_orders_pulsa = $db->query("SELECT * FROM orders_pulsa WHERE user = '$sess_username'");
    $count_worder_pulsa = $count_orders_pulsa->num_rows;

    //Total Pemesanan Game
    $check_wgame = $db->query("SELECT SUM(price) AS total FROM orders_game WHERE user = '$sess_username'");
    $data_worder_game = $check_wgame->fetch_assoc();
    $count_orders_game = $db->query("SELECT * FROM orders_game WHERE user = '$sess_username'");
    $count_worder_game = $count_orders_game->num_rows;

    //Total Pemesanan Voucher
    $check_wvoucher = $db->query("SELECT SUM(price) AS total FROM orders_voucher WHERE user = '$sess_username'");
    $data_worder_voucher = $check_wvoucher->fetch_assoc();
    $count_orders_voucher = $db->query("SELECT * FROM orders_voucher WHERE user = '$sess_username'");
    $count_worder_voucher = $count_orders_voucher->num_rows;

    $cek_tf = $db->query("SELECT SUM(quantity) AS total FROM transfer_balance WHERE receiver = '$sess_username'");
    $total_tf = $cek_tf->fetch_assoc();
    $count_tf = $db->query("SELECT * FROM transfer_balance WHERE receiver = '$sess_username'");
    $count_wtf = $count_tf->num_rows;
    
    $cek_depo = $db->query("SELECT SUM(jumlah) AS total FROM deposit WHERE username = '$sess_username'");
    $total_depo = $cek_depo->fetch_assoc();
    $count_depo = $db->query("SELECT * FROM deposit WHERE username = '$sess_username'");
    $count_wdepo = $count_depo->num_rows;

	$location = $db->query("SELECT * FROM location WHERE username = '$sess_username'");
	$data_location = mysqli_fetch_assoc($location);
} else {
    $_SESSION['user'] = $data_user;
    header("Location: ".$cfg_baseurl."home");
    }
    
include("lib/header.php");
if (isset($_SESSION['user'])) {
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
<div class="row">
    <div class="col-lg-12">
	    <div class="alert alert-success">
		    <div  scrollamount="10" align="center">
			<font color="black">
			Hallo <?php echo $data_user['username']; ?><br>Ayo Ikut Group <b><i class="mdi mdi-whatsapp text-success"></i> WhatsApp</b> Biar Tau Informasi Terbaru Dari <?php echo $cfg_webname ?>. <a class="btn btn-rounded btn-success" href="https://chat.whatsapp.com/Hq0RrQV5Y4MLOn9LfzP65c" target="_blank"><i class="mdi mdi-whatsapp"></i> Join Group</a></li>
		</div>
	</div>
<br />

	            <div class="row">
	                <div class="col-md-12" style="margin-top: -17px;">
	                    <div class="card card-body">
	                        <div class="row">
	                            <div class="col-6">
        	                        <h4 class="mb-0 text-success" style="margin-top: -5px !important; margin-bottom: -10px !important;"><i class="fa fa-wallet text-success"></i> Rp <?php echo number_format($data_user['balance'],0,',','.'); ?></h4>
        	                    </div>
    	                        <div class="col-6 text-right" style="margin-top: -10px !important; margin-bottom: -10px !important;">
            	                    <a href="<?php echo $cfg_baseurl; ?>deposit-saldo" class="btn btn-success btn-sm"> <i class="fas fa\s-circle"></i> Deposit Saldo</a>
    	                        </div>
	                        </div>
	                    </div>
	                </div>
<div class="col-12" style="margin-top: 20px;">
	                <div class="card text-center">
	                    <table class="table table-bordered mb-0">
                            <tbody>
                                <tr>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/pulsa" class="btn-loading"><i class="mdi mdi-cellphone-iphone fa-3x"></i>
                                            </a><a href="/beli/pulsa" class="btn-loading"><h5 class="text-primary">Pulsa Reguler</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="/orders" class="text-primary">
                                            </a><a href="/sosmed/sos" class="btn-loading"><i class="mdi mdi-instagram  fa-3x"></i>
                                            </a><a href="/sosmed/sos" class="btn-loading"><h5 class="text-primary">Social Media</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/paket-smstelpon" class="btn-loading"><i class="mdi mdi-phone-in-talk fa-3x"></i>
                                            </a><a href="/beli/paket-smstelpon" class="btn-loading"><h5 class="text-primary">Telepon & SMS</h5>
                                        </a>
                                    </th>
                                </tr>
                                
                                <tr>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/voucher-game" class="btn-loading"><i class="mdi mdi-gamepad-variant  fa-3x"></i>
                                            </a><a href="/beli/voucher-game" class="btn-loading"><h5 class="text-primary">Voucher Game</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/pln" class="btn-loading"><i class="mdi mdi-lightbulb-on-outline fa-3x"></i>
                                            </a><a href="/beli/pln" class="btn-loading"><h5 class="text-primary">Token PLN Prabayar</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="" class="text-success">
                                            </a><a href="/beli/saldo-emoney" class="btn-loading"><i class="mdi mdi-cash-100 fa-3x"></i>
                                            </a><a href="/beli/saldo-emoney" class="btn-loading"><h5 class="text-primary">Saldo E-money</h5>
                                        </a>
                                    </th>
                                </tr>
                                
                                <tr>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/paket-internet" class="btn-loading"><i class="mdi mdi-earth  fa-3x"></i>
                                            </a><a href="/beli/paket-internet" class="btn-loading"><h5 class="text-primary">Paket Data</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/order/saldo" class="btn-loading"><i class="mdi mdi-credit-card-plus   fa-3x"></i>
                                            </a><a href="/order/saldo" class="btn-loading"><h5 class="text-primary">Custome Saldo</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/lainya.php" class="btn-loading"><i class="mdi mdi-plus-circle-outline fa-3x"></i>
                                            </a><a href="/beli/lainya.php" class="btn-loading"><h5 class="text-primary">Lainya</h5>
                                        </a>
                                    </th>
                                </tr>
                                
                                <tr>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/spotify" class="btn-loading"><i class="mdi mdi-spotify  fa-3x"></i>
                                            </a><a href="/beli/spotify" class="btn-loading"><h5 class="text-primary">Spotify Premium</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/netflix" class="btn-loading"><i class="mdi mdi-netflix fa-3x"></i>
                                            </a><a href="/beli/netflix" class="btn-loading"><h5 class="text-primary">Netflix Premium</h5>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="" class="text-primary">
                                            </a><a href="/beli/youtube.php" class="btn-loading"><i class="mdi mdi-youtube fa-3x"></i>
                                            </a><a href="/beli/youtube.php" class="btn-loading"><h5 class="text-primary">Youtube Premium</h5>
                                        </a>
                                    </th>
                                </tr>
                            </tbody>
                        </table>
	                </div>
	            </div>
	        </div>
	    </div>
						<br />
						<!-- end row-->

                        <div class="row">
                            <div class="col-md-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-chart-bar text-success"></i> Grafik Pesanan 7 Hari Terakhir </h4> 
                                    </div> 
                                    <div class="card-body">
        <div class="chart" id="line-chart" style="height: 325px;"></div>
        <script>
  $(function () {
    "use strict";

    // LINE CHART
    var line = new Morris.Line({
      element: 'line-chart',
      resize: true,
      data: [
        {y: '<?php echo $date; ?>', v: <?php echo mysqli_num_rows($check_order_today); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_today); ?>},
        {y: '<?php echo $oneday_ago; ?>', v: <?php echo mysqli_num_rows($check_order_oneday_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_oneday_ago); ?>},
        {y: '<?php echo $twodays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_twodays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_twodays_ago); ?>},
        {y: '<?php echo $threedays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_threedays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_threedays_ago); ?>},
        {y: '<?php echo $fourdays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_fourdays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_fourdays_ago); ?>},
        {y: '<?php echo $fivedays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_fivedays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_fivedays_ago); ?>},
        {y: '<?php echo $sixdays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_sixdays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_sixdays_ago); ?>}
      ],
      xkey: 'y',
      ykeys: ['v','w'],
      labels: ['Pesanan Sosmed','Pesanan Pulsa PPOB'],
      lineColors: ['#f35864','#1576c2'],
      hideHover: 'auto'
    });
  });
</script>
                                        </div>
                                    </div>
                                </div>
                                
	    <div class="col-md-12 col-lg-4">
	        <div class="row">
	            <div class="col-md-12">
                    <div class="widget-rounded-circle card-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="avatar-lg rounded-circle bg-soft-success border-success border">
                                    <i class="mdi mdi-cart-outline font-22 avatar-title text-success"></i>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-right">
                                    <h3 class="text-dark mt-1"><span data-plugin="">Rp. <?php echo number_format($data_worder_sosmed['total']+$data_worder_pulsa['total']+$data_worder_game['total']+$data_worder_voucher['total'],0,',','.'); ?></span></h3>
                                    <p class="text-muted mb-1 text-truncate">Total Pemesanan</p>
                                </div>
                            </div>
                        </div> <!-- end row-->
                    </div>
	            </div>
	            <div class="col-md-12">
                    <div class="widget-rounded-circle card-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="avatar-lg rounded-circle bg-soft-success border-success border">
                                    <i class="mdi mdi-cart-plus font-22 avatar-title text-success"></i>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-right">
                                    <h3 class="text-dark mt-1"><span data-plugin=""><?php echo $count_worder_sosmed+$count_worder_pulsa+$count_worder_game+$count_worder_voucher; ?></span></h3>
                                    <p class="text-muted mb-1 text-truncate">Total Pembelian</p>
                                </div>
                            </div>
                        </div> <!-- end row-->
                    </div>
	            </div>
	            <div class="col-md-12">
                    <div class="widget-rounded-circle card-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="avatar-lg rounded-circle bg-soft-success border-success border">
                                    <i class="mdi mdi-credit-card font-22 avatar-title text-success"></i>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-right">
                                    <h3 class="text-dark mt-1"><span data-plugin="">Rp. <?php echo number_format($total_depo['total']+$total_tf['total'],0,',','.'); ?> (Dari <?php echo $count_wdepo+$count_wtf; ?> Deposit)</span></h3>
                                    <p class="text-muted mb-1 text-truncate">Total Deposit Saldo</p>
                                </div>
                            </div>
                        </div> <!-- end row-->
                    </div>
	            </div>
	        </div>
	    </div>
	</div>
	<!-- end row -->
	
                    <div class="row">                
                        <div class="col-md-12">
                            <div class="card widget-user">
                                <div class="card-body">
                                    <div class="pull-right">
                                        <div class="text-right">
                                        <a class="btn btn-rounded btn-success" href="<?php echo $cfg_baseurl; ?>user/pengaturan-akun"><i class="fas fa-cog"></i> Pengaturan Akun</a>
                                        </div>
                                    </div>
                                    <img src="<?php echo $cfg_baseurl ?>assets/images/businessman.svg" width="100px" class="mdi mdi-user img-fluid d-block rounded-circle" alt="user">
                                        <h5 class="m-t-20 m-b-5"><b><?php echo $data_user['nama']; ?></b></h5>
                                        <p class="text-muted font-5"><b>Nama Pengguna</b> : <?php echo $data_user['username']; ?><br/><b>Sisa Saldo</b> : Rp <?php echo number_format($data_user['balance'],0,',','.'); ?><br/><b>Level</b> : <?php echo $data_user['level']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- end row -->
                
                    <?php 
                    if($data_user['read_news'] == 0){
                    ?>
                    <div class="modal fade" id="news" tabindex="-1" role="dialog" aria-labelledby="NewsInfo" aria-hidden="true" style="display: none;">
                      <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title text-center" id="NewsInfo"><b><i class="mdi mdi-bullhorn fa-fw"></i>  Berita & Informasi</b></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="true">×</button>
                          </div>
                          <div class="modal-body" style="max-height: 400px; overflow: auto;">
                              <div class="table-responsive">
                                  <?php
                                    $check_news = $db->query("SELECT * FROM news ORDER BY id DESC LIMIT 5");
                                    while ($data_news = $check_news->fetch_assoc()) {
                                    if($data_news['type'] == "INFORMASI") {
                                        $alert = "primary";
                                    } else if($data_news['type'] == "PERINGATAN") {
                                        $alert = "danger";
                                    } else if($data_news['type'] == "LAYANAN") {
                                        $alert = "success";
                                    } else if($data_news['type'] == "EVENT") {
                                        $alert = "warning";
                                    }                                                        
                                    ?>
                            <div class="alert alert-info">
                                <p><span class="float-right text-muted"><?php echo TanggalIndonesia($data_news['date']); ?>, <?php echo $data_news['time']; ?></span></p>
                                <h5 class="inbox-item-author mt-0 mb-1"><?php echo $data_news['title']; ?></h5>
                                <h5><span class="badge badge-<?php echo $alert; ?>"><?php echo $data_news['type']; ?></span></h5>
                                <?php echo nl2br($data_news['content']); ?>
                              </div>
                            <?php } ?>
                           </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-success btn-bordred waves-effect w-md waves-light" data-dismiss="modal" onclick="read_news()"><i class="mdi mdi-read"></i> Saya Sudah Membaca</button>
                          </div>
                        </div>
                                <!-- /.modal-content -->
                      </div>
                    </div>  
                    <?php  
                    }
                    ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-box">
        		                    <div class="float-right">
                                <a href="<?php echo $cfg_baseurl ?>user/berita" class="btn btn-success">Lihat Semua Berita</a>
                            </div>
        	                <h4 class="header-title mb-3"><i class="mdi mdi-newspaper text-success"></i> Berita Terbaru</h4>
        	                <hr/>

<?php
// start paging config
$check_news = $db->query("SELECT * FROM news ORDER BY id DESC LIMIT 5"); // edit
// end paging config
while ($data_news = mysqli_fetch_assoc($check_news)) {
$newsstr = "-".strlen($data_news['content']);
$newssensor = substr($data_news['content'],$slider_userstr,+100);	
if($data_news['type'] == "INFORMASI") {
$alert = "primary";
} else if($data_news['type'] == "PERINGATAN") {
$alert = "danger";
} else if($data_news['type'] == "EVENT") {
$alert = "warning";
} else if($data_news['type'] == "LAYANAN") {
$alert = "success";
}                                                        
?>
                            <div class="inbox-widget">
                                <div class="inbox-item">
                                <div class="inbox-item-img"><img src="<?php echo $cfg_baseurl ?>assets/images/news.png" class="rounded-circle" alt=""></div>
                                <h5 class="inbox-item-author mt-0 mb-1"><?php echo $data_news['title']; ?></h5>
                                <div><p class="inbox-item-text"><span class="badge badge-<?php echo $alert; ?>"><?php echo $data_news['type']; ?></span><br />
                                <br />
                                <?php echo nl2br ($newssensor."....."); ?><br/><br><a href="<?php echo $cfg_baseurl ?>user/news.php?id=<?php echo $data_news['id']; ?>" class="btn btn-rounded btn-success">Selengkapnya</a></p>
                                </div>
                                </div>
                                <div class="text-right">
                                <div class="date" style="font-size:12px">
                                <p class="inbox-item-date"><?php echo TanggalIndonesia($data_news['date']); ?>, <?php echo $data_news['time']; ?></p>
                                </div>
                                <hr/>
                            </div>
                        </div>
<?php
}
?>
                    </div>
                </div>
            </div>
        </div> <!-- end container -->
    </div> <!-- end wrapper -->
                 
<?php
}
include("lib/footer.php");
?>