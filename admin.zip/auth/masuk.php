<?php
// Recoded by HL_C0D3
// Hargailah orang lain jika Anda ingin dihargai
session_start();
require("../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	header("Location: ".$cfg_baseurl);
} else {
	if (isset($_POST['login'])) {
		$post_username = $db->real_escape_string(trim(filter($_POST['username'])));
		$post_password = $db->real_escape_string(trim(filter($_POST['password'])));
		$ip = $_SERVER['REMOTE_ADDR'];

		if (empty($post_username) || empty($post_password)) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
		} else {
			$check_user = $db->query("SELECT * FROM users WHERE username = '$post_username'");
			if (mysqli_num_rows($check_user) == 0) {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Nama Pengguna Atau Kata Sandi.<script>swal("Gagal!", "Nama Pengguna Atau Kata Sandi.", "error");</script>';
			} else {
				$data_user = $check_user->fetch_assoc();
				$verif_pass = password_verify($post_password, $data_user['password']) ;
				if ($verif_pass <> $data_user['password']) {
					$msg_type = "error";
					$msg_content = '<b>Gagal:</b> Nama Pengguna Atau Kata Sandi Salah.<script>swal("Gagal!", "Nama Pengguna Atau Kata Sandi.", "error");</script>';
				} else if ($data_user['status'] == "Suspended") {
					$msg_type = "error";
					$msg_content = '<b>Gagal:</b> Akun Anda Telah Dinonaktifkan.<script>swal("Gagal!", "Akun Anda Telah Dinonaktifkan.", "error");</script>';
				} else {
					$_SESSION['user'] = $data_user;
					$insert_user = $db->query("INSERT INTO log (username, catatan, waktu) VALUES ('$post_username', 'Kamu Telah Melakukan Aktifitas Masuk Akun Dengan IP $ip', '$date $time')");
					if ($insert_user == TRUE) {
					header("Location: ".$cfg_baseurl);
				}
				}
			}
		}
	}
}

include("../lib/header.php");
?>
 <div class="row">
                    <div class="col-sm-6">
                        <br/>
                    </div>
                </div>	
					<div class="row">
                        <div class="offset-lg-3 col-lg-6">
                            <div class="card">
                                <div class="card-box ribbon-box">
                                    <div class="ribbon ribbon-success float-left"><i class="mdi mdi-login"></i> Masuk</div>
                                        <div class="ribbon-content">
                                        </div>
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-info">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
												<label>Nama Pengguna</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-user text-success"></i>
                                                    </div>
                                                </div>
													<input type="text" name="username" class="form-control" placeholder="Nama Pengguna" required>
												</div>
											</div>
											<div class="form-group">
												<label>Kata Sandi</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-lock text-success"></i>
                                                    </div>
                                                </div>
													<input type="password" id="password" name="password" class="form-control" placeholder="Kata Sandi" required>
												</div>
											</div>
												<button type="reset" class="btn btn-success waves-effect waves-light"><i class="fa fa-history"></i> Ulangi</button>
												<button type="submit" name="login" class="btn btn-success waves-effect waves-light"><i class="mdi mdi-login"></i> Masuk</button>
		                                    </form>
		                                </div>
										<div class="card-footer">
											Belum Punya Akun? <a class="btn btn-success waves-effect" href="<?php echo $cfg_baseurl; ?>auth/daftar"><i class="mdi mdi-account-plus"></i> Daftar</a>
										</div>
									</div>
								</div>
							</div>
                            <!-- end col -->
<?php
include("../lib/footer.php");
?>