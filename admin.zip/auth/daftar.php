<?php
session_start();
require("../mainconfig.php");
$msg_type = "nothing";


function dapetin($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $data = curl_exec($ch);
        curl_close($ch);
                return json_decode($data, true);
}
if (isset($_SESSION['user'])) {
    header("Location : ".$cfg_baseurl);
} else {
if (isset($_POST['daftar'])) {              
	$post_name = $db->real_escape_string(trim(filter($_POST['fullname'])));
	$post_email = $db->real_escape_string(trim(filter($_POST['email'])));
	$post_hp = $db->real_escape_string(trim(filter($_POST['no_hp'])));
    $post_username = $db->real_escape_string(trim(filter($_POST['username'])));
	$post_password = $db->real_escape_string(trim(filter($_POST['password'])));
	$post_repeat_password = $db->real_escape_string(trim(filter($_POST['repassword'])));

	$hash_password = password_hash($post_password,PASSWORD_DEFAULT);

			
	$checkdb_email = mysqli_query($db, "SELECT * FROM users WHERE email = '$post_email'");
	$checkdb_nomor = mysqli_query($db, "SELECT * FROM users WHERE no_hp = '$post_hp'");
	$checkdb_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$post_username'");
	$datadb_user = mysqli_fetch_assoc($checkdb_user);
	if (empty($post_name) || empty($post_username) || empty($post_password) || empty($post_repeat_password) || empty($post_email) || empty($post_hp)) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
	} else if (mysqli_num_rows($checkdb_nomor) > 0) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Nomor HP Sudah Terdaftar.<script>swal("Gagal!", "Nomor HP Sudah Terdaftar.", "error");</script>';
	} else if (mysqli_num_rows($checkdb_user) > 0) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Nama Pengguna Sudah Terdaftar.<script>swal("Gagal!", "Nama Pengguna Sudah Terdaftar.", "error");</script>';
	} else if (mysqli_num_rows($checkdb_email) > 0) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> E-Mail Sudah Terdaftar.<script>swal("Gagal!", "E-Mail Sudah Terdaftar.", "error");</script>';
	} else if (strlen($post_username) > 15) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Nama Pengguna Maksimal 15 Karakter.<script>swal("Gagal!", "Nama Pengguna Maksimal 15 Karakter.", "error");</script>';
	} else if (strlen($post_password) > 15) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Kata Sandi Maksimal 15 Karakter.<script>swal("Gagal!", "Kata Sandi Maksimal 15 Karakter.", "error");</script>';
	} else if (strlen($post_username) < 4) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Nama Pengguna Minimal 4 Karakter.<script>swal("Gagal!", "Nama Pengguna Minimal 4 Karakter.", "error");</script>';
	} else if (strlen($post_password) < 4) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Kata Sandi Minimal 4 Karakter.<script>swal("Gagal!", "Kata Sandi Minimal 4 Karakter.", "error");</script>';
	} else if ($post_password <> $post_repeat_password) {
		$msg_type = "error";
		$msg_content = '<b>Gagal:</b> Konfirmasi Kata Sandi Tidak Sesuai.<script>swal("Gagal!", "Konfirmasi Kata Sandi Tidak Sesuai.", "error");</script>';
	} else {
		$post_api = random(20);
		$insert_user = mysqli_query($db, "INSERT INTO users (nama, username, password, balance, level, registered, status, api_key, no_hp, email, uplink) VALUES ('$post_name', '$post_username', '$hash_password', '0', 'Member', '$date', 'Active', '$post_api', '$post_hp', '$post_email', 'System')");
			if ($insert_user == TRUE) {
				$msg_type = "success";
				$msg_content = "<b>Berhasil:</b> Pendaftaran Akun Berhasil.</b><br /><b>E-Mail:</b> $post_email<br /><b>Nama Pengguna:</b> $post_username<br /><b>Kata Sandi:</b> $post_password";
			} else {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}
	}

include_once("../lib/header.php");
?>
 <div class="row">
                    <div class="col-sm-6">
                        <br/>
                    </div>
                </div>	
					<div class="row">
                        <div class="offset-lg-3 col-lg-6">
                            <div class="card">
                                <div class="card-box ribbon-box">
                                    <div class="ribbon ribbon-success float-left"><i class="mdi mdi-account-plus"></i> Daftar Akun</div>
                                        <div class="ribbon-content">
                                        </div>
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
												<label>Nama Lengkap</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="mdi mdi-account-card-details text-success"></i>
                                                    </div>
                                                </div>
													<input type="text" name="fullname" class="form-control" placeholder="Nama Lengkap Anda">
												</div>
											</div>
											<div class="form-group">
												<label>E-Mail</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-envelope text-success"></i>
                                                    </div>
                                                </div>
													<input type="email" name="email" class="form-control" placeholder="E-Mail Aktif Anda">
												</div>
											</div>											
											<div class="form-group">
												<label>Nomor HP</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-phone text-success"></i>
                                                    </div>
                                                </div>
													<input type="number" name="no_hp" class="form-control" placeholder="Nomor HP. Contoh: 089506667156">
												</div>
											</div>
											<div class="form-group">
												<label>Nama Pengguna</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-user text-success"></i>
                                                    </div>
                                                </div>
													<input type="text" name="username" class="form-control" placeholder="Masukan Nama Pengguna">
												</div>
											</div>
											<div class="form-group">
												<label>Kata Sandi</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-lock text-success"></i>
                                                    </div>
                                                </div>
													<input type="password" name="password" class="form-control" placeholder="Masukan Kata Sandi">
												</div>
											</div>
											<div class="form-group">
												<label>Konfirmasi Kata Sandi</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-lock text-success"></i>
                                                    </div>
                                                </div>
													<input type="password" name="repassword" class="form-control" placeholder="Konfirmasi Kata Sandi">
												</div>
											</div>
											<div class="form-group">
                                                             	                        <div class="form-group">
											    <div class="custom-control custom-checkbox">
											    <input type="checkbox" name="agree" class="custom-control-input" id="agree" required>
											        <label class="custom-control-label" for="agree">
											        Saya Setuju Dengan <a href="<?php echo $cfg_baseurl; ?>halaman/tos">Ketentuan Layanan</a>
											        </label>
											    </div>
											</div>
											<button type="reset" class="btn btn-success waves-effect waves-light"><i class="fa fa-history"></i> Ulangi</button>
											<button type="submit" name="daftar" class="btn btn-success waves-effect waves-light"><i class="fa fa-user-plus"></i> Daftar</button>
		                                    </form>
										</div>
										<div class="card-footer">
											Sudah Punya Akun? <a class="btn btn-success waves-effect" href="<?php echo $cfg_baseurl; ?>auth/masuk"><i class="mdi mdi-login"></i> Masuk</a>
										</div>
									</div>
								</div>
							</div>
                            <!-- end col -->
                            
<script src='https://www.google.com/recaptcha/api.js'></script>
                            
<?php
include("../lib/footer.php");
?>
