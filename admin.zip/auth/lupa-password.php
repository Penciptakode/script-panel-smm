<?php
session_start();
require("../mainconfig.php");
require("../lib/class.phpmailer.php");
$msg_type = "nothing";

	if (isset($_POST['lupa'])) {
		$post_username = $db->real_escape_string(trim(filter($_POST['username'])));
		
		$check_user = $db->query("SELECT * FROM users WHERE username = '$post_username'");
	    $data_user = $check_user->fetch_assoc();

		if (empty($post_username)) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
		} else if (mysqli_num_rows($check_user) == 0) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Nama Pengguna Tidak Ditemukan.<script>swal("Gagal!", "Nama Pengguna Tidak Ditemukan.", "error");</script>';
		} else {
		    
    $new_password = random_number(7);
    $hash = password_hash($new_password, PASSWORD_DEFAULT);
    $tujuan = $data_user['email'];
    $username = $data_user['username'];
    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->SMTPSecure = 'ssl'; 
    $mail->Host = "mail.wdstoree.com"; //host masing2 provider email
    $mail->SMTPDebug = 2;
    $mail->Port = 465;
    $mail->SMTPAuth = true;
    $mail->Username = "admin@wdstoree.com"; //user email
    $mail->Password = "ollogans@@"; //password email 
    $mail->SetFrom("admin@wdstoree.com",""); //set email pengirim
    $mail->Subject = "Reset Password Akun ZuraPedia"; //subyek email
    $mail->AddAddress("$tujuan","");  //tujuan email
    $mail->MsgHTML("Lupa Password Akun<br><br><b>Nama Pengguna : $username<br>Kata Sandi Baru : $new_password<b><br>Silahkan Login Dengan Menggunakan Kata Sandi Baru Anda, Terima Kasih!");
    if ($mail->Send());

                $send = mysqli_query($db, "UPDATE users SET password = '$hash', verif_code = '$new_password' WHERE username = '$post_username'");
                if ($send == true) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Kata Sandi Baru Anda Telah Dikirim Ke Email Anda.<br /><b>Silahkan Di Cek Email Anda Di Halaman Utama Atau Spam";
                } else {
                    $msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
                }	
			}
		}

include_once("../lib/header.php");
?>
 <div class="row">
 	<br />
 </div>

						<div class="row">
                            <div class="offset-lg-3 col-lg-6">
                                <div class="card-box ribbon-box">
                                    <div class="ribbon ribbon-success float-left"><i class="mdi mdi-account-key"></i> Lupa Kata Sandi</div>
                                        <div class="ribbon-content">
                                        </div>
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
												<label>Nama Pengguna</label>
											    <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-user text-success"></i>
                                                    </div>
                                                </div>
													<input type="text" name="username" class="form-control" placeholder="Nama Pengguna Anda">
												</div>
											</div>
												<button type="reset" class="btn btn-success waves-effect waves-light"><i class="fa fa-history"></i> Ulangi</button>
												<button type="submit" name="lupa" class="btn btn-success waves-effect waves-light"><i class="mdi mdi-login"></i> Lupa</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->

<?php
include("../lib/footer.php");
?>
