<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:image" content="<?php echo $cfg_baseurl; ?>home/pacific.png">
        <meta name="description" content="<?php echo $cfg_webname ?> Adalah Sebuah Platform Bisnis Yang Menyediakan Berbagai Layanan Multy Media Marketing Yang Bergerak Terutama Di Indonesia. Dengan Bergabung Bersama Kami, Anda Dapat Menjadi Penyedia Jasa Sosial Media Atau Reseller Sosial Media Seperti Jasa Penambah Followers, Likes, Views, Subscribe, Dll.
Saat Ini Tersedia Berbagai Layanan Untuk Sosial Media Terpopuler Seperti Instagram, Facebook, Twitter, Youtube, Dll. Dan Kamipun Juga Menyediakan Panel Pulsa & PPOB Seperti Pulsa All Operator, Paket Data, Saldo Gojek/Grab, Token PLN, All Voucher Game Online, Dll.">
        <meta name="keywords" content="Cheaplikes Panel,Indo Panel, Free Followers, SMM Cheap, Indo SMM, SMM Panel, SMM Murah, API Integration, Cheap SMM Panel, Admin panel instagram, admin panel twitter, autofollowers instagram, jasa tambah followers instagram murah, jasa tambah followers, Cara menambah followers instagram, Panel SMM, Track Your Activity, Instagram Followers, Free Followers, Free Retweets, Costumer Service, Free Subcribe, Free Views, Beli Followers Instagram, Beli Followers, Social Media, Reseller, Smm, Panel, SMM, Fans, Instagram, Facebook, Youtube, Cheap, Reseller, Panel, Top, 10, Social, Rankings, Working, Fast, Cheap, Free, Safe, Automatic, Instant, Not, Manual, perfect, followersindo, followers gratis, followers ig, followers boom, followers instagram terbanyak, followers instagram bot, followers tk, followers jackpot, instagram followers, followers for instagram, free instagram followers, buy instagram followers, how to get more followers on instagram, get followers on instagram, Auto Like IG, Instagram Like,Penyedia Pulsa All Operator,Peyedia PPOB,Tagihan PPOB,Paket DAta All Operator, PLN, Token PLN, Terlengkap Dan Termurah, Brebes Media, Paket SMS All Operator">
        <meta name="author" content="ArCode">

        <link rel="shortcut icon" href="<?php echo $cfg_baseurl; ?>home/pacific.png">

        <title><?php echo $cfg_webtitle; ?></title>

        <!-- App css -->
        <link href="<?php echo $cfg_baseurl; ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $cfg_baseurl; ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $cfg_baseurl; ?>assets/css/app.min.css" rel="stylesheet" type="text/css" />
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
        <style type="text/css">
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background-color: #fff;
        }
        .preloader .loading {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%,-50%);
            font: 14px arial;
        }
        </style>
        
        
    </head>
    
    <body>
    
        <div class="preloader">
            <div class="loading">
                <img src="<?php echo $cfg_baseurl; ?>assets/images/diamond.gif" width="150">
                <center><p>Please Wait...</p></center>
            </div>
        </div>

    <body class="menubar-light">
        <header id="topnav">
            <!-- Topbar Start -->
            <div class="navbar-custom">
                <div class="container-fluid">
                    <ul class="list-unstyled topnav-menu float-right mb-0">

                        <li class="dropdown notification-list">
                            <!-- Mobile menu toggle-->
                            <a class="navbar-toggle nav-link">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </li>
                        
            <?php
            if (isset($_SESSION[ 'user'])) {
            ?>
                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <img src="<?php echo $cfg_baseurl; ?>assets/images/avatar-5.jpg" alt="user-image" class="rounded-circle">
                                <span class="pro-user-name ml-1">
                                    <?php echo $data_user['username']; ?> <i class="mdi mdi-chevron-down"></i> 
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                                
                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl; ?>user/pengaturan-akun" class="dropdown-item notify-item">
                                    <i class="ti-settings m-r-5 text-success"></i>
                                    <span>Pengaturan Akun</span>
                                </a>

                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl ?>user/penggunaan-saldo" class="dropdown-item notify-item">
                                    <i class="fa fa-wallet text-success"></i>
                                    <span>Penggunaan Saldo</span>
                                </a>

                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl ?>user/log" class="dropdown-item notify-item">
                                    <i class="fa fa-history text-success"></i>
                                    <span>Aktifitas Akun</span>
                                </a>

                                <div class="dropdown-divider"></div>

                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl ?>logout" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout text-success"></i>
                                    <span>Keluar</span>
                                </a>
                            </div>
                        </li>
            <?php } ?>    
                    </ul>

                    <!-- LOGO -->
                    <div class="logo-box">
                        <a href="<?php echo $cfg_baseurl; ?>" class="logo">
                            <span class="logo-large"><i class="mdi mdi-cart"></i> <?php echo $cfg_webname ?></span>
                        </a>
                    </div>
    
                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                        
                    </ul>
                </div> <!-- end container-fluid-->
            </div>
            <div class="topbar-menu">
                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">
            <?php
            if (isset($_SESSION['user'])) {
            ?>    
            <?php
            if ($data_user['level'] == "Developers") {
            ?> 
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>admin"><i class="fa fa-user text-success"></i> Admin Page</a>
                            </li>

            <?php } ?>
            <?php
            if ($data_user['level'] != "Member") {
            ?>   
                     <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>">
                                    <i class="fa fa-home text-success"></i>Dashboard</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"><i class="fa fa-users text-success"></i>Menu Staff<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>staff/tambah-pengguna">
                                        <i class="mdi mdi-account-plus mr-1"></i>
                                        <span>Tambah Pengguna</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>staff/transfer-saldo">
                                        <i class="fa fa-exchange-alt mr-1"></i>
                                        <span>Transfer Saldo</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>staff/kode-voucher">
                                        <i class="fe-shopping-bag mr-1"></i>
                                        <span>Buat Kode Voucher</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>staff/kelola-uplink">
                                        <i class="fa fa-history mr-1"></i>
                                        <span>Kelola Uplink</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>staff/kelola-transfer-saldo">
                                        <i class="fa fa-history mr-1"></i>
                                        <span>Kelola Transfer Saldo</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <?php
                                 }
                            ?>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>user/hall-of-fame">
                                    <i class="fa fa-bullhorn text-success"></i>Hof</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"><i class="fa fa-history text-success"></i>Riwayat & Layanan<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                   <li class="has-submenu">
                                        <a href="#">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span>Pulsa & PPOB</span>
                                            <div class="arrow-down"></div>
                                        </a>
                                        <ul class="submenu">
                                            <li>
                                            <a href="<?php echo $cfg_baseurl; ?>beli/riwayat" class="dropdown-item">
                                                <i class="fa fa-history"></i>
                                                <span>Riwayat Pemesanan</span>
                                                </a>
                                            </li>
                                            <li>
                                            <a href="<?php echo $cfg_baseurl; ?>beli/daftar-layanan" class="dropdown-item">
                                                <i class="fa fa-list"></i>
                                                <span>Daftar Layanan</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="has-submenu">
                                        <a href="#">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span>Sosial Media</span>
                                            <div class="arrow-down"></div>
                                        </a>
                                        <ul class="submenu">
                                            <li>
                                                <a href="<?php echo $cfg_baseurl; ?>sosmed/riwayat" class="dropdown-item">
                                                <i class="fa fa-history"></i>
                                                <span>Riwayat Pemesanan</span>
                                                </a>
                                            </li>
                                            <li>
                                            <a href="<?php echo $cfg_baseurl; ?>sosmed/daftar-layanan" class="dropdown-item">
                                                <i class="fa fa-list"></i>
                                                <span>Daftar Layanan</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li> 
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-credit-card text-success"></i>Deposit<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>deposit-saldo">
                                            <i class="fa fa-balance-scale mr-1"></i>
                                            <span>Buat Deposit</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>deposit-saldo/caradepo">
                                            <i class="mdi mdi-help mr-1"></i>
                                            <span>Cara Deposit</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>deposit-saldo/riwayat">
                                            <i class="fa fa-history mr-1"></i>
                                            <span>Riwayat Deposit</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>tiket">
                                    <i class="fa fa-envelope text-success"></i>Tiket</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-file text-success"></i>Halaman<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/api-dokumentasi">
                                            <i class="fa fa-code"></i>
                                            <span>API Dokumentasi</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/kontak">
                                            <i class="fe-phone-call mr-1"></i>
                                            <span>Hubungi Kami</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/staff">
                                            <i class="fa fa-users"></i>
                                            <span>Staff Kami</span>
                                        </a>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/tos">
                                            <i class="mdi mdi-information-variant"></i>
                                            <span>Ketentuan Layanan</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/faq">
                                            <i class="fa fa-edit"></i>
                                            <span>Pertanyaan Umum</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/tentang-status">
                                            <i class="mdi mdi-alert-outline"></i>
                                            <span>Penjelasan Status</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <?php
                                } else {
                            ?>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>">
                                    <i class="fa fa-home text-success"></i>Halaman Utama</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>auth/masuk">
                                    <i class="mdi mdi-login text-success"></i>Masuk</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>auth/daftar">
                                    <i class="fa fa-user-plus text-success"></i>Daftar</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>auth/lupa-password">
                                    <i class="fa fa-key text-success"></i>Lupa Kata Sandi</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-list text-success"></i>Daftar Harga<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>beli/daftar-layanan">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span>Pulsa & PPOB</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>sosmed/daftar-layanan">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span>Sosial Media</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-file text-success"></i>Halaman<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/kontak">
                                            <i class="fe-phone-call mr-1"></i>
                                            <span>Contact Admin</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/tos">
                                            <i class="mdi mdi-information-variant"></i>
                                            <span>Ketentuan Layanan</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>halaman/faq">
                                            <i class="fa fa-edit"></i>
                                            <span>Pertanyaan Umum</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php
                            }
                        ?> 
                    <!-- End navigation menu -->

                        <div class="clearfix"></div>
                    </div>
                    <!-- end #navigation -->
                </div>
                <!-- end container -->
            </div>
            <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->

        <div class="wrapper">
            <div class="container-fluid">

