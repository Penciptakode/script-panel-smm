        <!-- Footer -->
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <font color="black"><?php echo $cfg_webname ?></font> &copy; Copyright 2019-2020 <strong></strong> Di Buat Dengan <i class="mdi mdi-heart text-danger"></i> Oleh <a href="https://msyahrulma.id" target="_blank">ArCode</a>.
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer -->
        
        <!-- App js -->
        <script src="<?php echo $cfg_baseurl; ?>assets/js/vendor.min.js"></script>
        <script src="<?php echo $cfg_baseurl; ?>assets/js/app.min.js"></script>
        <script>
            $('#news').modal('show');
            function read_news() {
              $.ajax({
                type: "GET",
                url: "<?php echo $cfg_baseurl; ?>inc/read_news.php"
              });
            }

        </script>
    </body>
</html>

<script>
    $(document).ready(function(){
        $(".preloader").fadeOut();
    })
</script>