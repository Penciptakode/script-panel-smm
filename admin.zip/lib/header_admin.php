<!DOCTYPE html>
<html lang="en">
    
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:image" content="<?php echo $cfg_baseurl; ?>home/pacific.png">
        <meta name="description" content="<?php echo $cfg_webname ?> Adalah Sebuah Platform Bisnis Yang Menyediakan Berbagai Layanan Multy Media Marketing Yang Bergerak Terutama Di Indonesia. Dengan Bergabung Bersama Kami, Anda Dapat Menjadi Penyedia Jasa Sosial Media Atau Reseller Sosial Media Seperti Jasa Penambah Followers, Likes, Views, Subscribe, Dll.
Saat Ini Tersedia Berbagai Layanan Untuk Sosial Media Terpopuler Seperti Instagram, Facebook, Twitter, Youtube, Dll. Dan Kamipun Juga Menyediakan Panel Pulsa & PPOB Seperti Pulsa All Operator, Paket Data, Saldo Gojek/Grab, Token PLN, All Voucher Game Online, Dll.">
        <meta name="keywords" content="Cheaplikes Panel,Indo Panel, Free Followers, SMM Cheap, Indo SMM, SMM Panel, SMM Murah, API Integration, Cheap SMM Panel, Admin panel instagram, admin panel twitter, autofollowers instagram, jasa tambah followers instagram murah, jasa tambah followers, Cara menambah followers instagram, Panel SMM, Track Your Activity, Instagram Followers, Free Followers, Free Retweets, Costumer Service, Free Subcribe, Free Views, Beli Followers Instagram, Beli Followers, Social Media, Reseller, Smm, Panel, SMM, Fans, Instagram, Facebook, Youtube, Cheap, Reseller, Panel, Top, 10, Social, Rankings, Working, Fast, Cheap, Free, Safe, Automatic, Instant, Not, Manual, perfect, followersindo, followers gratis, followers ig, followers boom, followers instagram terbanyak, followers instagram bot, followers tk, followers jackpot, instagram followers, followers for instagram, free instagram followers, buy instagram followers, how to get more followers on instagram, get followers on instagram, Auto Like IG, Instagram Like,Penyedia Pulsa All Operator,Peyedia PPOB,Tagihan PPOB,Paket DAta All Operator, PLN, Token PLN, Terlengkap Dan Termurah, Brebes Media, Paket SMS All Operator">
        <meta name="author" content="ArCode">

        <link rel="shortcut icon" href="<?php echo $cfg_baseurl; ?>home/pacific.png">

        <title><?php echo $cfg_webname; ?></title>

        <!-- App css -->
        <link href="<?php echo $cfg_baseurl; ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $cfg_baseurl; ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo $cfg_baseurl; ?>assets/css/app.min.css" rel="stylesheet" type="text/css" />
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
        
    </head>

    <body class="menubar-light">
        <header id="topnav">
            <!-- Topbar Start -->
            <div class="navbar-custom">
                <div class="container-fluid">
                    <ul class="list-unstyled topnav-menu float-right mb-0">

                        <li class="dropdown notification-list">
                            <!-- Mobile menu toggle-->
                            <a class="navbar-toggle nav-link">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </li>

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <img src="<?php echo $cfg_baseurl; ?>assets/images/avatar-5.jpg" alt="user-image" class="rounded-circle">
                                <span class="pro-user-name ml-1">
                                    <?php echo $data_user['username']; ?> <i class="mdi mdi-chevron-down"></i> 
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                
                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl; ?>user/pengaturan-akun" class="dropdown-item notify-item">
                                    <i class="ti-settings m-r-5 text-success"></i>
                                    <span>Pengaturan Akun</span>
                                </a>

                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl ?>user/penggunaan-saldo" class="dropdown-item notify-item">
                                    <i class="fa fa-wallet text-success"></i>
                                    <span>Penggunaan Saldo</span>
                                </a>

                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl ?>user/log" class="dropdown-item notify-item">
                                    <i class="fa fa-history text-success"></i>
                                    <span>Aktifitas Akun</span>
                                </a>

                                <div class="dropdown-divider"></div>

                                <!-- item-->
                                <a href="<?php echo $cfg_baseurl ?>logout" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout text-success"></i>
                                    <span>Keluar</span>
                                </a>
                            </div>
                        </li>
                    </ul>

                    <!-- LOGO -->
                    <div class="logo-box">
                        <a href="<?php echo $cfg_baseurl; ?>" class="logo">
                            <span class="logo-large"><i class="mdi mdi-cart"></i> <?php echo $cfg_webname ?></span>
                        </a>
                    </div>
    
                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                        
                    </ul>
                </div> <!-- end container-fluid-->
            </div>
            <div class="topbar-menu">
                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>admin">
                                    <i class="fa fa-home text-success"></i>Admin</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>admin/users">
                                    <i class="fa fa-users text-success"></i>Pengguna</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-cart-plus text-success"></i>Pesanan<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        
                                        <a href="<?php echo $cfg_baseurl; ?>admin/orders_pulsa">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span>Pesanan Pulsa</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/orders">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span>Pesanan Sosmed</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>cron/status_pulsa">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span> Status Pulsa</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>cron/status">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span> Status Sosmed</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>cron/refund_pulsa">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span> Refund Pulsa</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>cron/refund">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span> Refund Sosmed</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-list text-success"></i>Layanan<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/services_pulsa">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span> Layanan Pulsa</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/services">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span> Layanan Sosmed</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/operan">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span> Get Pulsa</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>cron/getsosmed">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span> Get Sosmed</span>
                                        </a>
                                    </li>
                                    <li>
                                    <a href="<?php echo $cfg_baseurl; ?>admin/kategori_pulsa">
                                            <i class="mdi mdi-cellphone-android mr-1"></i>
                                            <span>Kategori Pulsa</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/kategori">
                                            <i class="mdi mdi-instagram mr-1"></i>
                                            <span>Kategori Sosmed</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-credit-card text-success"></i> Deposit<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/deposit.php">
                                            <i class="fa fa-balance-scale"></i>
                                            <span>Deposit</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/metode_deposit.php">
                                            <i class="fa fa-tasks"></i>
                                            <span>Metode Deposit</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-history text-success"></i> Aktifitas<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/transfer_history">
                                            <i class="fa fa-exchange-alt"></i>
                                            <span>Transfer Saldo</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/log_history">
                                            <i class="fa fa-toggle-on"></i>
                                            <span>Aktifitas Pengguna</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/kode_undangan.php">
                                            <i class="fa fa-key mr-1"></i>
                                            <span>Kode Undangan</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/kode_voucher.php">
                                            <i class="fe-shopping-bag mr-1"></i>
                                            <span>Kode Voucher</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/balance_history">
                                            <i class="fa fa-history"></i>
                                            <span>Riwayat Saldo</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="<?php echo $cfg_baseurl; ?>admin/tickets">
                                    <i class="fa fa-envelope text-success"></i>Tiket</a>
                            </li>
                            <li class="has-submenu">
                                <a class="nav-link dropdown-toggle waves-effect" href="#"> <i class="fa fa-list text-success"></i>Lainnya<i class="mdi mdi-chevron-down"></i></a>
                                <ul class="submenu">
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/provider.php">
                                            <i class="ti-settings m-r-5"></i>
                                            <span>Kelola Provider</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/harga_pendaftaran.php">
                                            <i class="fa fa-money-bill-alt"></i>
                                            <span>Kelola Harga Pendaftaran</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/news.php">
                                            <i class="fa fa-newspaper"></i>
                                            <span>Kelola Berita</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/contact.php">
                                            <i class="fe-phone-call mr-1"></i>
                                            <span>Kelola Kontak</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo $cfg_baseurl; ?>admin/staff.php">
                                            <i class="fa fa-users"></i>
                                            <span>Kelola Staff</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                    <!-- End navigation menu -->

                        <div class="clearfix"></div>
                    </div>
                    <!-- end #navigation -->
                </div>
                <!-- end container -->
            </div>
            <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->

        <div class="wrapper">
            <div class="container-fluid">
                
                    <div class="row">
                        <div class="card-body">
                            <div class="pull-right">
                                <div class="text-right">
                                <a href="<?php echo $cfg_baseurl; ?>" class="btn btn-success waves-effect w-md waves-light"><i class="fa fa-reply"></i> Kembali Ke Halaman Utama</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-md-12">
                    </div>
                </div>
                <!-- end row -->

