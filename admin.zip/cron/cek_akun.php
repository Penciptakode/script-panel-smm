<?php
   require_once("../mainconfig.php");
       
$api_postdata = "api_key=14131f-3228e3-29d238-f25495-1c8e3f-3aeed4";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://d-pedia.net/information/account');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $api_postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $chresult = curl_exec($ch);
    curl_close($ch);
    $json_result = json_decode($chresult, true);

$indeks=0; 
$i = 1;
// get data service
while($indeks < count($json_result['data'])){ 
$name =$json_result['data']['name'];
$nama_pengguna =$json_result['data']['username'];
$email =$json_result['data']['email'];
$phone =$json_result['data']['phone'];
$sisa_saldo =$json_result['data']['balance'];
$indeks++; 
$i++;

         
     $cek_akun = mysqli_query($db, "SELECT * FROM cek_akun WHERE provider = 'DP-AKUN'");
            $data_akun = mysqli_fetch_assoc($cek_akun);
        if(mysqli_num_rows($cek_akun) > 0) {
            echo "<br>Data Informasi Akun Sudah Ada Di Database<br>";
        } else {
            
$insert=mysqli_query($db, "INSERT INTO cek_akun (id, saldo, date, time, provider) VALUES ('','$sisa_saldo','$date','$time','DP-AKUN')");//Memasukan Kepada Database (OPTIONAL)
if($insert == TRUE){
echo"===============<br>Berhasil Menampilkan Data Informasi Akun<br><br>Name: $name<br>Nama Pengguna : $nama_pengguna<br>Email: $email<br>Phone: $phone<br>Saldo : $sisa_saldo<br>===============<br>";
}else{
    echo "Gagal Menampilkan Data Informasi Akun";
    
}
}
}
?>