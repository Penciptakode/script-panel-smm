<?php
require("../mainconfig.php");

$check_order = mysqli_query($db, "SELECT * FROM orders WHERE status IN ('','Pending','Processing') AND provider = 'MEDAN'");

if (mysqli_num_rows($check_order) == 0) {
  die("Pesanan Pending Tidak Ditemukan.");
} else {
  while($data_order = mysqli_fetch_assoc($check_order)) {
    $o_oid = $data_order['oid'];
    $o_poid = $data_order['poid'];
    $o_provider = $data_order['provider'];
  if ($o_provider == "MANUAL") {
    echo "Pesanan Manual<br />";
  } else {
    
    $check_provider = mysqli_query($db, "SELECT * FROM provider WHERE code = 'MEDAN'");
    $data_provider = mysqli_fetch_assoc($check_provider);
    
    $p_apikey = $data_provider['api_key'];
    $p_link = $data_provider['link'];
    
    if ($o_provider !== "MANUAL") {
      $api_postdata = "api_key=kXsiDmQTVnLMfC6iGodf&sosial=status&trx=$o_poid";
    } else {
      die("System error!");
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://medan-smm.co.id/api/sosial.php");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $api_postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $chresult = curl_exec($ch);
    curl_close($ch);
    $json_result = json_decode($chresult, true);
    
    if ($o_provider !== "MANUAL") {
      $u_status = $json_result['data']['status'];
      $u_start = $json_result['data']['start_count'];
      $u_remains = $json_result['data']['remains'];
    }
    
    $update_order = mysqli_query($db, "UPDATE orders SET status = '$u_status', start_count = '$u_start', remains = '$u_remains' WHERE oid = '$o_oid'");
    if ($update_order == TRUE) {
      echo "===============<br>Status Sosmed Berhasil Di Update<br><br>ID Provider : $o_oid<br>Status : $u_status<br>Start : $u_start<br>Remains : $u_remains<br>===============<br>";
    } else {
      echo "Gagal Menampilkan Data Status Sosmed.";
    }
  }
  }
}