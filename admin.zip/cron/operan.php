<?php
session_start();
require("../mainconfig.php");
$page_type = "Menu Operan";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = $db->query("SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = $check_user->fetch_array(MYSQLI_ASSOC);
	if ($check_user->num_rows == 0) {
		header("Location: ".$site_config['base_url']."user/logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$site_config['base_url']."user/logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$site_config['base_url']);
	} 

include("../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card-box">
                            <h3 class="text-center"> Oper Disini Gan</h3><br>
                            <form method="POST">
                                <div class="form-group row">
    								<label class="col-md-2 control-label">Insert Query</label>
    								<div class="col-md-10">
    									<select class="form-control" id="category" name="opsi">
											<option value="0">Pilih salah satu...</option>											
											<option value="3">Get Service Pulsa Diamond Pedia</option>
											<option value="6">Get Kategori Pulsa Diamond Pedia</option>
											<option value="5">Hapus Service Pulsa</option>
											<option value="4">Hapus Service Sosmed 1</option>
											<option value="15">Hapus Service Sosmed 2</option>
											<option value="9">Hapus Kategori Pulsa</option>
										</select>
    								</div>
    							</div>
        						<div class="form-group row">
                                    <div class="offset-lg-2 col-lg-8">
                                        <button type="reset" class="btn btn-secondary btn-bordred"><i class="fa fa-refresh"></i> Reset </button>  
                                        <button type="submit" class="btn btn-secondary btn-bordred" name="submit"><i class="fa fa-send"></i> Submit </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="card-box">
                            <h3 class="text-center">Result : </h3>
                                <?php
                Class Ez{
    
    public static $api_id = 5198;
    
    public static $apikey_irvan = 'cc97b2-46306f-b276f9-2fa443-38bf36';
    
    public static $apikey_diaomond  = 'LVtKdIpy3iaKCsQblGCc';
    
    public static $apikey_medan  = 'cc97b2-46306f-b276f9-2fa443-38bf36';
    
    public function get_service_irvan(){
        
        $data = ['api_id'=>self::$api_id,'api_key'=>self::$apikey_irvan];
        $ariez = Ez::curl('https://api.irvan.co.id/api/services',$data);
        $hasil = $ariez['exec'];
        
        return $hasil->data;    
    }
    
    public function get_service_cat_irvan(){
        
        $data = ['api_id'=>self::$api_id,'api_key'=>self::$apikey_irvan];
        $ariez = Ez::curl('https://medanpedia.co.id/api/services',$data);
        $hasil = $ariez['exec'];
        
        return $hasil->data;    
    }
    
    public function get_service_medan(){
            
        $data = ['api_key'=>self::$apikey_diaomond];
        $ariez = Ez::curl('https://serverh2h.com/service/social',$data);
        
        return $ariez['exec'];  
    }
    
    public function get_service_cat_diamond(){
         $data = ['api_key'=>self::$apikey_diaomond];
        $ariez = Ez::curl('https://serverh2h.com/service/sosial',$data);
        
        return $ariez['exec'];  
    }
    
    public function get_service_pulsa_diamond(){
         $data = ['api_key'=>self::$apikey_diaomond];
        $ariez = Ez::curl('https://serverh2h.com/service/pulsa',$data);
        
        return $ariez['exec'];  
    }
    
    public function get_service_cat_medan(){
        
        $data = ['api_key'=>self::$apikey_medan];
        $ariez = Ez::curl('https://api.irvankede-smm.co.id/category',$data);
        $hasil = $ariez['exec'];
        
        return $hasil->data; 
    }
     public function get_service_pulsa_cat_diamond(){
         $data = ['api_key'=>self::$apikey_diaomond];
        $ariez = Ez::curl('https://serverh2h.com/service/pulsa',$data);
        
        return $ariez['exec'];  
    }
    
    private static function curl($end_point = null ,$postdata = null){
        $ch = curl_init($end_point);
        curl_setopt($ch ,CURLOPT_RETURNTRANSFER,TRUE);
        curl_setopt($ch ,CURLOPT_FOLLOWLOCATION,TRUE);
        curl_setopt($ch ,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch ,CURLOPT_SSL_VERIFYHOST,FALSE);
        curl_setopt($ch ,CURLOPT_POSTFIELDS,http_build_query($postdata));
        $exe = json_decode(curl_exec($ch));
        $info = json_decode(curl_getinfo($ch));
        $error = json_decode(curl_error($ch));
        curl_close($ch);
        return [
            'exec'=>$exe,
            'info'=>$info,
            'error'=>$error,
            ];
        
    }
    
    
}

if(isset($_POST['submit'])){
$x = new Ez;
if($_POST['opsi'] == '1'){
    $service_irvan = $x->get_service_irvan();
    #insert_irv
    foreach($service_irvan as $data ){
        $id = $data->id;
        $category = $data->category;
        $name = $data->name;
        $price = $data->price;
        $min = $data->min;
        $max = $data->max;
        $note = $data->description;
        $rate = $price / 0.80; 
        $rate_asli = $rate+7000;
        
        $cek = $db->query("SELECT * FROM services WHERE sid = '$id' AND provider = 'MP'");
        if(mysqli_num_rows($cek) == 1){
            echo 'DATA ID '.$id.' SUDAH DIMASUKKAN <br \>';
        }else{
        
            $insert = $db->query("INSERT INTO services (sid,category,service,note, min, max, price, status, pid, provider) VALUES ('$sid','$category','$service','$note','$min_order','$max_order','$rate_asli','Active','$sid','MP')");
            if($insert == TRUE){
            echo "<font color='green'><b>Layanan Berhasil Di Tambahkan<br><br>Kategori : $category<br>ID Provider : $sid<br>Nama Layanan : $service<br>Type Server : $server<br>Minimal Pesan : $min_order<br>Maksimal Pesan : $max_order<br>Harga/1000 : $rate_asli<br>Note : $note<br \>";
            }else{
            echo "GAGAL MEMASUKAN DATA <br \>";
            }
        }
    }
}else if($_POST['opsi'] == '2'){
    $service_medan = $x->get_service_medan();
    
    #insert_diamond
    foreach($service_medan as $data ){
        $id = $data->id;  
        $category = $data->category;
        $name = $data->service;
        $price = $data->price;
        $min = $data->min;
        $max = $data->max;
        $note = $data->description;
        $rate = $price+10000;
        $cek = $db->query("SELECT * FROM services WHERE sid = '$id' AND provider='MEDAN'");
        if(mysqli_num_rows($cek) == 1){
            echo 'DATA ID '.$id.' SUDAH DIMASUKKAN <br \>';
        }else{
            $insert = $db->query("INSERT INTO services (sid,category,service,note,min,max,price,status,pid,provider) VALUES ('$id','$category','$name','$note','$min','$max','$price','Active','$id','MEDAN')");
            if($insert == TRUE){
            echo "<font color='green'><b>(+) SUKSES INSERT</b></font> >  ID = ".$id." , SERVICE = ".$name." PRICE = ".$price." <br \>";
            }else{
            echo "GAGAL MEMASUKAN DATA <br \>";
            }
        }
    }
}else if($_POST['opsi'] == '8'){
    $delete_service_all = $db->query("DELETE FROM service_cat");
    if($delete_service_all){
        echo "<font color='green'><b>(-) SUKSES DELETE CATEGORY SOSMED";
    }    
}else if($_POST['opsi'] == '4'){
    $delete_service_all = $db->query("DELETE FROM services");
    if($delete_service_all){
        echo "<font color='green'><b>(-) SUKSES DELETE SERVICE SOSMED1";
    }
}else if($_POST['opsi'] == '9'){
    $delete_service_all = $db->query("DELETE FROM service_pulsa_cat");
    if($delete_service_all){
        echo "<font color='green'><b>(-) SUKSES DELETE CATEGORY PULSA";
    }    
}else if($_POST['opsi'] == '5'){
    $delete_service_all = $db->query("DELETE FROM services_pulsa");
    if($delete_service_all){
        echo "<font color='green'><b>(-) SUKSES DELETE SERVICE PULSA";
    }
}else if($_POST['opsi'] == '15'){
    $delete_service_all = $db->query("DELETE FROM services2");
    if($delete_service_all){
        echo "<font color='green'><b>(-) SUKSES DELETE SERVICE SOSMED2";
    }
    
}else if($_POST['opsi'] == '3'){
      $service_diamond = $x->get_service_pulsa_diamond();
    
    #insert_diamond
    foreach($service_diamond as $data ){
        $id = $data->id;  
        $oprator = $data->oprator;
        $type = $data->tipe;
        $price = $data->price;
        $name = $data->name;
        $status = $data->status;
        $rate = $price / 1; 
        $rate_asli = $rate+900; 
        
        $cek = $db->query("SELECT * FROM services_pulsa WHERE sid = '$id' AND provider='DP-PULSA'");
        if(mysqli_num_rows($cek) == 1){
            echo 'DATA ID '.$id.' SUDAH DIMASUKKAN <br \>';
        }else{
            $insert = $db->query("INSERT INTO services_pulsa (sid,type,category,service,price,status,pid,provider) VALUES ('$id','$type','$oprator','$name','$rate_asli','Active','$id','DP-PULSA')");
            if($insert == TRUE){
            echo "<font color='green'><b>(+) SUKSES INSERT</b></font> >  ID = ".$id." <br> SERVICE = ".$name." <br> PRICE = ".$rate_asli." <br \>";
            }else{
            echo "GAGAL MEMASUKAN DATA <br \>";
            }
        }
    }
}else if($_POST['opsi'] == '6'){
      $service_diamond = $x->get_service_pulsa_cat_diamond();
    
    #insert_diamond
    foreach($service_diamond as $data ){
        $id = $data->id;  
        $oprator = $data->oprator;
        $type = $data->tipe;
        $price = $data->price;
        $name = $data->name;
        $status = $data->status;
        $rate = $price+251;
        
        $cek = $db->query("SELECT * FROM service_pulsa_cat WHERE name = '$oprator'");
        if(mysqli_num_rows($cek) == 1){
            echo 'DATA ID '.$oprator.' SUDAH DIMASUKKAN <br \>';
        }else{
            $insert = $db->query("INSERT INTO service_pulsa_cat (id,name,code,type) VALUES (NULL,'$oprator','$oprator','$type')");
            if($insert == TRUE){
            echo "<font color='green'><b>(+) SUKSES INSERT</b></font> >  Name = ".$oprator." , Code = ".$oprator." Type = ".$type." <br \>";
            }else{
            echo "GAGAL MEMASUKAN DATA <br \>";
            }
        }
    }    
}else if($_POST['opsi'] == '7'){
    $service_irvan = $x->get_service_cat_irvan();
    #insert_irv
    foreach($service_irvan as $data ){
        $id = $data->id;
        $category = $data->category;
        $name = $data->name;
        $price = $data->price;
        $min = $data->min;
        $max = $data->max;
        $note = $data->note;
        $rate = $price+8000;
        
        $cek = $db->query("SELECT * FROM service_cat2 WHERE name = '$category'");
        if(mysqli_num_rows($cek) == 1){
            echo 'DATA ID '.$id.' SUDAH DIMASUKKAN <br \>';
        }else{
        
            $insert = $db->query("INSERT INTO service_cat2 (id,name,code) VALUES (NULL,'$category','$category')");
            if($insert == TRUE){
            echo "<font color='green'><b>(+) SUKSES INSERT</b></font> >  Name = ".$category." , Code = ".$category." <br \>";
            }else{
            echo "GAGAL MEMASUKAN DATA <br \>";
            }
        }
    }    
}else if($_POST['opsi'] == '11'){
    $service_medan = $x->get_service_cat_medan();
    #insert_irv
    foreach($service_medan as $data ){
        $id = $data->id;
        $category = $data->category;
        $name = $data->name;
        $price = $data->price;
        $min = $data->min;
        $max = $data->max;
        $note = $data->note;
        $rate = $price+8000;
        
        $cek = $db->query("SELECT * FROM service_cat WHERE name = '$category'");
        if(mysqli_num_rows($cek) == 1){
            echo 'DATA ID '.$id.' SUDAH DIMASUKKAN <br \>';
        }else{
        
            $insert = $db->query("INSERT INTO service_cat (id,name,code) VALUES (NULL,'$category','$category')");
            if($insert == TRUE){
            echo "<font color='green'><b>(+) SUKSES INSERT</b></font> >  Name = ".$category." , Code = ".$category." <br \>";
            }else{
            echo "GAGAL MEMASUKAN DATA <br \>";
            }
        }
    }    
}

}
?>

                        </div>
                    </div>
                </div>
                
<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$site_config['base_url']);
}
?>