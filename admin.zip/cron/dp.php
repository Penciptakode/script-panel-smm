<?php
require_once("../mainconfig.php");
$postdata = "key=6f818c9748816e8c0f5670b64bb8a641124588b04797133640ba9ab29b868073&action=services";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.atlantic-pedia.co.id/api/pulsa"); // GANTI LINK NYA JANCOK !
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$chresult = curl_exec($ch);
echo $chresult;
curl_close($ch);
$json_result = json_decode($chresult, true);
$indeks=0; 
$i = 1;
// get data service
while($indeks < count($json_result)){ 
$oprator = $json_result[$indeks][category];
$name = $json_result[$indeks][name];
$type = $json_result[$indeks][type];
$id = $json_result[$indeks][code];
$price = $json_result[$indeks][price];
$status = $json_result[$indeks][status];

$indeks++;
$i++;
// end get data service
// setting price
$rate = $price / 0.80;
$rate_asli = $rate + 1300;
// setting price


mysqli_query($db, "INSERT INTO services_pulsa (id , sid, type, category, service, price, status, pid, provider) VALUES (NULL, , '$id', '$sid', '$type', '$oprator', '$name', '$rate_asli', 'Active', '$id', 'DP')");
;
}

?>