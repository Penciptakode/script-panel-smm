<?php
   require_once("../mainconfig.php");

$CallDB = mysqli_query($db, "SELECT * FROM cek_akun WHERE provider = 'BM-AKUN'");

if (mysqli_num_rows($CallDB) == 0) {
	die("Data Informasi Akun Tidak Ditemukan.");
} else {
	while($ThisData = $CallDB->fetch_assoc()) {
		$Provider = $ThisData['provider'];
		if (mysqli_query($db, "DELETE FROM cek_akun WHERE provider = '$Provider'") == true) {
			echo " Data Informasi Akun Berhasil Dihapus<br />";
    	} else {
			echo "Gagal Menampilkan Data Informasi Akun.";
		}
	}
}
?>