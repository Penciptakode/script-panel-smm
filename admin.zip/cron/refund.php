<?php
require("../mainconfig.php");

$check_order = mysqli_query($db, "SELECT * FROM orders WHERE status IN ('Error','Partial') AND refund = '0'");

if (mysqli_num_rows($check_order) == 0) {
	die("Pesanan Bersatatus Error Atau Partial Tidak Ditemukan.");
} else {
	while($data_order = mysqli_fetch_assoc($check_order)) {
		$o_oid = $data_order['oid'];
		$u_remains = $data_order['remains'];
		
		    $priceone = $data_order['price'] / $data_order['quantity'];
		    $refund = $priceone * $u_remains;
		    $buyer = $data_order['user'];
		    if($u_remains == 0) {
		        $refund = $data_order['price'];
		    }
		    
			$update_user = mysqli_query($db, "UPDATE users SET balance_used = balance_used-$refund WHERE username = '$buyer'");
			$update_user = mysqli_query($db, "UPDATE users SET balance = balance+$refund WHERE username = '$buyer'");
			$update_order = mysqli_query($db, "INSERT INTO balance_history (id, username, action, quantity, msg, date, time) VALUES ('', '$buyer', 'Add Balance', '$refund', 'Pengembalian Dana Dari Pemesanan Pada Fitur Sosial Media Akibat Status Pesanan Error/Partial Dengan ID Pesanan $o_oid', '$date', '$time')");
    		$update_order = mysqli_query($db, "UPDATE orders SET refund = '1'  WHERE oid = '$o_oid'");
    		if ($update_order == TRUE) {
    			echo "===============<br>Pengembalian Dana<br><br>Rp $refund<br>ID Provider : $o_oid<br>===============<br>";
    		} else {
    			echo "Gagal Menampilkan Data Pengembalian Dana.";
    		}
	}
}