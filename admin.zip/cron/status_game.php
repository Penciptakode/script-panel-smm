<?php
require("../mainconfig.php");

$check_order = mysqli_query($db, "SELECT * FROM orders_game WHERE status IN ('','Pending','Processing') AND provider = 'BM-GAME'");

if (mysqli_num_rows($check_order) == 0) {
  die("Pesanan Pending Tidak Ditemukan.");
} else {
  while($data_order = mysqli_fetch_assoc($check_order)) {
    $o_oid = $data_order['oid'];
    $o_poid = $data_order['poid'];
    $o_provider = $data_order['provider'];
  if ($o_provider == "MANUAL") {
    echo "Pesanan Manual<br />";
  } else {
    
    $check_provider = mysqli_query($db, "SELECT * FROM provider WHERE code = 'BM-GAME'");
    $data_provider = mysqli_fetch_assoc($check_provider);
    
    $p_apikey = $data_provider['api_key'];
    $p_link = $data_provider['link'];
    
    if ($o_provider !== "MANUAL") {
      $api_postdata = "api_key=$p_apikey&action=status&id=$o_poid";
    } else {
      die("System error!");
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://brebes-media.id/api/game");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $api_postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $chresult = curl_exec($ch);
    curl_close($ch);
    $json_result = json_decode($chresult, true);

    if ($o_provider !== "MANUAL") {
      $u_status = $json_result['data']['status'];
      $keterangan = $json_result['data']['catatan'];
    
    $update_order = mysqli_query($db, "UPDATE orders_game SET status = '$u_status' WHERE oid = '$o_oid'");
    $update_order = mysqli_query($db, "UPDATE orders_game SET catatan = '$keterangan' WHERE oid = '$o_oid'");
    if ($update_order == TRUE)
      echo "===============<br>Status Game Berhasil Di Update<br><br>ID Provider : $o_oid<br>Status : $u_status<br>Keterangan : $keterangan<br>===============<br>";
    } else {
      echo "Gagal Menampilkan Data Status Game.";
    }
  }
  }
}