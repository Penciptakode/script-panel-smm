<?php
   require_once("../mainconfig.php");
       
$api_postdata = "api_key=kXsiDmQTVnLMfC6iGodf&sosial=service";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://medan-smm.co.id/api/sosial.php");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $api_postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $chresult = curl_exec($ch);
    curl_close($ch);
    $json_result = json_decode($chresult, true);

$indeks=0; 
$i = 1;
// get data service
while($indeks < count($json_result['data'])){ 
    
$category =$json_result['data'][$indeks]['category'];
$sid =$json_result['data'][$indeks]['sid'];
$service = $json_result['data'][$indeks]['service'];
$min_order =$json_result['data'][$indeks]['min'];
$max_order = $json_result['data'][$indeks]['max'];
$price = $json_result['data'][$indeks]['price'];
$note = $json_result['data'][$indeks]['note'];
$indeks++; 
$i++;
// end get data service 
// setting price 
$rate = $price / 1; 
$rate_asli = $rate + 1000; //setting penambahan harga
// setting price 
 $check_services = mysqli_query($db, "SELECT * FROM services WHERE sid = '$sid' AND provider='MEDAN'");
            $data_services = mysqli_fetch_assoc($check_orders);
        if(mysqli_num_rows($check_services) > 0) {
            echo "Layanan Sudah Ada Di Database => $service | $sid \n <br />";
        } else {
            
$insert=mysqli_query($db, "INSERT INTO services (sid,category,service,note, min, max, price, status, pid, provider) VALUES ('$sid','$category','$service ZP','$note','$min_order','$max_order','$rate_asli','Active','$sid','MEDAN')");//Memasukan Kepada Database (OPTIONAL)
if($insert == TRUE){
echo"===============<br>Layanan Berhasil Di Tambahkan<br><br>Kategori : $category<br>ID Provider : $sid<br>Nama Layanan : $service<br>Minimal Pesan : $min_order<br>Maksimal Pesan : $max_order<br>Harga/1000 : $rate_asli<br>Note : $note<br>===============<br>";
}else{
    echo "Gagal Menampilkan Data Layanan Sosmed";
    
}
}
}
?>