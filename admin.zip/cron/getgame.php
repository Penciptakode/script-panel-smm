<?php
   require_once("../mainconfig.php");
       
$api_postdata = "api_key=MASUKAN_API_KEY_ANDA&action=layanan";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://brebes-media.id/api/game");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $api_postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $chresult = curl_exec($ch);
    curl_close($ch);
    $json_result = json_decode($chresult, true);

$indeks=0; 
$i = 1;
// get data service
while($indeks < count($json_result['data'])){ 
    
$sid =$json_result['data'][$indeks]['sid'];
$category=$json_result['data'][$indeks]['kategori'];
$service = $json_result['data'][$indeks]['layanan'];
$price = $json_result['data'][$indeks]['harga'];
$status = $json_result['data'][$indeks]['status'];
$indeks++; 
$i++;
// end get data service 
// setting price 
$rate = $price; 
$rate_asli = $rate + 300; //setting penambahan harga
// setting price 

         
     $check_services = mysqli_query($db, "SELECT * FROM services_game WHERE pid = '$sid' AND provider='BM-GAME'");
            $data_services = mysqli_fetch_assoc($check_orders);
        if(mysqli_num_rows($check_services) > 0) {
            echo "Layanan Sudah Ada Di Database => $service | $id \n <br>";
        } else {
            
$insert=mysqli_query($db, "INSERT INTO services_game (id, sid, service, oprator, price, status, provider) VALUES ('$sid', '$sid' , '$service','$category', '$rate_asli','Active', 'BM-GAME')");//Memasukan Kepada Database (OPTIONAL)
if($insert == TRUE){
echo"===============<br>Layanan Game Berhasil Di Tambahkan<br><br>ID Provider : $sid<br>Kategori : $category<br>Nama Layanan : $service<br>Harga : $rate_asli<br>Status : $status<br>===============<br>";
}else{
    echo "Gagal Menampilkan Data Layanan Game";
    
}
}
}
?>