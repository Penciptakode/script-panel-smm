<?php
session_start();
require("../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] == "Member") {
		header("Location: ".$cfg_baseurl);
	} else {

if (isset($_POST['tambah'])) {
	$email = $db->real_escape_string(trim(filter($_POST['email'])));
	$username = $db->real_escape_string(trim(filter($_POST['username'])));
	$password = $db->real_escape_string(trim(filter($_POST['password'])));
	$nama = $db->real_escape_string(trim(filter($_POST['nama'])));
	$nope = $db->real_escape_string(trim(filter($_POST['no_hp'])));
	$level = trim($_POST['level']);

    $cek_username = mysqli_query($db, "SELECT * FROM users WHERE username = '$username'");
    $cek_email = mysqli_query($db, "SELECT * FROM users WHERE email = '$email'");
    $hash_pass = password_hash($password, PASSWORD_DEFAULT);
    $api_key =  random(20);

    $cek_pendaftaran= mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE level = '$level'");
    $datanya = $cek_pendaftaran->fetch_assoc();

			if (empty($email) || empty($username) || empty($password) || empty($level)) {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
			} else if ($data_user['level'] == "Member") {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.<script>swal("Gagal!", "Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.", "error");</script>';
    	    } else if ($level != "Member" AND $level != "Reseller" AND $level != "Admin" AND $level != "Agen" AND $level != "Vip") {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Input Tidak Sesuai.<script>swal("Gagal!", "Input Tidak Sesuai.", "error");</script>';
    	    } else if ($cek_email->num_rows > 0) {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> E-Mail: '.$email.' Sudah Terdaftar Dalam Database.<script>swal("Gagal!", "E-Mail Sudah Terdaftar Dalam Database.", "error");</script>';
    	    } else if ($cek_username->num_rows > 0) {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Nama Pengguna: '.$username.' Sudah Terdaftar Dalam Database.<script>swal("Gagal!", "Nama Pengguna Sudah Terdaftar Dalam Database.", "error");</script>';
			} else if ($data_user['balance'] < $datanya['harga']) {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Saldo Anda Tidak Mencukupi Untuk Melakukan Pendaftaran Akun Level '.$level.'.<script>swal("Gagal!", "Saldo Anda Tidak Mencukupi.", "error");</script>';
			} else {
			    $update_user = mysqli_query($db, "UPDATE users SET balance = balance-".$datanya['harga']." WHERE username = '$sess_username'");
			    if ($update_user == TRUE) {
                $insert_user = mysqli_query($db, "INSERT INTO users (nama, username, password, balance, level, registered, status, api_key, email, uplink, no_hp) VALUES ('$nama', '$username', '$hash_pass', '".$datanya['bonus']."', '$level', '$date', 'Active', '$api_key', '$email', '$sess_username', '$nope')");
                $insert_user = mysqli_query($db, "INSERT INTO balance_history (username, action, quantity, msg, date, time) VALUES ('$sess_username', 'Cut Balance', '".$datanya['harga']."' , 'Saldo Dipotong Untuk Penambahan Pengguna : $username Dengan Level $level', '$date', '$time')");
                if ($insert_user == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Pengguna Baru Telah Berhasil Ditambahkan.<br /><b>Nama Pengguna:</b> $username<br /><b>Kata Sandi:</b> $password<br /><b>Level:</b> $level<br /><b>Bonus Untuk Anda</b> Rp ".number_format($post_balance,0,',','.');
				} else {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}
	}

	include("../lib/header.php");
?>
 <div class="row">
                    <div class="col-sm-6">
                        <br/>
                    </div>
                </div>	

                        <div class="row">
                            <div class="col-md-2"></div><div class="col-md-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-account-plus text-primary"></i> Tambah Pengguna</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
                                	<form class="form-horizontal" method="POST">
	                              	<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
	                              				<label class="col-md-2 control-label">Level</label>
	                              				<div class="col-md-10">
				                        		<select class="form-control" name="level" id="level" required>
				                            		<option value="">Pilih Salah Satu...</option>
				                            		<?php if ($data_user['level'] == "Member"){ ?>
                                            		<?php } else if ($data_user['level'] == "Agen"){ ?>
				                            		<option value="Member">Member</option>
                                            		<?php } else if ($data_user['level'] == "Reseller") { ?>
                                            		<option value="Member">Member</option>
				                            		<option value="Agen">Agen</option>
                                            		<?php } else if ($data_user['level'] == "Admin") { ?>
                                            		<option value="Member">Member</option>
				                            		<option value="Agen">Agen</option>
				                            		<option value="Reseller">Reseller</option>
				                            		<?php } else if ($data_user['level'] == "Vip") { ?>
                                            		<option value="Member">Member</option>
				                            		<option value="Agen">Agen</option>
				                            		<option value="Reseller">Reseller</option>
				                            		<option value="Admin">Admin</option>
                                            		<?php } else if ($data_user['level'] == "Developers") { ?>
                                            		<option value="Member">Member</option>
				                            		<option value="Agen">Agen</option>
				                            		<option value="Reseller">Reseller</option> 
				                            		<option value="Admin">Admin</option> 
				                            		<option value="Vip">Vip</option>
				                            		<?php } ?>
				                        		</select>
				                        	</div>
				                        	</div>
											<div id="catatan">
											</div>	
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Lengkap</label>
												<div class="col-md-10">
													<input type="text" name="nama" class="form-control" placeholder="Nama Lengkap">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">E-Mail</label>
												<div class="col-md-10">
													<input type="email" name="email" class="form-control" placeholder="E-Mail Aktif">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Pengguna</label>
												<div class="col-md-10">
													<input type="text" name="username" class="form-control" placeholder="Nama Pengguna">
												</div>
											</div>
											
											<div class="form-group"><div class="form-group">
												<label class="col-md-2 control-label">Nomor HP</label>
												<div class="col-md-10">
													<input type="number" name="no_hp" class="form-control" placeholder="08">
													<small class="text-danger">*Masukan Nomor HP Diawali Dengan 08</span></small>
												</div>
											</div>
												<label class="col-md-2 control-label">Kata Sandi</label>
												<div class="col-md-10">
													<input type="text" name="password" class="form-control" placeholder="Kata Sandi">
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
												<button type="reset" class="btn btn-danger waves-effect w-md waves-light">Ulangi</button>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="tambah">Tambah</button>
											</div>
										</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
						<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript">
$(document).ready(function() {
	$("#level").change(function() {
		var level = $("#level").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/tambah-pengguna.php',
			data: 'level=' + level,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#catatan").html(msg);
			}
		});
	});
});
	</script>			    
<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>