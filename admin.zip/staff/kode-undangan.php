<?php
session_start();
require("../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] == "Member") {
		header("Location: ".$cfg_baseurl);
	} else {
	    
		if (isset($_POST['buat'])) {
            $level = $db->real_escape_string(trim(filter($_POST['level'])));
            
            $code = random(7);
            
            $cek_pendaftaran= mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE level = '$level'");
            $datanya = $cek_pendaftaran->fetch_assoc();

			if (empty($level)) {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
			} else if ($data_user['level'] == "Member") {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.<script>swal("Gagal!", "Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.", "error");</script>';
			} else if ($data_user['balance'] < $datanya['harga']) {
				$msg_type = "error";
				$msg_content = '<b>Gagal:</b> Saldo Anda Tidak Mencukupi Untuk Melakukan Buat Kode Undangan.<script>swal("Gagal!", "Saldo Anda Tidak Mencukupi.", "error");</script>';
			} else {
			    $update_user = mysqli_query($db, "UPDATE users SET balance = balance-".$datanya['harga']." WHERE username = '$sess_username'");
			    if ($update_user == TRUE) {
				$insert_code = mysqli_query($db, "INSERT INTO kode_undangan (level, uplink, code, balance, status, date, time) VALUES ('$level', '$sess_username', '$code', '".$datanya['bonus']."', 'Active', '$date', '$time')");
				$insert_code = mysqli_query($db, "INSERT INTO balance_history (username, action, quantity, msg, date, time) VALUES ('$sess_username', 'Cut Balance', '".$datanya['harga']."' , 'Saldo Dipotong Untuk Buat Kode Undangan Baru Dengan Level $level', '$date', '$time')");
				if ($insert_code == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Kode Undangan Berhasil Dibuat.<br /><b>Kode undangan:</b> $code<br />";
				} else {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}
	}

	include("../lib/header.php");
?>
 <div class="row">
                    <div class="col-sm-6">
                        <br/>
                    </div>
                </div>	

                        <div class="row">
                            <div class="col-md-2"></div><div class="col-md-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-key mr-1 text-primary"></i> Kode Undangan</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
	                              				<label class="col-md-2 control-label">Level</label>
	                              				<div class="col-md-10">
				                        		<select class="form-control" name="level" id="level" required>
				                            		<option value="">Pilih Salah Satu...</option>
				                            		<?php if ($data_user['level'] == "Member"){ ?>
                                            		<?php } else if ($data_user['level'] == "Agen"){ ?>
				                            		<option value="Member">Member</option>
                                            		<?php } else if ($data_user['level'] == "Reseller") { ?>
                                            		<option value="Member">Member</option>
				                            		<option value="Agen">Agen</option>
                                            		<?php } else if ($data_user['level'] == "Admin") { ?>
                                            		<option value="Member">Member</option>
				                            		<option value="Agen">Agen</option>
				                            		<option value="Reseller">Reseller</option>
                                            		<?php } else if ($data_user['level'] == "Developers") { ?>
                                            		<option value="Member">Member</option>
				                            		<option value="Agen">Agen</option>
				                            		<option value="Reseller">Reseller</option> 
				                            		<option value="Admin">Admin</option> 
				                            		<?php } ?>
				                        		    </select>
												</div>
											</div>
											<div id="catatan">
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
												<button type="reset" class="btn btn-danger waves-effect w-md waves-light">Ulangi</button>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="buat">Buat</button>
											</div>
										</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
						
                        <div class="row">
                            <div class="col-md-2"></div><div class="col-md-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-history text-primary"></i> Data Kode Undangan Yang Dibuat Oleh Anda</h4>
                                    </div>
                                    <div class="card-body">
                                        <form>
                                            <div class="row">
                                                <div class="form-group col-lg-4">
                                                    <label>Tampilkan Beberapa</label>
                                                    <select class="form-control" name="tampil">
                                                        <option value="10">Default</option>
                                                        <option value="50">50</option>
                                                        <option value="100">100</option>
                                                        <option value="250">250</option>
                                                    </select>
                                                </div>                                                
                                                <div class="form-group col-lg-4">
                                                    <label>Cari Kode Undangan</label>
                                                    <input type="text" class="form-control" name="aksi" placeholder="Cari Kode Undangan">
                                                </div>                                
                                                <div class="form-group col-lg-4">
                                                    <label>Submit</label>
                                                    <button type="submit" class="btn btn-block btn-primary">Filter</button>
                                                </div>
                                            </div>
                                        </form>
										<div class="table-responsive">
											<table id="datatable-responsive" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
													    <th>No</th>
														<th>Tanggal & Waktu</th>
														<th>Kode</th>
														<th>Level</th>
														<th>Saldo</th>
														<th>Status</th>
													</tr>
												</thead>
												<tbody>
<?php 
// start paging config
$no=1;
if (isset($_GET['tampil'])) {
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
    $cari_aksi = $db->real_escape_string(filter($_GET['aksi']));

    $cek_riwayat = "SELECT * FROM kode_undangan WHERE code LIKE '%$cari_aksi%' AND uplink = '$sess_username' ORDER BY id DESC"; // edit
} else {
    $cek_riwayat = "SELECT * FROM kode_undangan WHERE uplink = '$sess_username' ORDER BY id DESC"; // edit
}
if (isset($_GET['tampil'])) {
$cari_urut = $db->real_escape_string(filter($_GET['tampil']));
$records_per_page = $cari_urut; // edit
} else {
    $records_per_page = 10; // edit
}

$starting_position = 0;
if(isset($_GET["halaman"])) {
    $starting_position = ($db->real_escape_string(filter($_GET["halaman"]))-1) * $records_per_page;
}
$new_query = $cek_riwayat." LIMIT $starting_position, $records_per_page";
$new_query = $db->query($new_query);
$no = $starting_position+1;
// end paging config
while ($data_riwayat = $new_query->fetch_assoc()) {
    if ($data_riwayat['status'] == "Active") {
        $label = "success";
    } else if ($data_riwayat['status'] == "Already Used") {
        $label = "danger";
    }
?>
													<tr>
														<th scope="row"><?php echo $no++ ?></th>
														<td><?php echo TanggalIndonesia($data_riwayat['date']); ?>, <?php echo $data_riwayat['time']; ?></td>
														<td><?php echo $data_riwayat['code']; ?></label></td>
														<td><?php echo $data_riwayat['level']; ?></td>
														<td><?php echo $data_riwayat['balance']; ?></td>
														<td><label class="btn btn-xs btn-<?php echo $label; ?>"><?php if($data_riwayat['status'] == "Active") { ?>Aktif</i></span><?php } else { ?>Sudah Digunakan</span><?php } ?></label></td>
													</tr>
												<?php
												}
												?>
												</tbody>
											</table>
                            </div>
                            <br>
                                        <ul class="pagination pagination-split">
<?php
// start paging link
if (isset($_GET['tampil'])) {
$cari_urut = $db->real_escape_string(filter($_GET['tampil']));
} else {
$cari_urut =  10;
}  
if (isset($_GET['tampil'])) {
    $cari_aksi = $db->real_escape_string(filter($_GET['aksi']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
} else {
    $self = $_SERVER['PHP_SELF'];
}
$cek_riwayat = $db->query($cek_riwayat);
$total_records = mysqli_num_rows($cek_riwayat);
echo "<li class='disabled page-item'><a class='page-link' href='#'>Total Data : ".$total_records."</a></li>";
if($total_records > 0) {
    $total_pages = ceil($total_records/$records_per_page);
    $current_page = 1;
    if(isset($_GET["halaman"])) {
        $current_page = $db->real_escape_string(filter($_GET["halaman"]));
        if ($current_page < 1) {
            $current_page = 1;
        }
    }
    if($current_page > 1) {
        $previous = $current_page-1;
    if (isset($_GET['tampil'])) {
    $cari_aksi = $db->real_escape_string(filter($_GET['aksi']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=1&tampil=".$cari_urut."&aksi=".$cari_aksi."'><<</a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$previous."&tampil=".$cari_urut."&aksi=".$cari_aksi."'><</a></li>";
} else {
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=1'><<</a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$previous."'><</a></li>";
}
}
    // limit page
    $limit_page = $current_page+3;
    $limit_show_link = $total_pages-$limit_page;
    if ($limit_show_link < 0) {
        $limit_show_link2 = $limit_show_link*2;
        $limit_link = $limit_show_link - $limit_show_link2;
        $limit_link = 3 - $limit_link;
    } else {
        $limit_link = 3;
    }
    $limit_page = $current_page+$limit_link;
    // end limit page
    // start page
    if ($current_page == 1) {
        $start_page = 1;
    } else if ($current_page > 1) {
        if ($current_page < 4) {
            $min_page  = $current_page-1;
        } else {
            $min_page  = 3;
        }
        $start_page = $current_page-$min_page;
    } else {
        $start_page = $current_page;
    }
    // end start page
    for($i=$start_page; $i<=$limit_page; $i++) {
    if (isset($_GET['tampil'])) {
    $cari_aksi = $db->real_escape_string(filter($_GET['aksi']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
        if($i==$current_page) {
            echo "<li class='active page-item'><a class='page-link' href='#'>".$i."</a></li>";
        } else {
            echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$i."&tampil=".$cari_urut."&aksi=".$cari_aksi."'>".$i."</a></li>";
        }
    } else {
        if($i==$current_page) {
            echo "<li class='active page-item'><a class='page-link' href='#'>".$i."</a></li>";
        } else {
            echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$i."'>".$i."</a></li>";
        }        
    }
    }
    if($current_page!=$total_pages) {
        $next = $current_page+1;
    if (isset($_GET['tampil'])) {
    $cari_aksi = $db->real_escape_string(filter($_GET['aksi']));
    $cari_urut = $db->real_escape_string(filter($_GET['tampil']));
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$next."&tampil=".$cari_urut."&aksi=".$cari_aksi."'>></i></a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$total_pages."&tampil=".$cari_urut."&aksi=".$cari_aksi."'>>></a></li>";
} else {
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$next."'>></a></li>";
        echo "<li class='page-item'><a class='page-link' href='".$self."?halaman=".$total_pages."'>>></a></li>";
    }
}
}
// end paging link
?>
                                        </ul>
                        </div>
                    </div>
                </div>
            </div>
						<!-- end row -->
						<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript">
$(document).ready(function() {
	$("#level").change(function() {
		var level = $("#level").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/kode-undangan.php',
			data: 'level=' + level,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#catatan").html(msg);
			}
		});
	});
});
	</script>			    
<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>