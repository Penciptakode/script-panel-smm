<?php
session_start();
require_once("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	include("../lib/header.php");
	$msg_type = "nothing";
	if (isset($_POST['deposit'])) {
	    $jumlah = $db->real_escape_string(trim(filter($_POST['jumlah'])));
	    $payment = $db->real_escape_string(trim(filter($_POST['payment'])));
	    $nomor_pengirim = $db->real_escape_string(trim(filter($_POST['nomor_pengirim'])));
	    $code = random_number(3).random_number(4);
	    $username = $sess_username;

	    $check_data = mysqli_query($db, "SELECT * FROM deposit_method WHERE id = '$payment' AND status = 'ON' AND name = 'Transfer Bank' ORDER BY id ASC");
		$data_depo = mysqli_fetch_assoc($check_data);

	    $send = $data_depo['send'];

	    $jumlah = $db->real_escape_string($jumlah);
	    $qcheckd= mysqli_query($db,"SELECT * FROM deposit WHERE username = '$username' AND status = 'Pending'");
	    $countd = mysqli_num_rows($qcheckd);

	    $qcs = mysqli_query($db,"SELECT * FROM deposit_method WHERE id = '$payment'");
	    $cs = mysqli_num_rows($qcs);
	    $rows = mysqli_fetch_array($qcs);
	    if (!$jumlah || !$nomor_pengirim) {
	        $msg_type = "error";
	        $msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
	    } else if ($countd >= 1) {
	        $msg_type = "error";
	        $msg_content = '<b>Gagal:</b> Kamu Masih Memiliki 1 Request Deposit Yang Masih Pending, Harap Lakukan Pembayaran !!..<script>swal("Gagal!", "Kamu Masih Memiliki 1 Request Deposit Yang Masih Pending, Harap Lakukan Pembayaran !!.", "error");</script>';
	    } else if ($qcs == 0) {
	        $msg_type = "error";
	        $msg_content = '<b>Gagal:</b> Metode Deposit Tidak Ditemukan.<script>swal("Gagal!", "Metode Deposit Tidak Ditemukan.", "error");</script>';
	    } else if ($jumlah < $data_depo['minimal']) {
	        $msg_type = "error";
	        $msg_content = '<b>Gagal:</b> Minimal Deposit Saldo Adalah Rp '.$data_depo['minimal'].'.<script>swal("Gagal!", "Minimal Deposit Saldo Adalah Rp '.$data_depo['minimal'].'", "error");</script>';
	    } else {
	        $deponya = $data_depo['payment'];
			if ($data_depo['provider'] == 'OVO' AND $deponya == 'OVO CASH') {
				$jumlah = $jumlah + rand(000,999);				
			}
		    else if ($data_depo['provider'] == 'DANA' AND $deponya == 'DANA') {
				$jumlah = $jumlah + rand(000,999);				
			}
			else if ($data_depo['provider'] == 'GOPAY' AND $deponya == 'GOPAY') {
				$jumlah = $jumlah + rand(000,999);				
			}
	        $methodname = $data_depo['payment'];
	        $balance = $jumlah * $data_depo['rate'];
			$check_top = mysqli_query($db, "SELECT * FROM top_depo WHERE username = '$username'");
			$data_top = mysqli_fetch_assoc($check_top);
	        $insert = mysqli_query($db, "INSERT INTO deposit (code, username, name, provider, payment, penerima, nomor_pengirim, jumlah, saldo, status, date, time, place_from) VALUES ('$code', '$username', 'Transfer Bank', '".$data_depo['provider']."', '$methodname', '".$data_depo['send']." ".$data_depo['penerima']."', '$nomor_pengirim','$jumlah', '$balance', 'Pending', '$date', '$time', 'WEB')");
	        if ($insert == TRUE) {
	            $jumlah_2 = number_format($jumlah,0,',','.');
	            $saldo = number_format($balance,0,',','.');
	            $payment = $rows['payment'];
			if ($insert == TRUE) {
				if (mysqli_num_rows($check_top) == 0) {
				    $insert_topup = mysqli_query($db, "INSERT INTO top_depo (method, username, jumlah, total) VALUES ('Deposit', '$username', '$balance', '1')");
				} else {
				    $insert_topup = mysqli_query($db, "UPDATE top_depo SET jumlah = ".$data_top['jumlah']."+$balance, total = ".$data_top['total']."+1 WHERE username = '$username' AND method = 'Deposit'");
				}
	            $msg_type = "success";
	            $msg_content = "<b>Berhasil:</b> Permintaan Deposit Anda Berhasil.";
	        } else {
	            $msg_type = "error";
	            $msg_content = "System Error.";
				}
			}
		}
	}
	    
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>

                        <div class="row">
                            <div class="col-md-7">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-credit-card text-primary"></i> Deposit Saldo EMONEY</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?><div id="respon"></div>
										</div>
									<?php
									$check_bank = $db->query("SELECT * FROM deposit WHERE username = '$sess_username' AND status = 'Pending' ORDER BY id DESC");
									while ($data_bank = $check_bank->fetch_assoc()) {
									?>
									<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
								<script>
									var url = "<?php echo $cfg_baseurl; ?>deposit-saldo/invoice?code=<?php echo $data_bank['code']; ?>"; // URL Tujuan
									var count = 3; // dalam detik
									function countDown() {
									    if (count > 0) {
									        count--;
									        var waktu = count + 1;
									        $('#respon').html('<b>Halaman Akan Di Alihkan Ke Halaman Pembayaran Otomatis Dalam ' + waktu + ' Detik.');
									        setTimeout("countDown()", 1000);
									    } else {
									        window.location.href = url;
									    }
									}
								    countDown();
								</script>
										<?php
										}
										?>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
												<label class="col-md-2 control-label">Metode</label>
												<div class="col-md-10">
												<select class="form-control" name="payment" id="payment">
													<option value="0">Pilih Salah Satu</option>
<?php 
	$sql = mysqli_query($db,"SELECT * FROM deposit_method WHERE status = 'ON' AND name = 'Transfer Bank' ORDER BY id ASC");
if (mysqli_num_rows($sql) == 0) { ?>

													<option value="0">Metode Deposit Tidak Ditemukan!</option>
<?php } else {
	while($data = $sql->fetch_array()){ ?>
													<option value="<?php echo $data['id']; ?>"><?php echo $data['payment']; ?></option>
<?php } }   ?>
												</select>
											</div>
										</div>
										<div class="form-group">
											<label class="col-md-12 control-label">Pengirim</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fa fa-phone text-primary"></i>
                                                    </div>
                                                </div>
													<input type="number" class="form-control"  placeholder="Nomor Pengirim" id="nomor_pengirim" name="nomor_pengirim">
												</div>
											</div>
										</div>
										<div class="form-group">
											<label class="col-md-12 control-label">Jumlah Deposit</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text text-primary">
                                                            Rp
                                                    </div>
                                                </div>
													<input type="number" class="form-control" name="jumlah" placeholder="Jumlah Deposit" id="jumlah">
    												</div>
    											</div>
    										</div>
    										<div class="form-group">
    										<div class="col-md-10">
											<button type="reset" class="btn btn-danger waves-effect w-md waves-light">Ulangi</button>
											<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="deposit">Buat Deposit</button>
											    </div>
											</div>
										</form>
									</div>
								</div>
							</div>

<?php
$check_ovo = $db->query("SELECT * FROM deposit_method WHERE provider = 'OVO' AND status = 'ON' ORDER BY id DESC");
while ($data_ovo = $check_ovo->fetch_assoc()) {
?>

                            <div class="col-md-5">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-information-outline text-primary"></i> Peraturan Deposit</h4>
                                    </div>
                                    <div class="card-body">
										<ul>
<li>Pertama, Masukkan Nomor Pengirim Anda, Contoh 081234567891.</li>
<li>Kedua, Masukkan Jumlah Deposit Yang Akan Anda Transfer.</li>
<li>Ketiga, Klik Buat Deposit.</li>
<li>Keempat, Kirim Bukti Transfer Ke Admin Panel.</li>
<li>Kelima, Silahkan Tunggu 1-30 Menit Dan Saldo Anda Akan Dikonfirmasi Oleh Admin/Sistem.</li>
										</ul>
									</div>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	<?php
	}
	?>
<!-- end row -->

<script src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript">
  $("#jumlah").change(function(){
    var payment = $("#payment").val();
    var jumlah = $("#jumlah").val();
    $.ajax({
      url : '<?= $cfg_baseurl; ?>inc/depo_rate.php',
      type  : 'POST',
      dataType: 'html',
      data  : 'payment='+payment+'&jumlah='+jumlah,
      success : function(result){
        $("#cutbalance").val(result);
      }
      });
    });  
</script>
<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$cfg_baseurl);
}
?>