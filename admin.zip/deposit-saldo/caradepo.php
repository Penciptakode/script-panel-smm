<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else {

include("../lib/header.php");
?>
            <div class="content-page">
<body oncontextmenu='return false;' onkeydown='return false;' onmousedown='return false;'>
			<div class="row">
					<div class="card">
						<div class="card-body tx-center tx-inverse">
							<div class="row">
		         <div class="col-sm-12 col-md-12" style="margin-bottom:50px;">
            <center><h3 style="font-size:20px;font-weight:bold;">CARA DEPOSIT</h3></center>
            <center><p class="lead mg-b-0">Setelah mendaftar di wdstore, langkah selanjutnya adalah deposit saldo agar anda dapat melakukan transaksi.</p></center>
         </div>
         <div class="col-sm-4 col-md-4">
            <!-- Start User Friendly Block -->
            <div class="box-content text-center">
               <div class="block-icon">
                  <span aria-hidden="true" class="fa fa-edit fa-3x text-primary"></span>
               </div>
               <h3>Request Deposit</h3>
               <p>Langkah pertama, lakukan request deposit pada halaman member dengan memilih menu DEPOSIT SALDO lalu memilih Pulsa Transfer/EMONEY serta nominal deposit yang diinginkan dan sistem akan menampilkan detail deposit anda, berupa Nominal Transfer & Nomor tujuan.</p>
            </div>
            <!-- End Block -->
         </div>
         <div class="col-sm-4 col-md-4">
            <!-- Start User Friendly Block -->
            <div class="box-content text-center">
               <div class="block-icon">
                  <span aria-hidden="true" class="fa fa-paper-plane fa-3x text-primary"></span>
               </div>
               <h3>Transfer Pembayaran</h3>
               <p>Langkah kedua, anda akan di minta untuk melakukan transfer sejumlah nominal transfer yang tertera pada detail deposit, nominal transfer untuk pulsa transfer tidak ada tambahan angka unik untuk tf, sedangkan untuk EMONEY memiliki 3 angka unik di belakang sehingga disarankan untuk transfer pembayaran sesuai nominal transfer yang tertera.</p>
            </div>
            <!-- End Block -->
         </div>
         <div class="col-sm-4 col-md-4">
            <!-- Start User Friendly Block -->
            <div class="box-content text-center">
               <div class="block-icon">
                  <span aria-hidden="true" class="fa fa-check fa-3x text-primary"></span>
               </div>
               <h3>Konfirmasi Pembayaran</h3>
               <p>Langkah terakhir, konfirmasi pembayaran anda dengan cara kirim bukti transfer ke admin grup</p>
            </div>
         </div>
         <br>
         <br>
         <div class="col-sm-12 col-md-12">
            <!-- Start User Friendly Block -->
            <div class="box-content text-center">
               <div class="block-icon">
               <center><h3 style="font-size:20px;font-weight:bold;"><font color =''>MENDUKUNG PEMBAYARAN DARI PULSA TRANSFER & DOMPET DIGITAL BERIKUT</font></h3></center>
               </div>
               <div style="text-align:center;padding-top:20px">
<img src="https://technologue.id/wp-content/uploads/2017/04/TELKOMSEL.jpg" style="height:100%;max-height:50px;margin:50px 60px" />
<img src="https://p-store.net/images/payment-icon/paypal.png" style="height:100%;max-height:30px;margin:10px 20px" />
<img src="https://p-store.net/images/payment-icon/ovo.png" style="height:100%;max-height:30px;margin:10px 20px" />
<img src="https://p-store.net/images/payment-icon/gopay.png" style="height:100%;max-height:30px;margin:10px 20px" />
</div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
</div>

<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>