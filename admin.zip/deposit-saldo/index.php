<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else {

include("../lib/header.php");
?>
                    <div class="col-md-12">
                        <br/>
                    </div>

	<div class="row">
	    <div class="col-12">
	        <div class="card card-body">
	            <h3 class="text-center">METODE TOPUP</h3>
	            <div class="row" style="margin-top:20px;">
	                <div class="col-md-4 col-sm-12">
	                    <a class="card card-body text-center text-primary" href="<?php echo $cfg_baseurl; ?>deposit-saldo/pulsa-transfer" style="height:200px;">
	                        <center>
	                            <img src="<?php echo $cfg_baseurl; ?>assets/images/logo/pulsa.png" class="img-responsive" width="200"/>
	                        </center>
	                        <h4>Pulsa Transfer</h4>
	                    </a>
	                </div>

	                <div class="col-md-4 col-sm-12">
	                    <a class="card card-body text-center text-primary" href="<?php echo $cfg_baseurl; ?>deposit-saldo/emoney" style="height:200px;">
	                        <center>
	                            <img src="<?php echo $cfg_baseurl; ?>assets/images/logo/emny.png" class="img-responsive" width="200"/>
	                        </center>
	                       <br>
	                        <h4>E-MONEY</h4>
	                    </a>
	                </div>

	                <div class="col-md-4 col-sm-12">
	                    <a class="card card-body text-center text-primary" href="<?php echo $cfg_baseurl; ?>deposit-saldo/redem-voucher" style="height:200px;">
	                        <center>
	                            <img src="<?php echo $cfg_baseurl; ?>assets/images/logo/reedem-code.png" class="img-responsive" width="120"/>
	                        </center>
	                        <h4>Reedem Kode</h4>
	                    </a>
	                </div>
	            </div>
	            
	            <div class="row">
	                <div class="col-md-12 col-sm-12">
	                    <a class="card card-body text-center text-primary" href="<?php echo $cfg_baseurl; ?>deposit-saldo/riwayat" style="height:200px;">
	                        <center>
	                            <img src="<?php echo $cfg_baseurl; ?>assets/images/logo/history.png" class="img-responsive" width="120"/>
	                        </center>
	                        <h4>Riwayat Deposit</h4>
	                    </a>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
</div>

<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>
<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+6289506667156", // WhatsApp number
            call_to_action: "Hubungi Kami", // Call to action
            position: "right", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /WhatsHelp.io widget -->