<?php
session_start();
require_once("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}
	if (isset($_POST['buat'])) {
		$post_code = $db->real_escape_string(trim(filter($_POST['code'])));
		
	    $cek_voc = mysqli_query($db, "SELECT * FROM kode_voucher WHERE code = '$post_code' AND status = 'Active'");
        $cek_voc_rows = mysqli_num_rows($cek_voc);
		$data_voc = mysqli_fetch_assoc($cek_voc);
		
	    if (empty($post_code)) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
	    } else if (mysqli_num_rows($cek_voc) == 0) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Kode Voucher Tidak Ditemukan Atau Sudah Tidak Aktif.<script>swal("Gagal!", "Kode Voucher Tidak Ditemukan Atau Sudah Tidak Aktif.", "error");</script>';
		} else {
			    $update_user = mysqli_query($db, "UPDATE users SET balance = balance+".$data_voc['balance']." WHERE username = '$sess_username'");
				$update_user = mysqli_query($db, "UPDATE kode_voucher SET status = 'Already Used' WHERE code = '".$data_voc['code']."'");
			    if ($update_user == TRUE) {
			    $saldo = $data_voc['balance'];
				$insert_code = mysqli_query($db, "INSERT INTO balance_history (username, action, quantity, msg, date, time) VALUES ('$sess_username', 'Add Balance', '$saldo' , 'Mendapatkan Saldo Dari Redeem Kode Voucher', '$date', '$time')");
				if ($insert_code == TRUE) {
					$msg_type = "success";
					$msg_content = '<b>Berhasil:</b> Kode Voucher Berhasil Di Redeem Sebesar Rp '.$saldo.'.<script>swal("Berhasil!", "Kode Voucher Berhasil Di Redeem Sebesar Rp '.$saldo.'.", "success");</script>';;
				} else {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}
	}

	include("../lib/header.php");
?>
 <div class="row">
                    <div class="col-sm-6">
                        <br/>
                    </div>
                </div>	

                        <div class="row">
                            <div class="col-md-2"></div><div class="col-md-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fe-shopping-bag mr-1 text-primary"></i> Redeem Kode Voucher</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
												<label class="col-md-2 control-label">Kode Voucher</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="fe-shopping-bag mr-1 text-primary"></i>
                                                    </div>
                                                </div>
													<input type="number" name="code" class="form-control" placeholder="Masukan Kode Voucher">
												</div>
											</div>
										</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
												<button type="reset" class="btn btn-danger waves-effect w-md waves-light">Ulangi</button>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="buat">Redeem</button>
											</div>
										</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$cfg_baseurl);
}
?>