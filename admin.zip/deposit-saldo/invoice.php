<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else {
		if (isset($_GET['code'])) {
			$post_code = $_GET['code'];
			$cek_deposit = mysqli_query($db, "SELECT * FROM deposit WHERE code = '$post_code' AND username = '$sess_username'");
			$data_depo = mysqli_fetch_assoc($cek_deposit);
			if (mysqli_num_rows($cek_deposit) == 0) {
				header("Location: ".$cfg_baseurl."deposit-saldo/riwayat");
			} else {

		if($data_depo['status'] == "Pending") {
			$label = "warning";
		} else if($data_depo['status'] == "Error") {
			$label = "danger";
		} else if($data_depo['status'] == "Success") {
			$label = "success";
		}
				include("../lib/header.php");

	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
?>

                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>

            <div class="card-box">
                <!-- Logo & title -->
                <div class="clearfix">
                    <div class="float-left">
                        <img src="<?php echo $cfg_baseurl; ?>home/pacific.png" alt="" height="50">
                    </div>
                    <div class="float-right">
                        <h4 class="m-0 d-print-none">Invoice Deposit #<?php echo $data_depo['code']; ?></h4>
                    </div>
                </div>
    
                <div class="row">
                    <div class="col-md-6">
                        <div class="mt-3">
                            <p><b>Hallo, <?php echo $data_depo['username']; ?></b></p>
                            <p class="text-muted">Terimakasih Telah Melakukan Deposit Di <?php echo $cfg_webname; ?>, Silahkan Melakukan Pembayaran Dengan Detail Invoice Pembayaran Di Bawah Ini.</p>
                        </div>
    
                    </div>
                    <!-- end col -->
                    <div class="col-md-4 offset-md-2">
                        <div class="mt-3 float-right">
                            <p class="m-b-10"><strong>Tanggal & Waktu : </strong><span class="float-right"> &nbsp;&nbsp;&nbsp;&nbsp; <?php echo TanggalIndonesia($data_depo['date']); ?>, <?php echo $data_depo['time']; ?></span></p>
                            <p class="m-b-10"><strong>Status : </strong> <span class="float-right">
                            <p class="btn btn-xs btn-<?php echo $label; ?>"><?php echo $data_depo['status']; ?></span>
                            </span>
                            </p>
                            <p class="m-b-10"><strong>Invoice No : </strong><span class="float-right">#<?php echo $data_depo['code']; ?></span></p>
                        </div>
                    </div>
                    <!-- end col -->
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive">
                            <table class="table mt-4 table-centered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Metode Pembayaran</th>
                                        <th>Penerima</th>
                                        <th style="width: 10%">Jumlah Pembayaran</th>
                                        <th style="width: 10%" class="text-right">Saldo Didapat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><?php echo $data_depo['provider']; ?></td>
                                        <td><font color ='red'><?php echo $data_depo['penerima']; ?></font></td>
                                        <td><?php echo number_format($data_depo['jumlah'],0,',','.'); ?></td>
                                        <td class="text-right"><?php echo number_format($data_depo['saldo'],0,',','.'); ?></td>
                                    </tr>
    
                                </tbody>
                            </table>
                        </div>
                        <!-- end table-responsive -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->

                <div class="row">
                    <div class="col-sm-6">
                        <div class="clearfix pt-3">
                            <h5 class="text-muted">Keterangan :</h5>
                            <p class="text-muted">Harap Melakukan Pembayaran Segera Selambat-lambat Nya 12 Jam Dari Invoice Deposit Di Buat.
                            Harap Transfer Dengan Jumlah Rp <font color=red><?php echo number_format($data_depo['jumlah'],0,',','.'); ?></color></font>,-
                            <?php if($data_depo['name'] !== "Transfer Pulsa") { ?>
                            Wajib Sesuai Dengan 3 Kode Unik Di Belakang Nya.
                            Jangan Lupa Jika Deposit Via Emoney,Diwajibkan Kirim Bukti Transfer!
                            <?php
                            }
                            ?>
                            Terima Kasih.
                            </p>
                        </div>
                    </div>
                    <!-- end col -->
                    <div class="col-sm-6">
                        <div class="float-right">
                            <h3>Rp. <?php echo number_format($data_depo['saldo'],0,',','.'); ?></h3>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <!-- end col -->
                </div>
                <?php if($data_depo['status'] !== "Success" AND $data_depo['status'] !== "Error") { ?>
                <div class="mt-4 mb-1">
                    <div class="text-right d-print-none">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo $cfg_baseurl; ?>deposit-saldo/riwayat">
                        	<input type="hidden" name="code" value="<?php echo $data_depo['code']; ?>">
                        	<button type="submit" class="pull-right btn btn-danger"><strong>BATALKAN</strong></button>
                        </form>
                    </div>
                </div>
                <?php
                }
                ?>
            </div>
            <!-- end card-box -->
        </div>
        <!-- end col -->
    </div>
</div>

<?php
				include("../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."deposit-saldo/riwayat");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>