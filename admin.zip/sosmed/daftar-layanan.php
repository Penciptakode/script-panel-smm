<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}
}

include("../lib/header.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>

						<div class="row">
                            <div class="col-md-12">
                                <div class="card-box ribbon-box">
                                    <div class="ribbon ribbon-primary float-left"><i class="fa fa-list"></i> Daftar Harga</div>
                                        <div class="ribbon-content">
                                        </div>
										<form class="form-horizontal" role="form" method="POST">
											
											    <div class="form-group">
												<div class="col-md-3"><b>Kategori</b></div>
												<div class="col-md-12">
												<select class="form-control" name="category" id="category">
														<option value="0">Pilih Salah Satu...</option>
														<?php
											$check_cat = mysqli_query($db, "SELECT * FROM service_cat");
											while ($data_cat = mysqli_fetch_assoc($check_cat)) {
											?>
											<option value="<?php echo $data_cat['code']; ?>"><?php echo $data_cat['name']; ?></option>
											<?php
											}
											?>
													</select>
											    </div>
											</div>
						<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script type="text/javascript">
$(document).ready(function() {
	$("#type").change(function() {
		var type = $("#type").val();
		var category = $("#category").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/tipe_sosmed.php',
			data: 'type=' + type,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#category").html(msg);
			}
		});
	});
	$("#category").change(function() {
		var category = $("#category").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/service_sosmed_list.php',
			data: 'category=' + category,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#service").html(msg);
			}
		});
	});
	$("#service").change(function() {
		var service = $("#service").val();
		$.ajax({
			url: '<?php echo $cfg_baseurl; ?>inc/order_pulsa.php',
			data: 'service=' + service,
			type: 'POST',
			dataType: 'html',
			success: function(msg) {
				$("#price").val(msg);
			}
		});
	});
});
</script>
                       
												     <div class="col-md-12">
											      <div id="service"></div>		
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div><!-- end row -->
				<!-- end row -->

<?php
	include("../lib/footer.php");
?>