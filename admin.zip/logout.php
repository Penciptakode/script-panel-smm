<?php
session_start();
require("mainconfig.php");
if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$ip = $_SERVER['REMOTE_ADDR'];
	}
session_destroy();
					$insert_user = $db->query("INSERT INTO log (username, catatan, waktu) VALUES ('$sess_username', 'Kamu Telah Melakukan Aktifitas Keluar Akun Dengan IP $ip', '$date $time')");
					if ($insert_user == TRUE) {
					header("Location: ".$cfg_baseurl);
				}