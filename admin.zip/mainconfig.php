<?php
// Hargailah orang lain jika Anda ingin dihargai

date_default_timezone_set('Asia/Jakarta');
error_reporting(0);

$cfg_mt = 0; // Maintenance? 1 = ya 0 = tidak
if($cfg_mt == 1) {
    die("Site under Maintenance.");
}

// web
$cfg_webtitle = "Jakarta Pedia | Server H2H & Smm Panel ";
$cfg_webname = "Jakarta Pedia";
$cfg_baseurl = "https://jakartapedia.org/";
$cfg_desc = "Jakarta Pedia Merupakan Sebuah Server H2H Pulsa Serta PPOB Termurah Dan Server Sosial Media Marketing, Cepat & Berkualitas.";
$cfg_author = "Muhamad Syahrul Minanul Aziz";
$logo_white = "Jakarta";
$logo_blue = " Pedia";
$cfg_about = "Jakarta Pedia Merupakan Sebuah Server H2H Pulsa Serta PPOB Termurah Dan Server Sosial Media Marketing, Cepat & Berkualitas.";

// fitur staff
$cfg_min_transfer = 1000; // jumlah minimal transfer saldo
$cfg_member_price = 10000; // harga pendaftaran member
$cfg_member_bonus = 5000; // bonus saldo member
$cfg_agen_price = 20000; // harga pendaftaran agen
$cfg_agen_bonus = 10000; // bonus saldo agen
$cfg_reseller_price = 35000; // harga pendaftaran reseller
$cfg_reseller_bonus = 20000; // bonus saldo reseller
$cfg_admin_price = 50000; // harga pendaftaran admin
$cfg_admin_bonus = 30000; // bonus saldo admin

// Harga Pendaftaran
$member_price =10000; // harga pendaftaran member
$member_bonus = 5000; // bonus saldo member
$agen_price = 20000; // harga pendaftaran agen
$agen_bonus = 10000; // bonus saldo agen
$reseller_price = 35000; // harga pendaftaran reseller
$reseller_bonus = 20000; // bonus saldo reseller
$admin_price = 50000; // harga pendaftaran admin
$admin_bonus = 30000; // bonus saldo admin

// database
$db_server = "localhost";
$db_user = "benongpe_db";
$db_password = "benongpe_db";
$db_name = "benongpe_db";

// date & time
$date = date("Y-m-d");
$time = date("H:i:s");

function filter($data){

$filter = stripslashes(strip_tags(htmlspecialchars(htmlentities($data,ENT_QUOTES))));

return $filter;

}


// require
require("lib/database.php");
require("lib/function.php");