<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	include("../lib/header.php");
	$msg_type = "nothing";

	if (isset($_POST['order'])) {
	    $post_tipe = $db->real_escape_string(trim(filter($_POST['tipe'])));
		$post_target = $db->real_escape_string(trim(filter($_POST['target'])));
		$post_jumlah = $db->real_escape_string(trim(filter($_POST['jumlah'])));
    
        $check_orders = mysqli_query($db, "SELECT * FROM orders_pulsa WHERE data = '$post_target' AND status IN ('Pending','Processing')");
        $data_orders = mysqli_fetch_assoc($check_orders);		

		$oid = random_number(3).random_number(4);
        $provider = "DP-PULSA";
        $get_price = ($post_jumlah / 1) + 800;
        $check_provider = mysqli_query($db, "SELECT * FROM provider WHERE code = '$provider'");
        $data_provider = mysqli_fetch_assoc($check_provider);
        
		if (empty($post_tipe) || empty($post_target) || empty($post_jumlah)) {
	    	$msg_type = "error";
		    $msg_content = '<b>Gagal:</b> Mohon Mengisi Semua Input.<script>swal("Gagal!", "Mohon Mengisi Semua Input.", "error");</script>';
		} else if (mysqli_num_rows($check_provider) == 0) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Server Sedang Mengalami Gangguan.<script>swal("Gagal!", "Server Sedang Mengalami Gangguan.", "error");</script>';
		} else if (mysqli_num_rows($check_orders) == 1) {
		    $msg_type = "error";
		    $msg_content = '<b>Gagal:</b> Terdapat Pesanan Dengan No.HP Yang Sama & Berstatus Pending/Processing.<script>swal("Gagal!", "Terdapat Pesanan Dengan No.HP Yang Sama & Berstatus Pending/Processing.", "error");</script>';		
		} else if ($data_user['balance'] < $get_price) {
			$msg_type = "error";
			$msg_content = '<b>Gagal:</b> Saldo Anda Tidak Mencukupi Untuk Melakukan Pesanan Ini.<script>swal("Gagal!", "Saldo Anda Tidak Mencukupi Untuk Melakukan Pesanan Ini.", "error");</script>';
		} else {
		    
		    if($post_tipe == "ovo"){
		        $post_tipee = "SALDO OVO CASH";
		    } else if($post_tipe == "gopay"){
		        $post_tipee = "SALDO GOPAY";
		    }

			// api data
			$api_link = $data_provider['link'];
			$api_key = $data_provider['api_key'];
			// end api data

              $poid = random_number(7);

			if ($provider == "MANUAL") {
				$api_postdata = "";
				$poid = $oid;
			} else if ($provider == "DP-PULSA") {			
			$api_postdata = "api_key=$api_key&tipe=$post_tipe&nomor=$post_target&nominal=$post_jumlah";
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, 'https://serverh2h.com/order/saldo');
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $api_postdata);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$chresult = curl_exec($ch);
			$chresult;
			curl_close($ch);
			$json_result = json_decode($chresult, true);	
				$poid = $json_result['code_trx'];		
			} else {
				die("System Error!");
			}

			if (empty($poid)) {
				$msg_type = "error";
				$msg_content = $json_result['error']."<b> (1).";
			} else {
			    $check_top = mysqli_query($db, "SELECT * FROM top_users WHERE username = '$sess_username'");
			    $data_top = mysqli_fetch_assoc($check_top);
				$update_user = mysqli_query($db, "UPDATE users SET balance = balance-$get_price WHERE username = '$sess_username'");
				$get_price = $post_jumlah / 1 + 800;
				if ($update_user == TRUE) {
				    $insert_order = mysqli_query($db, "INSERT INTO balance_history (id, username, action, quantity, msg, date, time) VALUES ('', '$sess_username', 'Cut Balance', '$get_price', 'Pemesanan $post_tipee Dengan ID Pesanan : $oid', '$date', '$time')");
					$insert_order = mysqli_query($db, "INSERT INTO orders_pulsa (oid, poid, user, service, data, price, status, date, place_from, provider) VALUES ('$oid', '$poid', '$sess_username', '$post_tipee $post_jumlah', '$post_target', '$get_price', 'Pending', '$date', 'WEB', '$provider')");
					if ($insert_order == TRUE) {
    					if (mysqli_num_rows($check_top) == 0) {
    				        $insert_topup = mysqli_query($db, "INSERT INTO top_users (method, username, jumlah, total) VALUES ('Order', '$sess_username', '$get_price', '1')");
    				    } else {
    				        $insert_topup = mysqli_query($db, "UPDATE top_users SET jumlah = ".$data_top['jumlah']."+$get_price, total = ".$data_top['total']."+1 WHERE username = '$sess_username' AND method = 'Order'");
    				    }
    						$msg_type = "success";
    						$msg_content = "<b>Berhasil:</b> Pesanan Anda Telah Diterima.</b><br /><b>ID Pesanan:</b> $oid<br /><b>Nama Layanan:</b> $post_tipee $post_jumlah<br /><b>Tujuan/Target:</b> $post_target<br /><b>Harga:</b> Rp ".number_format($get_price,0,',','.');
					} else {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> System Error.";
				    }
    			} else {
    				$msg_type = 'error';
    				$msg_content = "<b>Gagal</b> System Error.";
    			}
		    }
        }
    }
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
?>
                    <div class="col-md-12">
                        <br/>
                    </div>
<div class="row">
<div class="col-lg-12">
<div class="alert alert-success">
<h4 class="text-uppercase">
<i class="mdi mdi-bullhorn"></i> <b class="text-uppercase">Penting!</b></h3>
Halo <?php echo $sess_username; ?>, Sebelum Membuat Pesanan Disarankan Untuk Membaca <b>Informasi</b> Terlebih Dahulu, Jika Anda Masuk Menggunakan PC Maka <b>Informasi</b> Terletak Disebelah Kanan Form Pesanan, Jika Anda Masuk Menggunakan <i>Smartphone / Mobile Phone</i> Maka <b>Informasi</b> Terletak Dibagian Bawah Form Pesanan.
<br/>
Terima Kasih.
</div>
</div>
</div>
						<div class="row">
							<div class="col-md-7">
								<div class="card">
									<div class="card-header">
										<h4 class="header-title"><i class="mdi mdi-cart text-primary"></i> Pemesanan Baru</h4>
									</div>
									<div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" method="POST">
										<input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>">
											<div class="form-group">
												<label class="col-md-2 control-label">Tipe</label>
												<div class="col-md-10">
												<select class="form-control" id="tipe" name="tipe">
													<option value="0">Pilih Salah Satu...</option>
                                                    <option value="gopay">SALDO GOPAY</option>
                                                    <option value="ovo">SALDO OVO</option>
													</select>
												</div>
											</div>	
											<div class="form-group">
												<label class="col-md-2 control-label">Tujuan</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                        <i class="mdi mdi-cellphone-android mr-1"></i>
                                                    </div>
                                                </div>
													<input type="number" name="target" class="form-control" placeholder="Nomor Target">
												</div>
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-2 control-label">Jumlah</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            Rp
                                                    </div>
                                                </div>
													<input type="number" name="jumlah" id="jumlah" class="form-control" placeholder="Contoh: 10000">
    												</div>
    											</div>
    										</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Total Harga</label>
												<div class="col-md-10">
											    <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            Rp
                                                    </div>
                                                </div>
													<input type="number" class="form-control" name="total" id="total" placeholder="0" readonly>
    												</div>
    											</div>
    										</div>
    										<div class="form-group">
    										<div class="col-md-10">
											<button type="reset" class="btn btn-danger waves-effect w-md waves-light">Ulangi</button>
											<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="order">Buat Pesanan</button>
											    </div>
											</div>    
										</form>
									</div>
								</div>
							</div>
                            <div class="col-md-5">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-information-outline text-primary"></i> Peraturan Pemesanan</h4>
                                    </div>
                                    <div class="card-body">
										<ul>
											<li>Pesan Saldo OVO CASH Dan Saldo GOPAY, Masukkan Nomor Dengan Benar.</li>
											<li>Sistem Serba OTOMATIS INSTAN, Harap Berhati Hati Sebelum Pesan!.</li>
											<li>Harap Masukan Nomor OVO Atau GOPAY Dengan Benar, Tidak Ada Pengembalian Dana Untuk Kesalahan Pengguna Yang Pesanannya Sudah Terlajur Di Pesan.</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
						<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script type="text/javascript">
$(document).ready(function() {
  $("#jumlah").change(function(){
    var jumlah = $("#jumlah").val();
    $.ajax({
      url : '<?php echo $cfg_baseurl; ?>inc/rate-saldo.php',
      type  : 'POST',
      dataType: 'html',
      data: 'jumlah=' + jumlah,
      success : function(result){
        $("#total").val(result);
      }
      });
    });  
});
	</script>
<?php
	include("../lib/footer.php");
} else {
	header("Location: ".$cfg_baseurl);
}
?>