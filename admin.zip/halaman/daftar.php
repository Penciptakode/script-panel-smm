<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}
}
include("../lib/header.php");
?>

<?php
$check_member = mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE level = 'Member'");
$data_member = $check_member->fetch_assoc();

$check_agen = mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE level = 'Agen'");
$data_agen = $check_agen->fetch_assoc();

$check_reseller = mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE level = 'Reseller'");
$data_reseller = $check_reseller->fetch_assoc();

$check_admin = mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE level = 'Admin'");
$data_admin = $check_admin->fetch_assoc();
?>


                <div class="row">
                    <div class="col-lg-12 center-page">
                        <div class="text-center">
                            <h2 class="m-b-30 m-t-20">Daftar Harga Pendaftaran Akun <?php echo $cfg_webname ?></h2>
                            <p>
                                 Buruan Join <?php echo $cfg_webname ?>, Dijamin Gak Nyesel Kok Join <?php echo $cfg_webname ?> <br/> Mari Memulai Bisnis Bersama <?php echo $cfg_webname ?>, Mari Raih Kesuksesanmu Bersama <?php echo $cfg_webname ?>.
                            </p>
                        </div>

                        <div class="row m-t-50">
                            
                            <!--Pricing Column-->
                            <article class="pricing-column col-lg-3 col-md-3">
                                <div class="inner-box card-box">
                                    <div class="plan-header text-center">
                                        <h3 class="plan-title">Member</h3>
                                        <h2 class="plan-price">Rp.<?php echo $data_member['harga']; ?></h2>
                                    </div>
                                    <ul>
                                        <li>Akses Semua Fitur Yang Di Berikan Oleh Layanan <?php echo $cfg_webname ?></li>
                                        <li>Mendapatkan Saldo Awal Sebesar Rp.<?php echo $data_member['bonus']; ?></li>
                                        <li>Mendapatkan Bonus Bulanan Jika Masuk Top 5 Pengguna</li>
                                        <li>Masuk Grup Bimbingan Cara Berbisnis Di <?php echo $cfg_webname ?></li>
                                    </ul>

                                    <div class="text-center">
                                        <a href="https://api.whatsapp.com/send?phone=6281572323740&text=Hallo%20Saya%20Mau%20Beli%20SC%20V1.MSYAHRULMA.ID" class="btn btn-primary btn-bordred btn-rounded waves-effect waves-light" target="BLANK"><i class="mdi mdi-account-plus"></i> Daftar Sekarang</a>
                                    </div>
                                </div>
                            </article> 

                            <!--Pricing Column-->
                            <article class="pricing-column col-lg-3 col-md-3">
                                <div class="inner-box card-box">
                                    <div class="plan-header text-center">
                                        <h3 class="plan-title">Agen</h3>
                                        <h2 class="plan-price">Rp.<?php echo $data_agen['harga']; ?></h2>
                                    </div>
                                    <ul>
                                        <li>Akses Semua Fitur Yang Di Berikan Oleh Layanan <?php echo $cfg_webname ?></li>
                                        <li>Mendapatkan Saldo Awal Sebesar Rp.<?php echo $data_agen['bonus']; ?></li>
                                        <li>Dapat Mendaftarkan Pengguna Dengan Level Member</li>
                                        <li>Dapat Melakukakan Transfer Saldo Ke Pengguna Lain</li>
                                        <li>Mendapatkan Bonus Bulanan Jika Masuk Top 5 Pengguna</li>
                                        <li>Masuk Grup Bimbingan Cara Berbisnis Di <?php echo $cfg_webname ?></li>
                                    </ul>

                                    <div class="text-center">
                                        <a href="https://api.whatsapp.com/send?phone=6281572323740&text=Hallo%20Saya%20Mau%20Beli%20SC%20V1.MSYAHRULMA.ID" class="btn btn-primary btn-bordred btn-rounded waves-effect waves-light" target="BLANK"><i class="mdi mdi-account-plus"></i> Daftar Sekarang</a>
                                    </div>
                                </div>
                            </article>

                            <!--Pricing Column-->
                            <article class="pricing-column col-lg-3 col-md-3">
                                <div class="inner-box card-box">
                                    <div class="plan-header text-center">
                                        <h3 class="plan-title">Resseler</h3>
                                        <h2 class="plan-price">Rp.<?php echo $data_reseller['harga']; ?></h2>
                                    </div>
                                    <ul>
                                        <li>Akses Semua Fitur Yang Di Berikan Oleh Layanan <?php echo $cfg_webname ?></li>
                                        <li>Mendapatkan Saldo Awal Sebesar Rp.<?php echo $data_reseller['bonus']; ?></li>
                                        <li>Dapat Mendaftarkan Pengguna Dengan Level Member Dan Agen</li>   
                                        <li>Dapat Melakukakan Transfer Saldo Ke Pengguna Lain</li>   
                                        <li>Mendapatkan Bonus Bulanan Jika Masuk Top 5 Pengguna</li>
                                        <li>Masuk Grup Bimbingan Cara Berbisnis Di <?php echo $cfg_webname ?></li>
                                    </ul>

                                    <div class="text-center">
                                        <a href="https://api.whatsapp.com/send?phone=6281572323740&text=Hallo%20Saya%20Mau%20Beli%20SC%20V1.MSYAHRULMA.ID" class="btn btn-primary btn-bordred btn-rounded waves-effect waves-light" target="BLANK"><i class="mdi mdi-account-plus"></i> Daftar Sekarang</a>
                                    </div>
                                </div>
                            </article>
                            
                            <!--Pricing Column-->
                            <article class="pricing-column col-lg-3 col-md-3">
                                <div class="inner-box card-box">
                                    <div class="plan-header text-center">
                                        <h3 class="plan-title">Admin</h3>
                                        <h2 class="plan-price">Rp.<?php echo $data_admin['harga']; ?></h2>
                                    </div>
                                    <ul>
                                        <li>Akses Semua Fitur Yang Di Berikan Oleh Layanan <?php echo $cfg_webname ?></li>
                                        <li>Mendapatkan Saldo Awal Sebesar Rp.<?php echo $data_admin['bonus']; ?></li>
                                        <li>Dapat Mendaftarkan Pengguna Dengan Level Member, Agen, Dan Reseller</li>   
                                        <li>Dapat Melakukakan Transfer Saldo Ke Pengguna Lain</li>   
                                        <li>Mendapatkan Bonus Bulanan Jika Masuk Top 5 Pengguna</li>
                                        <li>Masuk Grup Bimbingan Cara Berbisnis Di <?php echo $cfg_webname ?></li>
                                    </ul>

                                    <div class="text-center">
                                        <a href="https://api.whatsapp.com/send?phone=6281572323740&text=Hallo%20Saya%20Mau%20Beli%20SC%20V1.MSYAHRULMA.ID" class="btn btn-primary btn-bordred btn-rounded waves-effect waves-light" target="BLANK"><i class="mdi mdi-account-plus"></i> Daftar Sekarang</a>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </div><!-- end col -->
                </div>
                <!-- end row -->

 <?php
	include("../lib/footer.php");
?>