<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}
}

include("../lib/header.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-box ribbon-box">
                                    <div class="ribbon ribbon-primary float-left"><i class="mdi mdi-alert-outline"></i> Penjelasan Keterangan Dan Status Di <?php echo $cfg_webname; ?></div>
                                        <div class="ribbon-content">
                                        </div>
										<b>- Pending</b> : Pesanan Atau Deposit Sedang Dalam Antrian Di Server<br>
										<b>- Processing</b> : Pesanan Sedang Dalam Proses<br>
										<b>- Success</b> : Pesanan Telah Berhasil<br>
										<b>- Partial</b> : Pesanan Sudah Terproses Tapi Tercanceled Ditengah Jalan, Kami Akan Reffund Yang Belum Masuk<br>
										<b>- Error</b> : Pesanan Di Batalkan, Dan Saldo Akan Otomatis Di Kembalikan Ke Akun.<br>
										<br>
										<b>MENGAPA BISA PARTIAL ???</b><br>
										<b>Limit</b> : Contoh Jika Satu Layanan Dengan Maksimal 10.000 Followers, Kemudian Anda Membeli 10.000 Followers 2x Di <b>Akun Yang Sama</b>. Kemungkinan Besar Akan Terjadi Partial. <br>
										Karena Akun <i>Followers</i> Yang Ada Di Server Tersebut Hanya 10.000 Followers.<br>
										Jadi Anda Tidak Bisa Mengirim Lebih Dari 20.000 Followers Walaupun Dengan Cara 10.000 2x Pemesanan.<br>
										Jika Hal Ini Terjadi, Silahkan Gunakan <i>Server Layanan</i> Lainnya.<br>
										<b>Hal Ini Tidak Berpengaruh Jika Berbeda Akun.</b><br>
										<b>Server Overload :</b> Overload Biasanya Terjadi Di Layanan Yang Murah. Karena Murah Terlalu Banyak Pesanan Yang Masuk Sehingga Terjadi Overload Dan Partial.<br>
										Untuk Pesanan Partial, Sisa Saldo Layanan Yang Tidak Masuk Akan Otomatis Di Kembalikan Ke Akun.	
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
include("../lib/footer.php");
?>