<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}
}

include("../lib/header.php");
?>

<?php
$check_contact = $db->query("SELECT * FROM contact ORDER BY id DESC");
while ($data_contact = $check_contact->fetch_assoc()) {
?>

                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
				<div class="row">
                    <div class="col-12">
                        <div class="text-center">
                            <i class="h1 mdi mdi-comment-multiple-outline text-muted"></i>
                            <h3 class="mb-3">Pertanyaan Yang Sering Ditanyakan.!</h3>
                            <p class="text-muted"> Berikut Telah Kami Rangkum Beberapa Pertanyaan Yang Sering Ditanyakan Client Terkait Dengan Layanan Kami.</p>
                            <a href="https://api.whatsapp.com/send?phone=<?php echo $data_contact['wa']; ?>&amp;text=Halo Admin Saya Butuh Bantuan" target="BLANK"> <button type="button" class="btn btn-primary waves-effect waves-light mt-2"><i class="mdi mdi-whatsapp mr-1"></i>Hubungi Kami Di WhatSapp</button></a>
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            <br/>

					<?php
					}
					?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="card-box ribbon-box">
                                    <div class="ribbon ribbon-primary float-left"><i class="fa fa-edit"></i> Pertanyaan Umum</div>
                                        <div class="ribbon-content">
                                        </div>
                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question" data-wow-delay=".1s">Apa Itu <?php echo $cfg_webname; ?>?</h4>
                            <p class="faq-answer mb-4"><?php echo $cfg_webname; ?> Adalah Sebuah Platform Bisnis Yang Menyediakan Berbagai Layanan Multy Media Marketing Yang Bergerak Terutama Di Indonesia. Dengan Bergabung Bersama Kami, Anda Dapat Menjadi Penyedia Jasa Sosial Media Atau Reseller Sosial Media Seperti Jasa Penambah Followers, Likes, Views, Subscribe, Dll.
                            Saat Ini Tersedia Berbagai Layanan Untuk Sosial Media Terpopuler Seperti Instagram, Facebook, Twitter, Youtube, Dll. Dan Kamipun Juga Menyediakan Panel Pulsa & PPOB Seperti Pulsa All Operator, Paket Data, Saldo Gojek/Grab, Token PLN, All Voucher Game Online, Dll.</p>
                        </div>

                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question">Bagaimana Cara Mendaftarnya? Apakah Ada Biaya Pendaftaran?</h4>
                            <p class="faq-answer mb-4">Pendaftaran Cukup Klik Daftar, Dan Isi Data Sesuai Yang Dibutuhkan, Anda Sudah Terdaftar Di <b><?php echo $cfg_webname; ?></b>. Untuk Pendaftaran <i>GRATIS</i> Tidak Dipungut Biaya Seperserpun.</p>
                        </div>

                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question">Bagaimana Cara Membuat Pesanan?</h4>
                            <p class="faq-answer mb-4">Untuk Membuat Pesanan Sangatlah Mudah, Anda Hanya Perlu Masuk Terlebih Dahulu Ke Akun Anda Dan Menuju Halaman Pemesanan Dengan Mengklik Menu Yang Sudah Tersedia. Selain Itu Anda Juga Dapat Melakukan Pemesanan Melalui Request <b>API</b>.</p>
                        </div>

                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question" data-wow-delay=".1s">Apa Itu Partial?</h4>
                            <p class="faq-answer mb-4">Status Partial Adalah Ketika Kami Mengembalikan Sebagian Sisa - Sisa Pesanan. Terkadang Karena Beberapa Alasan Kami Tidak Dapat Mengirimkan Pesanan Penuh, Jadi Kami Mengembalikan Saldo Sesuai Jumlah Yang Belum Terkirim Kepada Anda. Contoh: Anda Membeli Pesanan Dengan Jumlah 1.000 <i>Followers</i> Dan Membebankan Biaya Rp 10.000, Katakanlah Kami Mengirimkan 900 <i>Followers</i> Dan Kurang 100 <i>Followers</i> Tidak Dapat Kami Kirim, Maka Kami Akan <i>"Kembalikan Saldo"</i> Pesanan Dan Mengembalikan Kurang 100 <i>Followers</i> Kepada Anda Dalam Contoh Ini.</p>
									</div>
								</div>
							</div>

                        <div class="col-md-6">
                            <div class="card-box">
                                <br/>
                            <br/>
                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question">Apa Itu Instagram Mention?</h4>
                            <p class="faq-answer mb-4">Instagram Mention Adalah Ketika Anda Menyebut Seseorang Di Instagram Contoh: <i>@msyahrulma_13</i> Ini Berarti Anda Telah Menyebutkan <i>msyahrulma_13</i> Di Bawah Postingan Ini Dan <i>msyahrulma_13</i> Akan Menerima Pemberitahuan Untuk Memeriksa Postingan.
                            Pada Dasarnya Instagram Mentions <i>[Pengikut Pengguna]</i>, Anda Meletakkan Tautan Posting Anda, Dan Nama Pengguna Dari Orang Yang Anda Ingin Kami Sebutkan Sebagai Pengikut.</p>
                        </div>

                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question">Apa Itu Instagram Impressions?</h4>
                            <p class="faq-answer mb-4">Tayangan Berarti Menjangkau <i>Juga Berapa Banyak Pengguna Telah Melihat Posting Anda</i> Itu Kebanyakan Digunakan Dengan Merek, Mereka Akan Meminta Anda Untuk Menunjukkan Statistik Tayangan Yang Anda Miliki.</p>
                        </div>

                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question">Apa Perbedaan Semua Server Di Setiap Layanan?</h4>
                            <p class="faq-answer mb-4">Disetiap Layanan Kami Memberikan Perbedaan Harga, Kualitas Dan Kecepatan Proses, Rata - Rata Server Kami Optimal, Apabila Tidak Mengalami Gangguan. Dan Kami Selalu Memberikan <i>Informasi Atau Update</i> Layanan Di Info Panel.</p>
                        </div>

                        <!-- Question/Answer -->
                        <div>
                            <div class="faq-question-q-box">Q.</div>
                            <h4 class="faq-question">Bagaimana Cara Melakukan Deposit Atau Isi Saldo?</h4>
                            <p class="faq-answer mb-4">Untuk Melakukan Deposit Atau Isi Saldo, Anda Hanya Perlu Masuk Terlebih Dahulu Ke Akun Anda Dan Menuju Halaman Deposit Dengan Mengklik Menu Yang Sudah Tersedia. Kami Menyediakan Deposit Melalui Bank Dan Pulsa.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end row -->
<?php
include("../lib/footer.php");
?>