<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}
}
include("../lib/header.php");
?>

<?php
$check_contact = $db->query("SELECT * FROM contact ORDER BY id DESC");
while ($data_contact = $check_contact->fetch_assoc()) {
?>

                <div class="row">
                    <div class="col-sm-6">
                    	<br/>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div class="text-center card-box">
                            <div class="clearfix"></div>
                            <div class="member-card">
                                <div class="thumb-xl member-thumb m-b-10 center-block">
                                    <img src="<?php echo $cfg_baseurl; ?>assets/images/assistant.svg" width="150px" class="img-circle img-thumbnail" alt="profile-image">
                                    <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i>
                                </div>

                                <div class="">
                                    <h4 class="m-b-5 text-primary"><?php echo $data_contact['nama']; ?></h4>
                                    <label class="badge badge-info"><?php echo $data_contact['level']; ?></label>
                                </div>

                                <div class="text-muted font-13 m-t-20">
                                    <?php echo $data_contact['deskripsi']; ?>
                                </div>

                                <hr/>
                                            
                                </center>

                                <div class="text-left">
                                    <p class="text-muted font-13"><strong>Facebook :</strong> <span class="m-l-15"><?php echo $data_contact['fb']; ?></span></p>

                                    <p class="text-muted font-13"><strong>WhatsApp :</strong> <span class="m-l-15"><?php echo $data_contact['wa']; ?></span></p>

                                    <p class="text-muted font-13"><strong>Instagram :</strong> <span class="m-l-15"><?php echo $data_contact['ig']; ?></span></p>

                                    <p class="text-muted font-13"><strong>Lokasi :</strong> <span class="m-l-15"><?php echo $data_contact['lokasi']; ?></span></p>
                                </div>
                                            
                            <ul class="social-list list-inline mt-5 mb-0">
                                <li class="list-inline-item">
                                    <a href="<?php echo $data_contact['link_fb']; ?>" class="social-list-item border-primary text-primary"><i
                                            class="mdi mdi-facebook"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="https://api.whatsapp.com/send?phone=<?php echo $data_contact['wa']; ?>" class="social-list-item border-danger text-danger"><i
                                            class="mdi mdi-whatsapp"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="<?php echo $data_contact['link_ig']; ?>" class="social-list-item border-info text-info"><i
                                            class="mdi mdi-instagram"></i></a>
                                </li>
                            </ul>
						</div>
					<br />
<b>Jam Kerja</b><br />

<div class="alert alert-success">
<?php echo $data_contact['jam_kerja']; ?>
</div>
												<?php
												}
												?>
                                </div>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->


                    </div>
                    <!-- end container -->
                </div>
                <!-- end content -->
<?php
include("../lib/footer.php");
?>