<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_GET['sid'])) {
			$post_sid = $_GET['sid'];
			$checkdb_service = mysqli_query($db, "SELECT * FROM services WHERE sid = '$post_sid'");
			$datadb_service = mysqli_fetch_assoc($checkdb_service);
			if (mysqli_num_rows($checkdb_service) == 0) {
				header("Location: ".$cfg_baseurl."admin/services.php");
			} else {
				if (isset($_POST['edit'])) {
					$post_pid = $db->real_escape_string(filter($_POST['pid']));
					$post_cat = $db->real_escape_string(filter($_POST['category']));
					$post_service = $db->real_escape_string(filter($_POST['service']));
					$post_note = $db->real_escape_string(filter($_POST['note']));
					$post_min = $db->real_escape_string(filter($_POST['min']));
					$post_max = $db->real_escape_string(filter($_POST['max']));
					$post_price = $db->real_escape_string(filter($_POST['price']));
					$post_status = $db->real_escape_string(filter($_POST['status']));
					if (empty($post_service) || empty($post_note) || empty($post_min) || empty($post_max) || empty($post_price) || empty($post_pid) || empty($post_cat)) {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			        } else if ($data_user['level'] == "Member") {
			        	$msg_type = "error";
			        	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
					} else if ($post_status != "Active" AND $post_status != "Not active") {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Input Tidak Sesuai.";
					} else {
						$update_service = mysqli_query($db, "UPDATE services SET category = '$post_cat', service = '$post_service', note = '$post_note', min = '$post_min', max = '$post_max', price = '$post_price', status = '$post_status', pid = '$post_pid' WHERE sid = '$post_sid'");
						if ($update_service == TRUE) {
							$msg_type = "success";
							$msg_content = "<b>Berhasil:</b> Layanan Berhasil Diubah.<br /><b>ID Layanan Pusat:</b> $post_pid<br /><b>ID Layanan Provider:</b> $post_sid<br /><b><b>Ketegori:</b> $post_cat<br /><b>Nama Layanan:</b> $post_service<br /><b>Keterangan:</b> $post_note<br /><b>Minimal Pesan:</b> ".number_format($post_min,0,',','.')."<br /><b>Maksimal Pesan:</b> ".number_format($post_max,0,',','.')."<br /><b>Harga/1000:</b> Rp ".number_format($post_price,0,',','.')."<br /><b>Status:</b> $post_status<br /><b>Type:</b> $post_type";
						} else {
							$msg_type = "error";
							$msg_content = "<b>Gagal:</b> System Error.";
						}
					}
				}
				$checkdb_service = mysqli_query($db, "SELECT * FROM services WHERE sid = '$post_sid'");
				$datadb_service = mysqli_fetch_assoc($checkdb_service);
				include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-list text-primary"></i> Ubah Layanan</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">ID Layanan Pusat</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="pid" placeholder="ID Layanan Pusat" value="<?php echo $datadb_service['pid']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">ID Layanan Provider</label>
												<div class="col-md-10">
													<input type="number" class="form-control" placeholder="ID Layanan Provider" value="<?php echo $datadb_service['sid']; ?>" readonly>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Kategori</label>
												<div class="col-md-10">
													<select class="form-control" name="category">
														<option value="<?php echo $datadb_service['category']; ?>"><?php echo $datadb_service['category']; ?> (Terpilih)</option>
														<?php
														$check_cat = mysqli_query($db, "SELECT * FROM service_cat ORDER BY name ASC");
														while ($data_cat = mysqli_fetch_assoc($check_cat)) {
														?>
														<option value="<?php echo $data_cat['code']; ?>"><?php echo $data_cat['name']; ?></option>
														<?php
														}
														?>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Layanan</label>
												<div class="col-md-10">
													<input type="text" class="form-control" name="service" placeholder="Nama Layanan" value="<?php echo $datadb_service['service']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Keterangan</label>
												<div class="col-md-10">
													<input type="text" class="form-control" name="note" placeholder="Keterangan" value="<?php echo $datadb_service['note']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Min Pesan</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="min" placeholder="Minimal Pesan" value="<?php echo $datadb_service['min']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Max Pesan</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="max" placeholder="Maksimal Pesan" value="<?php echo $datadb_service['max']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Harga/1000</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="price" placeholder="Contoh: 30000" value="<?php echo $datadb_service['price']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Status</label>
												<div class="col-md-10">
													<select class="form-control" name="status">
														<option value="<?php echo $datadb_service['status']; ?>"><?php echo $datadb_service['status']; ?> (Terpilih)</option>
														<option value="Active">Aktif</option>
														<option value="Not active">Tidak Aktif</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/services" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="edit">Ubah</button>
											    </div>
										    </div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
				include("../../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."admin/news.php");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>