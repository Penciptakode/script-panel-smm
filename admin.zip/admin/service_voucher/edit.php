<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_GET['sid'])) {
			$post_sid = $_GET['sid'];
			$checkdb_service = mysqli_query($db, "SELECT * FROM services_voucher WHERE sid = '$post_sid'");
			$datadb_service = mysqli_fetch_assoc($checkdb_service);
			if (mysqli_num_rows($checkdb_service) == 0) {
				header("Location: ".$cfg_baseurl."admin/services_voucher.php");
			} else {
				if (isset($_POST['edit'])) {
					$post_sid = $db->real_escape_string(filter($_POST['sid']));
					$post_service = $db->real_escape_string(filter($_POST['service']));
					$post_oprator = $db->real_escape_string(filter($_POST['oprator']));
					$post_price = $db->real_escape_string(filter($_POST['price']));
					$post_status = $db->real_escape_string(filter($_POST['status']));
					if (empty($post_service) || empty($post_price) || empty($post_sid) || empty($post_oprator)) {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			        } else if ($data_user['level'] == "Member") {
			        	$msg_type = "error";
			        	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
					} else if ($post_status != "Active" AND $post_status != "Not Active") {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Input Tidak Sesuai.";
					} else {
						$update_service = mysqli_query($db, "UPDATE services_voucher SET oprator = '$post_oprator', service = '$post_name', price = '$post_price', sid = '$post_sid', status = '$post_status' WHERE id = '$post_id'");
						if ($update_service == TRUE) {
							$msg_type = "success";
							$msg_content = "<b>Berhasil:</b> Layanan Berhasil Diubah.<br /><b>ID Layanan Pusat:</b> $post_sid<br /><b>ID Layanan Provider:</b> $post_id<br /><b>Nama Layanan:</b> $post_name<br /><b>Kategori:</b> $post_oprator<br />Harga:</b> ".number_format($post_price,0,',','.')."<br /><b>Status:</b> $post_status";
						} else {
							$msg_type = "error";
							$msg_content = "<b>Gagal:</b> System Error.";
						}
					}
				}
				$checkdb_service = mysqli_query($db, "SELECT * FROM services_voucher WHERE sid = '$post_sid'");
				$datadb_service = mysqli_fetch_assoc($checkdb_service);
				include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-list text-primary"></i> Ubah Layanan</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">ID Layanan Pusat</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="sid" placeholder="ID Layanan Pusat" value="<?php echo $datadb_service['sid']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">ID Layanan Provider</label>
												<div class="col-md-10">
													<input type="number" class="form-control" placeholder="ID Layanan Provider" value="<?php echo $datadb_service['id']; ?>" readonly>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Layanan</label>
												<div class="col-md-10">
													<input type="text" class="form-control" name="service" placeholder="Nama Layanan" value="<?php echo $datadb_service['service']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Kategori</label>
												<div class="col-md-10">
													<select class="form-control" name="oprator">
														<option value="<?php echo $datadb_service['oprator']; ?>"><?php echo $datadb_service['oprator']; ?> (Terpilih)</option>
														<?php
														$check_cat = mysqli_query($db, "SELECT * FROM voucher_cat ORDER BY name ASC");
														while ($data_cat = mysqli_fetch_assoc($check_cat)) {
														?>
														<option value="<?php echo $data_cat['code']; ?>"><?php echo $data_cat['name']; ?></option>
														<?php
														}
														?>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Harga</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="price" placeholder="Contoh: 30000" value="<?php echo $datadb_service['price']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Status</label>
												<div class="col-md-10">
													<select class="form-control" name="status">
														<option value="<?php echo $datadb_service['status']; ?>"><?php echo $datadb_service['status']; ?> (Terpilih)</option>
														<option value="Active">Aktif</option>
														<option value="Not Active">Tidak Aktif</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/services_voucher" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="edit">Ubah</button>
											    </div>
										    </div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
				include("../../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."admin/services_voucher.php");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>