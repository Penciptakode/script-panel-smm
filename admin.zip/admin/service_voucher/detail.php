<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_GET['sid'])) {
			$post_sid = $_GET['sid'];
			$check_target = mysqli_query($db, "SELECT * FROM services_voucher WHERE sid = '$post_sid'");
			$data_target = mysqli_fetch_assoc($check_target);
			if (mysqli_num_rows($check_target) == 0) {
				header("Location: ".$cfg_baseurl."admin/services_voucher.php");
			} else {
				include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-list text-primary"></i> Detail Layanan</h4>
                                    </div>
                                    <div class="card-body">
										<div class="table-responsive">
											<table class="table table-striped table-bordered table-hover m-0">
												<tr>
													<th>ID Layanan Pusat</th>
													<td><?php echo $data_target['sid']; ?></td>
												</tr>
												<tr>
													<th>ID Layanan Provider</th>
													<td><?php echo $data_target['id']; ?></td>
												</tr>
												<tr>
													<th>Nama Layanan</th>
													<td><?php echo $data_target['service']; ?></td>
												</tr>
												<tr>
													<th>Kategori</th>
													<td><?php echo $data_target['oprator']; ?></td>
												</tr>
												<tr>
													<th>Harga</th>
													<td><?php echo number_format($data_target['price'],0,',','.'); ?></td>
												</tr>
												<tr>
													<th>Status</th>
													<td><?php echo $data_target['status']; ?></td>
												</tr>
											</table>
										</div>
										<br />
										<a href="<?php echo $cfg_baseurl; ?>admin/services_voucher.php" class="btn btn-primary m-t-20">Kembali Ke Daftar</a>
											    </div>
										    </div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
				include("../../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."admin/services_voucher.php");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>