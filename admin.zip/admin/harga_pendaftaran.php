<?php
session_start();
require("../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {

	include("../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-account-multiple-outline text-primary"></i> Daftar Harga Pendaftaran Akun</h4>
                                    </div>
                                    <div class="card-body">
										<div class="clearfix"></div>
										<br />
										<div class="col-md-12 table-responsive">
											<table id="datatable-responsive" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
														<th>Level</th>
														<th>Bonus Saldo</th>
														<th>Harga Pendaftaran</th>
														<th>Aksi</th>
													</tr>
												</thead>
												<tbody>
												<?php
// start paging config
$check_data = $db->query("SELECT * FROM harga_pendaftaran ORDER BY id DESC"); // edit

// end paging config	
												while ($data_show = mysqli_fetch_assoc($check_data)) {
												?>
													<tr>
														<td><?php echo $data_show['level']; ?></td>
														<td><?php echo $data_show['bonus']; ?></td>
														<td><?php echo $data_show['harga']; ?></td>
														<td align="center">
														<a href="<?php echo $cfg_baseurl; ?>admin/harga_pendaftaran/edit.php?id=<?php echo $data_show['id']; ?>" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
														</td>
													</tr>
												<?php
												}
												?>
												</tbody>
											</table>
										</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>