<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_POST['add'])) {
			$post_sid = $db->real_escape_string(filter($_POST['sid']));
			$post_name = $db->real_escape_string(filter($_POST['service']));
			$post_operator = $db->real_escape_string(filter($_POST['operator']));
			$post_price = $db->real_escape_string(filter($_POST['price']));
			$post_status = $db->real_escape_string(filter($_POST['status']));
			$post_provider = $db->real_escape_string(filter($_POST['provider']));
			$post_type = $db->real_escape_string(filter($_POST['type']));

			$checkdb_service = mysqli_query($db, "SELECT * FROM services_game WHERE sid = '$post_sid'");
			$datadb_service = mysqli_fetch_assoc($checkdb_service);

			if (empty($post_sid) || empty($post_name) || empty($post_operator) || empty($post_price) || empty($post_status) || empty($post_provider)) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
		    } else if ($data_user['level'] == "Member") {
			 	$msg_type = "error";
			 	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
			} else if (mysqli_num_rows($checkdb_service) > 0) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> ID Layanan Pusat: $post_sid Sudah Terdaftar Di Database.";
			} else {
				$insert_service = mysqli_query($db, "INSERT INTO services_game (sid, service, oprator, price, status, provider) VALUES ('$post_sid', '$post_name', '$post_operator', '$post_price', '$post_status', '$post_provider')");
				if ($insert_service == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Layanan Berhasil Ditambahkan.<br /><b>ID Layanan Pusat:</b> $post_sid<br /><b>Nama Layanan:</b> $post_name<br /><b>Operator:</b> $post_operator<br /><b>Harga:</b> ".number_format($post_price,0,',','.')."<br /><b>Status:</b> $post_status<br /><b>Kode Provider:</b> $post_provider<br /><b>Type Server:</b> $post_type";
				} else {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}

	include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-list text-primary"></i> Tambah Layanan</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">ID Layanan Pusat</label>
												<div class="col-md-10">
													<input type="number" name="sid" class="form-control" placeholder="ID Layanan Pusat">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Layanan</label>
												<div class="col-md-10">
													<input type="text" name="service" class="form-control" placeholder="Nama Layanan">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Operator</label>
												<div class="col-md-10">
													<input type="text" name="operator" class="form-control" placeholder="Contoh: TELKOMSEL">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Harga</label>
												<div class="col-md-10">
													<input type="number" name="price" class="form-control" placeholder="Contoh: 30000">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Status</label>
												<div class="col-md-10">
													<select class="form-control" name="status">
														<option value="0">Pilih Salah Satu...</option>
														<option value="Active">Aktif</option>
														<option value="Not Active">Tidak Aktif</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Kode Provider</label>
												<div class="col-md-10">
													<select class="form-control" name="provider">
													    <option value="0">Pilih Salah Satu...</option>
														<?php
														$check_prov = mysqli_query($db, "SELECT * FROM provider");
														while ($data_prov = mysqli_fetch_assoc($check_prov)) {
														?>
														<option value="<?php echo $data_prov['code']; ?>"><?php echo $data_prov['code']; ?></option>
														<?php
														}
														?>
													</select>
												</div>
											</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/services_game" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
											<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="add">Tambah</button>
											    </div>
										    </div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>