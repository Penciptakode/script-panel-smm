<?php
session_start();
require("../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_POST['delete'])) {
			$post_nama = $db->real_escape_string($_POST['nama']);
			$checkdb_staff = mysqli_query($db, "SELECT * FROM staff WHERE nama = '$post_nama'");
			if (mysqli_num_rows($checkdb_staff) == 0) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Nama Lengkap Staff Tidak Ditemukan.";
			} else if ($data_user['level'] == "Member") {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
			} else {
				$delete_staff = mysqli_query($db, "DELETE FROM staff WHERE nama = '$post_nama'");
				if ($delete_staff == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Nama Lengkap Staff: <b>$post_nama</b> Berhasil Dihapus.";
				}
			}
		}

	include("../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                        <div class="row">
                            <div class="col-md-12">
								<div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-users text-primary"></i> Kelola Staff</h4>
                                    </div>
                                    <div class="card-body">
										<div class="col-md-6">
											<a href="<?php echo $cfg_baseurl; ?>admin/staff/tambah" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah</a>
										</div>
										<div class="clearfix"></div>
										<br />
										<div class="col-md-12 table-responsive">
											<table id="datatable-responsive" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
														<th>No</th>
														<th>Nama Lengkap</th>
														<th>Level</th>
														<th>Email</th>
														<th>Facebook</th>
														<th>Whatsapps</th>
														<th>Instagram</th>
														<th>Link Facebook</th>
														<th>Link Instagram</th>
														<th>Tugas</th>
														<th>Aksi</th>
													</tr>
												</thead>
												<tbody>
												<?php
$check_info = $db->query("SELECT * FROM staff ORDER BY id DESC");
												$no = 1;
												while ($data_show = $check_info->fetch_assoc()) {
												?>
													<tr>
														<td><?php echo $no; ?></td>
														<td><?php echo $data_show['nama']; ?></td>
														<td><?php echo $data_show['level']; ?></td>
														<td><?php echo $data_show['email']; ?></td>
														<td><?php echo $data_show['facebook']; ?></td>
														<td><?php echo $data_show['wa']; ?></td>
														<td><?php echo $data_show['ig']; ?></td>
														<td><?php echo $data_show['link_fb']; ?></td>
														<td><?php echo $data_show['link_ig']; ?></td>
														<td><?php echo $data_show['tugas']; ?></td>
														<td align="center">
														<a href="<?php echo $cfg_baseurl; ?>admin/staff/edit.php?id=<?php echo $data_show['id']; ?>" class="btn btn-xs btn-warning"><i class="fa fa-edit"></i></a>
														<a href="<?php echo $cfg_baseurl; ?>admin/staff/delete.php?nama=<?php echo $data_show['nama']; ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
														</td>
													</tr>
												<?php
												$no++;
												}
												?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>