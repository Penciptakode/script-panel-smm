<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_POST['add'])) {
			$post_name = $db->real_escape_string(filter($_POST['name']));
			$post_penerima = $db->real_escape_string(filter($_POST['penerima']));
		    $post_provider = $db->real_escape_string(filter($_POST['provider']));
			$post_payment = $db->real_escape_string(filter($_POST['payment']));
			$post_rate = $db->real_escape_string(filter($_POST['rate']));
			$post_send = $db->real_escape_string(filter($_POST['send']));
			$post_minimal = $db->real_escape_string(filter($_POST['minimal']));
			$post_status = $db->real_escape_string(filter($_POST['status']));

			$checkdb_user = mysqli_query($db, "SELECT * FROM deposit_method WHERE nama = '$post_nama'");
			$datadb_user = mysqli_fetch_assoc($checkdb_user);
			if (empty($post_name) || empty($post_send)) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			} else if ($data_user['level'] == "Member") {
			    $msg_type = "error";
			 	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
			} else if (mysqli_num_rows($checkdb_user) > 0) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Nama Payment Deposit: $post_nama Sudah Terdaftar Dalam Database.";
			} else {
				$post_api = random(20);
				$insert_user = mysqli_query($db, "INSERT INTO deposit_method (provider, name, payment, rate, penerima, send, minimal, status) VALUES ('$post_provider', '$post_name', '$post_payment', '$post_rate', '$post_penerima', '$post_send', '$post_minimal', '$post_status')");
				if ($insert_user == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Metode Deposit Berhasil Ditambahkan.<br /><b>Tipe:</b> $post_name<br /><b>Nama Payment Deposit:</b> $post_payment $post_penerima<br /><b>Rate:</b> $post_rate<br /><b>Tujuan:</b> $post_send<br /><b>Minimal Deposit:</b> $post_minimal<br /><b>Status:</b> $post_status";
				} else {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}

	include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-credit-card text-primary"></i> Tambah Metode Deposit</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Tipe</label>
												<div class="col-md-10">
													<select class="form-control" name="name">
														<option value="0">Pilih Salah Satu...</option>
														<option value="Transfer Pulsa">Pulsa Transfer</option>
														<option value="Transfer Bank">Bank</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Provider</label>
												<div class="col-md-10">
													<input type="text" name="provider" class="form-control" placeholder="Provider">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Payment Deposit</label>
												<div class="col-md-10">
													<input type="text" name="payment" class="form-control" placeholder="Nama Payment Deposit">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Rate</label>
												<div class="col-md-10">
													<input type="text" name="rate" class="form-control" placeholder="Contoh: 1.00">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Tujuan</label>
												<div class="col-md-10">
													<input type="number" name="send" class="form-control" placeholder="Contoh: 6282136611003">
													<small class="text-danger">*Jika Metode Deposit BANK Wajib Masukan Nomor Rekening</span></small>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Penerima</label>
												<div class="col-md-10">
													<input type="text" name="penerima" class="form-control" placeholder="Contoh: A/N  Muhamad Syahrul Minanul Aziz">
													<small class="text-danger">*Jika Metode Deposit Transfer Pulsa Dikosongkan</span></small>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Minimal Deposit</label>
												<div class="col-md-10">
													<input type="number" name="minimal" class="form-control" placeholder="Contoh: 5000">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Status</label>
												<div class="col-md-10">
													<select class="form-control" name="status">
													    <option value="0">Pilih Salah Satu...</option>
													    <option value="ON">ON</option>
														<option value="OFF">OFF</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/metode_deposit.php" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="add">Tambah</button>
											    </div>
											</div>										
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>