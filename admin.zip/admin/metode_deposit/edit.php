<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_GET['id'])) {
			$post_id = $_GET['id'];
			$checkdb_user = mysqli_query($db, "SELECT * FROM deposit_method WHERE id = '$post_id'");
			$datadb_user = mysqli_fetch_assoc($checkdb_user);
			if (mysqli_num_rows($checkdb_user) == 0) {
				header("Location: ".$cfg_baseurl."admin/metode_deposit.php");
			} else {
				if (isset($_POST['edit'])) {
					$post_name = $db->real_escape_string(filter($_POST['name']));
					$post_penerima = $db->real_escape_string(filter($_POST['penerima']));
					$post_provider = $db->real_escape_string(filter($_POST['provider']));
					$post_payment = $db->real_escape_string(filter($_POST['payment']));
					$post_rate = $db->real_escape_string(filter($_POST['rate']));
					$post_send = $db->real_escape_string(filter($_POST['send']));
					$post_minimal = $db->real_escape_string(filter($_POST['minimal']));
					$post_status = $db->real_escape_string(filter($_POST['status']));
					if (empty($post_name) || empty($post_send)) {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			        } else if ($data_user['level'] == "Member") {
			        	$msg_type = "error";
			        	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
					} else {
						$update_service = mysqli_query($db, "UPDATE deposit_method SET name = '$post_name', penerima = '$post_penerima', provider = '$post_provider', payment = '$post_payment', rate = '$post_rate', send = '$post_send', minimal = '$post_minimal', status = '$post_status' WHERE id = '$post_id'");
						if ($update_service == TRUE) {
							$msg_type = "success";
							$msg_content = "<b>Berhasil:</b> Metode Deposit Berhasil Diubah.<br /><b>Tipe:</b> $post_name<br /><b>Provider:</b> $post_provider<br /><b>Nama Payment Deposit:</b> $post_payment $post_penerima<br /><b>Rate:</b> $post_rate<br /><b>Tujuan:</b> $post_send<br /><b>Minimal Deposit:</b> $post_minimal<br /><b>Status:</b> $post_status";
						} else {
							$msg_type = "error";
							$msg_content = "<b>Gagal:</b> System Error.";
						}
					}
				}
				$checkdb_user = mysqli_query($db, "SELECT * FROM deposit_method WHERE id = '$post_id'");
				$datadb_user = mysqli_fetch_assoc($checkdb_user);
				include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-credit-card text-primary"></i> Ubah Metode Deposit</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Tipe</label>
												<div class="col-md-10">
													<select class="form-control" name="name">
														<option value="<?php echo $datadb_user['name']; ?>"><?php echo $datadb_user['name']; ?> (Terpilih)</option>
														<option value="Transfer Pulsa">Transfer Pulsa</option>
														<option value="Transfer Bank">Transfer Bank</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Provider</label>
												<div class="col-md-10">
													<input type="text" name="provider" class="form-control" placeholder="Provider" value="<?php echo $datadb_user['provider']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Payment Deposit</label>
												<div class="col-md-10">
													<input type="text" name="payment" class="form-control" placeholder="Nama Payment Deposit" value="<?php echo $datadb_user['payment']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Rate</label>
												<div class="col-md-10">
													<input type="text" name="rate" class="form-control" placeholder="Contoh: 1.00" value="<?php echo $datadb_user['rate']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Tujuan</label>
												<div class="col-md-10">
													<input type="number" name="send" class="form-control" placeholder="Contoh: 6282136611003" value="<?php echo $datadb_user['send']; ?>">
													<small class="text-danger">*Jika Metode Deposit BANK Wajib Masukan Nomor Rekening</span></small>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Penerima</label>
												<div class="col-md-10">
													<input type="text" name="penerima" class="form-control" placeholder="Contoh: A/N  Muhamad Syahrul Minanul Aziz" value="<?php echo $datadb_user['penerima']; ?>">
													<small class="text-danger">*Jika Metode Deposit Transfer Pulsa Dikosongkan</span></small>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Minimal Deposit</label>
												<div class="col-md-10">
													<input type="number" name="minimal" class="form-control" placeholder="Contoh: 5000" value="<?php echo $datadb_user['minimal']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Status</label>
												<div class="col-md-10">
													<select class="form-control" name="status">
													    <option value="<?php echo $datadb_user['status']; ?>"><?php echo $datadb_user['status']; ?> (Terpilih)</option>
													    <option value="ON">ON</option>
														<option value="OFF">OFF</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/metode_deposit.php" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="edit">Ubah</button>
											    </div>
										    </div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
				include("../../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."admin/metode_deposit.php");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>