<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_GET['id'])) {
			$post_oid = $_GET['id'];
			$checkdb_order = mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE id = '$post_oid'");
			$datadb_order = mysqli_fetch_assoc($checkdb_order);
			if (mysqli_num_rows($checkdb_order) == 0) {
				header("Location: ".$cfg_baseurl."admin/harga_pendaftaran.php");
			} else {
				if (isset($_POST['edit'])) {
					$post_level = $db->real_escape_string(filter($_POST['level']));
					$post_bonus = $db->real_escape_string(filter($_POST['bonus']));
					$post_price = $db->real_escape_string(filter($_POST['harga']));
					if (empty($post_bonus) || empty($post_price)) {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			        } else if ($data_user['level'] == "Member") {
			        	$msg_type = "error";
			        	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
					} else {
						$update_order = mysqli_query($db, "UPDATE harga_pendaftaran SET level = '$post_level', bonus = '$post_bonus', harga = '$post_price' WHERE id = '$post_oid'");
						if ($update_order == TRUE) {
							$msg_type = "success";
							$msg_content = "<b>Berhasil:</b> Harga Pendaftaran Akun Berhasil Diubah.<br /><b>Level:</b> $post_level<br /><b>Harga Pendaftaran:</b> $post_bonus<br /><b>Fee Pendaftaran:</b> $post_price";
						} else {
							$msg_type = "error";
							$msg_content = "<b>Gagal:</b> System Error.";
						}
					}
				}
				$checkdb_order = mysqli_query($db, "SELECT * FROM harga_pendaftaran WHERE id = '$post_oid'");
				$datadb_order = mysqli_fetch_assoc($checkdb_order);
				include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-account-multiple-outline text-primary"></i> Ubah Harga Pendaftaran Akun</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Level</label>
												<div class="col-md-10">
													<select class="form-control" name="level">
														<option value="<?php echo $datadb_order['level']; ?>"><?php echo $datadb_order['level']; ?> (Terpilih)</option>
														<option value="Member">Member</option>
														<option value="Agen">Agen</option>
														<option value="Reseller">Reseller</option>
														<option value="Admin">Admin</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Bonus Saldo</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="bonus" placeholder="Bonus Saldo" value="<?php echo $datadb_order['bonus']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Harga Pendaftaran</label>
												<div class="col-md-10">
													<input type="number" class="form-control" name="harga" placeholder="Harga Pendaftaran" value="<?php echo $datadb_order['harga']; ?>">
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/harga_pendaftaran.php" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
											<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="edit">Ubah</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
				include("../../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."admin/harga_pendaftaran.php");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>