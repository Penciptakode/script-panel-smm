<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_POST['add'])) {
			$post_type = $db->real_escape_string(filter($_POST['type']));
			$post_title = $db->real_escape_string(filter($_POST['title']));
			$post_content = $db->real_escape_string(filter($_POST['content']));

			if (empty($post_content)) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			} else if ($data_user['level'] == "Member") {
			 	$msg_type = "error";
			 	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
			} else {
				$insert_news = mysqli_query($db, "INSERT INTO news (date, time, type, title, content) VALUES ('$date', '$time', '$post_type', '$post_title', '$post_content')");
				$update_news = mysqli_query($db, "UPDATE users SET read_news = '0'");
				if ($insert_news == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Berita Berhasil Ditambahkan.<br /><b>Tipe:</b> $post_type<br /><b>Judul:</b> $post_title <br /><b>Konten:</b> $post_content <br /><b>Tanggal & Waktu:</b> $date & $time";
				} else {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}

	include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-newspaper text-primary"></i> Tambah Berita</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Tipe</label>
												<div class="col-md-10">
													<select class="form-control" name="type">
														<option value="0">Pilih Salah Satu...</option>
														<option value="INFORMASI">INFORMASI</option>
														<option value="PERINGATAN">PERINGATAN</option>
														<option value="LAYANAN">LAYANAN</option>
														<option value="EVENT">EVENT</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Judul</label>
												<div class="col-md-10">
													<input type="text" name="title" class="form-control" placeholder="Judul">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Konten</label>
												<div class="col-md-10">
													<textarea name="content" class="form-control" placeholder="Konten"></textarea>
												</div>
											</div>
                                           <div class="form-group">
                                                <div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/news.php" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="add">Tambah</button>
											</div></div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>