<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_GET['id'])) {
			$post_id = $_GET['id'];
			$checkdb_news = mysqli_query($db, "SELECT * FROM news WHERE id = '$post_id'");
			$datadb_news = mysqli_fetch_assoc($checkdb_news);
			if (mysqli_num_rows($checkdb_news) == 0) {
				header("Location: ".$cfg_baseurl."admin/news.php");
			} else {
				if (isset($_POST['edit'])) {
					$post_type = $db->real_escape_string(filter($_POST['type']));
					$post_title = $db->real_escape_string(filter($_POST['title']));
					$post_content = $db->real_escape_string(filter($_POST['content']));
					if (empty($post_content)) {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			        } else if ($data_user['level'] == "Member") {
			        	$msg_type = "error";
			        	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
					} else {
						$update_news = mysqli_query($db, "UPDATE news SET content = '$post_content', title = '$post_title', type = '$post_type' WHERE id = '$post_id'");
						if ($update_news == TRUE) {
							$msg_type = "success";
							$msg_content = "<b>Berhasil:</b> Berita Berhasil Diubah.";
						} else {
							$msg_type = "error";
							$msg_content = "<b>Gagal:</b> System Error.";
						}
					}
				}
				$checkdb_news = mysqli_query($db, "SELECT * FROM news WHERE id = '$post_id'");
				$datadb_news = mysqli_fetch_assoc($checkdb_news);
				include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-newspaper text-primary"></i> Ubah Berita</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Tipe</label>
												<div class="col-md-10">
													<select class="form-control" name="type">
														<option value="<?php echo $datadb_news['type']; ?>"><?php echo $datadb_news['type']; ?> (Terpilih)</option>
														<option value="INFORMASI">INFORMASI</option>
														<option value="PERINGATAN">PERINGATAN</option>
														<option value="LAYANAN">LAYANAN</option>
														<option value="EVENT">EVENT</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Judul</label>
												<div class="col-md-10">
													<input type="text" name="title" class="form-control" placeholder="Judul" value="<?php echo $datadb_news['title']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Konten</label>
												<div class="col-md-10">
													<textarea name="content" class="form-control" placeholder="Konten"><?php echo $datadb_news['content']; ?></textarea>
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/news.php" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="edit">Ubah</button>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
						<!-- end row -->
<?php
				include("../../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."admin/news.php");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>