<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_GET['id'])) {
			$post_id = $_GET['id'];
			$checkdb_user = mysqli_query($db, "SELECT * FROM staff WHERE id = '$post_id'");
			$datadb_user = mysqli_fetch_assoc($checkdb_user);
			if (mysqli_num_rows($checkdb_user) == 0) {
				header("Location: ".$cfg_baseurl."admin/staff.php");
			} else {
				if (isset($_POST['edit'])) {
					$post_nama = $db->real_escape_string(filter($_POST['nama']));
					$post_email = $db->real_escape_string(filter($_POST['email']));
					$post_level = $db->real_escape_string(filter($_POST['level']));
					$post_fb = $db->real_escape_string(filter($_POST['facebook']));
					$post_ig = $db->real_escape_string(filter($_POST['ig']));
					$post_wa = $db->real_escape_string(filter($_POST['wa']));
					$post_lfb = $db->real_escape_string(filter($_POST['link_fb']));
					$post_lig = $db->real_escape_string(filter($_POST['link_ig']));
					$post_tgs = $db->real_escape_string(filter($_POST['tugas']));
					if (empty($post_nama) || empty($post_fb)) {
						$msg_type = "error";
						$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			        } else if ($data_user['level'] == "Member") {
			        	$msg_type = "error";
			        	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
					} else {
						$update_service = mysqli_query($db, "UPDATE staff SET nama = '$post_nama', facebook = '$post_fb', wa = '$post_wa', ig = '$post_ig', link_ig = '$post_lig', email = '$post_email', level = '$post_level', link_fb = '$post_lfb', tugas = '$post_tgs' WHERE id = '$post_id'");
						if ($update_service == TRUE) {
							$msg_type = "success";
							$msg_content = "<b>Berhasil:</b> Staff Berhasil Diedit.<br /><b>Nama Lengkap:</b> $post_nama<br /><b>E-Mail:</b> $post_email<br /><b>Level Akun:</b> $post_level<br /><b>Facebook:</b> $post_fb<br /><b>Instagram:</b> $post_ig<br /><b>WhatsApps:</b> $post_wa<br /><b>Link Profil Facebook:</b> $post_lfb<br /><b>Link Profil Instagram:</b> $post_lig<br /><b>Tugas:</b> $post_tgs";
						} else {
							$msg_type = "error";
							$msg_content = "<b>Gagal:</b> System Error.";
						}
					}
				}
				$checkdb_user = mysqli_query($db, "SELECT * FROM staff WHERE id = '$post_id'");
				$datadb_user = mysqli_fetch_assoc($checkdb_user);
				include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="fa fa-users text-primary"></i> Ubah Staff</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Lengkap</label>
												<div class="col-md-10">
													<input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" value="<?php echo $datadb_user['nama']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">E-Mail Aktif</label>
												<div class="col-md-10">
													<input type="email" name="email" class="form-control" placeholder="E-Mail" value="<?php echo $datadb_user['email']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Level Akun</label>
												<div class="col-md-10">
													<select class="form-control" name="level">
													    <option value="<?php echo $datadb_user['level']; ?>"><?php echo $datadb_user['level']; ?> (Terpilih)</option>
													    <option value="Developers">Developers</option>
														<option value="Member">Member</option>
														<option value="Admin">Admin</option>
														<option value="Agen">Agen</option>
														<option value="Reseller">Reseller</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Akun Facebook</label>
												<div class="col-md-10">
													<input type="text" name="facebook" class="form-control" placeholder="Facebook" value="<?php echo $datadb_user['facebook']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Akun Instagram</label>
												<div class="col-md-10">
													<input type="text" name="ig" class="form-control" placeholder="Instagram" value="<?php echo $datadb_user['ig']; ?>">
													<small class="text-danger">*Kosongkan Jika Tidak Punya Akun Instagram</span></small>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nomor WhatsApp</label>
												<div class="col-md-10">
													<input type="number" name="wa" class="form-control" placeholder="62" value="<?php echo $datadb_user['wa']; ?>">
													<small class="text-danger">*Nomor WhatsApp Wajib Di Awali 62 Bukan 0</span></small>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Link Profil Facebook</label>
												<div class="col-md-10">
													<input type="text" name="link_fb" class="form-control" placeholder="Link Profil Facebook" value="<?php echo $datadb_user['link_fb']; ?>">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Link Profil Instagram</label>
												<div class="col-md-10">
													<input type="text" name="link_ig" class="form-control" placeholder="Link Profil Instagram" value="<?php echo $datadb_user['link_ig']; ?>">
													<small class="text-danger">*Kosongkan Jika Tidak Punya Akun Instagram</span></small>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Tugas</label>
												<div class="col-md-10">
													<input type="text" name="tugas" class="form-control" placeholder="Tugas" value="<?php echo $datadb_user['tugas']; ?>">
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/staff.php" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="edit">Ubah</button>
											    </div>
										    </div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
				include("../../lib/footer.php");
			}
		} else {
			header("Location: ".$cfg_baseurl."admin/staff.php");
		}
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>