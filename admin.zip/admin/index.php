<?php
session_start();
require("../mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
	    
    include("../lib/header_admin.php");

// ===== Halaman Admin ===== //
//Total Saldo & Pengguna
$check_wuser = $db->query("SELECT SUM(balance) AS total FROM users");
$data_wuser = $check_wuser->fetch_assoc();
$check_wuser = $db->query("SELECT * FROM users");
$count_wuser = mysqli_num_rows($check_wuser);

//Total Pemesanan Sosial Media
$check_wsosmed = mysqli_query($db, "SELECT SUM(price) AS total FROM orders WHERE status = 'Success'");
$data_worder_sosmed = mysqli_fetch_assoc($check_wsosmed);
$check_wsosmed = mysqli_query($db, "SELECT * FROM orders WHERE status = 'Success'");
$count_worder_sosmed = mysqli_num_rows($check_wsosmed);

//Total Pemesanan Pulsa PPOB
$check_wpulsa = mysqli_query($db, "SELECT SUM(price) AS total FROM orders_pulsa WHERE status = 'Success'");
$data_worder_pulsa = mysqli_fetch_assoc($check_wpulsa);
$check_wpulsa = mysqli_query($db, "SELECT * FROM orders_pulsa WHERE status = 'Success'");
$count_worder_pulsa = mysqli_num_rows($check_wpulsa);

//Total Pemesanan Game
$check_wgame = mysqli_query($db, "SELECT SUM(price) AS total FROM orders_game WHERE status = 'Success'");
$data_worder_game = mysqli_fetch_assoc($check_wgame);
$check_wgame = mysqli_query($db, "SELECT * FROM orders_game WHERE status = 'Success'");
$count_worder_game = mysqli_num_rows($check_wgame);

//Total Pemesanan Voucher
$check_wvoucher = mysqli_query($db, "SELECT SUM(price) AS total FROM orders_voucher WHERE status = 'Success'");
$data_worder_voucher = mysqli_fetch_assoc($check_wvoucher);
$check_wvoucher = mysqli_query($db, "SELECT * FROM orders_voucher WHERE status = 'Success'");
$count_worder_voucher = mysqli_num_rows($check_wvoucher);

// Data Grafik Pesanan Sosial Media
$check_order_today = $db->query("SELECT * FROM orders WHERE date ='$date'");
    
$oneday_ago = date('Y-m-d', strtotime("-1 day"));
$check_order_oneday_ago = $db->query("SELECT * FROM orders WHERE date ='$oneday_ago'");
    
$twodays_ago = date('Y-m-d', strtotime("-2 day"));
$check_order_twodays_ago = $db->query("SELECT * FROM orders WHERE date ='$twodays_ago'");
    
$threedays_ago = date('Y-m-d', strtotime("-3 day"));
$check_order_threedays_ago = $db->query("SELECT * FROM orders WHERE date ='$threedays_ago'");
    
$fourdays_ago = date('Y-m-d', strtotime("-4 day"));
$check_order_fourdays_ago = $db->query("SELECT * FROM orders WHERE date ='$fourdays_ago'");
    
$fivedays_ago = date('Y-m-d', strtotime("-5 day"));
$check_order_fivedays_ago = $db->query("SELECT * FROM orders WHERE date ='$fivedays_ago'");
    
$sixdays_ago = date('Y-m-d', strtotime("-6 day"));
$check_order_sixdays_ago = $db->query("SELECT * FROM orders WHERE date ='$sixdays_ago'");
    
// Data Selesai
    
// Data Grafik Pesanan Pulsa PPOB
$check_order_pulsa_today = $db->query("SELECT * FROM orders_pulsa WHERE date ='$date'");
    
$oneday_ago = date('Y-m-d', strtotime("-1 day"));
$check_order_pulsa_oneday_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$oneday_ago'");
    
$twodays_ago = date('Y-m-d', strtotime("-2 day"));
$check_order_pulsa_twodays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$twodays_ago'");
    
$threedays_ago = date('Y-m-d', strtotime("-3 day"));
$check_order_pulsa_threedays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$threedays_ago'");
    
$fourdays_ago = date('Y-m-d', strtotime("-4 day"));
$check_order_pulsa_fourdays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$fourdays_ago'");
    
$fivedays_ago = date('Y-m-d', strtotime("-5 day"));
$check_order_pulsa_fivedays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$fivedays_ago'");
    
$sixdays_ago = date('Y-m-d', strtotime("-6 day"));
$check_order_pulsa_sixdays_ago = $db->query("SELECT * FROM orders_pulsa WHERE date ='$sixdays_ago'");
    
// Data Selesai

// Data Grafik Pesanan Game
$check_order_game_today = $db->query("SELECT * FROM orders_game WHERE date ='$date'");
    
$oneday_ago = date('Y-m-d', strtotime("-1 day"));
$check_order_game_oneday_ago = $db->query("SELECT * FROM orders_game WHERE date ='$oneday_ago'");
    
$twodays_ago = date('Y-m-d', strtotime("-2 day"));
$check_order_game_twodays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$twodays_ago'");
    
$threedays_ago = date('Y-m-d', strtotime("-3 day"));
$check_order_game_threedays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$threedays_ago'");
    
$fourdays_ago = date('Y-m-d', strtotime("-4 day"));
$check_order_game_fourdays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$fourdays_ago'");
    
$fivedays_ago = date('Y-m-d', strtotime("-5 day"));
$check_order_game_fivedays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$fivedays_ago'");
    
$sixdays_ago = date('Y-m-d', strtotime("-6 day"));
$check_order_game_sixdays_ago = $db->query("SELECT * FROM orders_game WHERE date ='$sixdays_ago'");
    
// Data Selesai

// Data Grafik Pesanan Voucher
$check_order_voucher_today = $db->query("SELECT * FROM orders_voucher WHERE date ='$date'");
    
$oneday_ago = date('Y-m-d', strtotime("-1 day"));
$check_order_voucher_oneday_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$oneday_ago'");
    
$twodays_ago = date('Y-m-d', strtotime("-2 day"));
$check_order_voucher_twodays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$twodays_ago'");
    
$threedays_ago = date('Y-m-d', strtotime("-3 day"));
$check_order_voucher_threedays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$threedays_ago'");
    
$fourdays_ago = date('Y-m-d', strtotime("-4 day"));
$check_order_voucher_fourdays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$fourdays_ago'");
    
$fivedays_ago = date('Y-m-d', strtotime("-5 day"));
$check_order_voucher_fivedays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$fivedays_ago'");
    
$sixdays_ago = date('Y-m-d', strtotime("-6 day"));
$check_order_voucher_sixdays_ago = $db->query("SELECT * FROM orders_voucher WHERE date ='$sixdays_ago'");
    
// Data Selesai
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
            <div class="row">
                <div class="col-md-12">
                    <div class="widget-rounded-circle card-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="avatar-lg rounded-circle bg-soft-success border-success border">
                                    <i class="mdi mdi-account-multiple-outline font-22 avatar-title text-success"></i>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-right">
                                    <h3 class="text-dark mt-1"><span data-plugin="">Rp. <?php echo number_format($data_wuser['total'],0,',','.'); ?> (Dari <?php echo number_format($count_wuser,0,',','.'); ?> Pengguna)</span></h3>
                                    <p class="text-muted mb-1 text-truncate">Total Saldo Seluruh Pengguna</p>
                                </div>
                            </div>
                        </div> <!-- end row-->
                    </div>
	            </div>
	            
            <div class="col-md-3">
                    <div class="widget-rounded-circle card-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="avatar-lg rounded-circle bg-soft-success border-success border">
                                    <i class="mdi mdi-instagram font-22 avatar-title text-success"></i>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-right">
                                    <h3 class="text-dark mt-1"><span data-plugin="">Rp. <?php echo number_format($data_worder_sosmed['total'],0,',','.'); ?> (Dari <?php echo number_format($count_worder_sosmed,0,',','.'); ?> Pesanan)</span></h3>
                                    <p class="text-muted mb-1 text-truncate">Pesanan Sosmed</p>
                                </div>
                            </div>
                        </div> <!-- end row-->
                    </div>
	            </div>
            <div class="col-md-3">
                    <div class="widget-rounded-circle card-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="avatar-lg rounded-circle bg-soft-success border-success border">
                                    <i class="mdi mdi-cellphone-iphone font-22 avatar-title text-success"></i>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="text-right">
                                    <h3 class="text-dark mt-1"><span data-plugin="">Rp. <?php echo number_format($data_worder_pulsa['total'],0,',','.'); ?> (Dari <?php echo number_format($count_worder_pulsa,0,',','.'); ?> Pesanan)</span></h3>
                                    <p class="text-muted mb-1 text-truncate">Pesanan Pulsa</p>
                                </div>
                            </div>
                        </div> <!-- end row-->
                    </div>
	            </div>
	       </div>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                    <div class="row">
                           <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header"> 
                                        <h4 class="header-title"><i class="far fa-chart-bar text-success"></i> Grafik Transaksi 7 Hari Terakhir</h4> 
                                    </div> 
                                    <div class="card-body">
        <div class="chart" id="line-chart" style="height: 325px;"></div>
        <script>
  $(function () {
    "use strict";

    // LINE CHART
    var line = new Morris.Line({
      element: 'line-chart',
      resize: true,
      data: [
        {y: '<?php echo $date; ?>', v: <?php echo mysqli_num_rows($check_order_today); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_today); ?>, x: <?php echo mysqli_num_rows($check_order_game_today); ?>},
        {y: '<?php echo $oneday_ago; ?>', v: <?php echo mysqli_num_rows($check_order_oneday_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_oneday_ago); ?>, x: <?php echo mysqli_num_rows($check_order_game_oneday_ago); ?>},
        {y: '<?php echo $twodays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_twodays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_twodays_ago); ?>, x: <?php echo mysqli_num_rows($check_order_game_twodays_ago); ?>},
        {y: '<?php echo $threedays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_threedays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_threedays_ago); ?>, x: <?php echo mysqli_num_rows($check_order_game_threedays_ago); ?>},
        {y: '<?php echo $fourdays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_fourdays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_fourdays_ago); ?>, x: <?php echo mysqli_num_rows($check_order_game_fourdays_ago); ?>},
        {y: '<?php echo $fivedays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_fivedays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_fivedays_ago); ?>, x: <?php echo mysqli_num_rows($check_order_game_fivedays_ago); ?>},
        {y: '<?php echo $sixdays_ago; ?>', v: <?php echo mysqli_num_rows($check_order_sixdays_ago); ?>, w: <?php echo mysqli_num_rows($check_order_pulsa_sixdays_ago); ?>, x: <?php echo mysqli_num_rows($check_order_game_sixdays_ago); ?>}
      ],
      xkey: 'y',
      ykeys: ['v','w','x'],
      labels: ['Pesanan Sosmed','Pesanan Pulsa PPOB','Pesanan Lainya'],
      lineColors: ['#f35864','#1576c2','#00CED1'],
      hideHover: 'auto'
    });
  });
</script>
                                        </div>
                                    </div>
                                </div>
                            </div>
						<!-- end row -->
<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>