<?php
session_start();
require("../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_POST['delete'])) {
			$post_nama = $db->real_escape_string($_POST['nama']);
			$checkdb_contact = mysqli_query($db, "SELECT * FROM contact WHERE nama = '$post_nama'");
			if (mysqli_num_rows($checkdb_contact) == 0) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Nama Lengkap Kontak Tidak Ditemukan.";
			} else {
				$delete_contact = mysqli_query($db, "DELETE FROM contact WHERE nama = '$post_nama'");
				if ($delete_contact == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Nama Lengkap Kontak: <b>$post_nama</b> Berhasil Dihapus.";
				}
			}
		}

	include("../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                        <div class="row">
                            <div class="col-md-12">
								<div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-account-circle text-primary"></i> Kelola Kontak</h4>
                                    </div>
                                    <div class="card-body">
										<div class="clearfix"></div>
										<br />
										<div class="col-md-12 table-responsive">
											<table id="datatable-responsive" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
														<th>No</th>
														<th>Nama Lengkap</th>
														<th>Whatsapps</th>
														<th>Facebook</th>
														<th>Instagram</th>
														<th>Link Facebook</th>
														<th>Link Instagram</th>
														<th>Link Grub WhatsApp</th>
														<th>Level</th>
														<th>Jam Kerja</th>
														<th>Deskripsi</th>
														<th>Lokasi</th>
														<th>Aksi</th>
													</tr>
												</thead>
												<tbody>
												<?php
$check_info = $db->query("SELECT * FROM contact ORDER BY id DESC");
												$no = 1;
												while ($data_show = $check_info->fetch_assoc()) {
												?>
													<tr>
														<td><?php echo $no; ?></td>
														<td><?php echo $data_show['nama']; ?></td>
														<td><?php echo $data_show['wa']; ?></td>
														<td><?php echo $data_show['fb']; ?></td>
														<td><?php echo $data_show['ig']; ?></td>
														<td><?php echo $data_show['link_fb']; ?></td>
														<td><?php echo $data_show['link_ig']; ?></td>
														<td><?php echo $data_show['link_grubwa']; ?></td>
														<td><?php echo $data_show['level']; ?></td>
														<td><?php echo $data_show['jam_kerja']; ?></td>
														<td><?php echo $data_show['deskripsi']; ?></td>
														<td><?php echo $data_show['lokasi']; ?></td>
														<td align="center">
														<a href="<?php echo $cfg_baseurl; ?>admin/contact/edit.php?id=<?php echo $data_show['id']; ?>" class="btn btn-xs btn-warning"><i class="fa fa-edit"></i></a>
														<a href="<?php echo $cfg_baseurl; ?>admin/contact/delete.php?nama=<?php echo $data_show['nama']; ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
														</td>
													</tr>
												<?php
												$no++;
												}
												?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>