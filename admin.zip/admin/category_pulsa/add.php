<?php
session_start();
require("../../mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['level'] != "Developers") {
		header("Location: ".$cfg_baseurl);
	} else {
		if (isset($_POST['add'])) {
		    $post_type = $db->real_escape_string(filter($_POST['type']));
			$post_code = $db->real_escape_string(filter($_POST['code']));
			$post_name = $db->real_escape_string(filter($_POST['name']));

			$checkdb_service = mysqli_query($db, "SELECT * FROM servicepulsa_cat WHERE code = '$post_code'");
			$datadb_service = mysqli_fetch_assoc($checkdb_service);
			if (empty($post_name) || empty($post_code) || empty($post_type)) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Mohon Mengisi Semua Input.";
			} else if ($data_user['level'] == "Member") {
			   	$msg_type = "error";
			 	$msg_content = "<b>Gagal:</b> Akun Member Tidak Memiliki Izin Untuk Mengakses Fitur Ini.";
			} else if (mysqli_num_rows($checkdb_service) > 0) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Kode Kategori: $post_code Sudah Terdaftar Di Database.";
			} else {
				$insert_service = mysqli_query($db, "INSERT INTO servicepulsa_cat (name, code, type) VALUES ('$post_name', '$post_code', '$post_type')");
				if ($insert_service == TRUE) {
					$msg_type = "success";
					$msg_content = "<b>Berhasil:</b> Kategori Berhasil Ditambahkan.<br /><b>Type:</b> $post_type<br /><b>Kode Kategori:</b> $post_name<br /><b>Nama Ketegori:</b> $post_code";
				} else {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> System Error.";
				}
			}
		}

	include("../../lib/header_admin.php");
?>
                <div class="row">
                    <div class="col-sm-12">
                    	<br/>
                    </div>
                </div>
                
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="header-title"><i class="mdi mdi-cards-outline text-primary"></i> Tambah Kategori</h4>
                                    </div>
                                    <div class="card-body">
										<?php 
										if ($msg_type == "success") {
										?>
										<div class="alert alert-success">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-check-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										} else if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Type</label>
												<div class="col-md-10">
												<select class="form-control" name="type">
													<option value="0">Pilih Salah Satu...</option>
                                                    <option value="Server 1">Server 1</option>
                                                    <option value="Server 2">Server 2</option>
													</select>
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Kode Kategori</label>
												<div class="col-md-10">
													<input type="text" name="code" class="form-control" placeholder="Kode Kategori">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Nama Kategori</label>
												<div class="col-md-10">
													<input type="text" name="name" class="form-control" placeholder="Nama Kategori">
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-offset-2 col-md-10">
											<a href="<?php echo $cfg_baseurl; ?>admin/kategori_pulsa" class="btn btn-warning waves-effect w-md waves-light">Kembali Ke Daftar</a>
												<button type="submit" class="btn btn-primary waves-effect w-md waves-light" name="add">Tambah</button>
											    </div>
										    </div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
<?php
	include("../../lib/footer.php");
	}
} else {
	header("Location: ".$cfg_baseurl);
}
?>