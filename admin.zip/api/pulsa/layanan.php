<?php
require("../../mainconfig.php");
header("Content-Type: application/json");

if (isset($_POST['api_key']) AND isset($_POST['action'])) {
	$post_key = $db->real_escape_string(trim(filter($_POST['api_key'])));
	$post_action = $_POST['action'];
	if (empty($post_key) || empty($post_action)) {
		$array = array("error" => "Permintaan Tidak Sesuai");
	} else {
		$check_user = mysqli_query($db, "SELECT * FROM users WHERE api_key = '$post_key'");
		$data_user = mysqli_fetch_assoc($check_user);
		if (mysqli_num_rows($check_user) == 1) {
			$username = $data_user['username'];
			if ($post_action == "layanan"){
			    //INI LAYANAN
			    $querys = mysqli_query($db, "SELECT * FROM services_pulsa WHERE status = 'Active' ORDER BY pid ASC");
		        $exe = mysqli_query($querys);
		
				while($row = mysqli_fetch_array($querys)){
				    $array = "-";
				    $datas[] = array('sid' => $row['sid'], 'type' => $row['type'], 'category' => $row['category'], 'service' => $row['service'], 'price' => $row['price'], 'status' => $row['status']);
                }
                $array = array("result" => $datas);
			} else {
				$array = array("error" => "Permintaan Salah");
			}
		} else {
			$array = array("error" => "API Key Salah");
		}
	}
} else {
	$array = array("error" => "Permintaan Tidak Sesuai");
}

$print = json_encode($array);
print_r($print);