<?php
require("../../mainconfig.php");
header("Content-Type: application/json");

if (isset($_POST['api_key']) AND isset($_POST['action'])) {
	$post_key = $db->real_escape_string(trim(filter($_POST['api_key'])));
	$post_action = $_POST['action'];
	if (empty($post_key) || empty($post_action)) {
		$array = array("error" => "Permintaan Tidak Sesuai");
	} else {
		$check_user = mysqli_query($db, "SELECT * FROM users WHERE api_key = '$post_key'");
		$data_user = mysqli_fetch_assoc($check_user);
		if (mysqli_num_rows($check_user) == 1) {
			$username = $data_user['username'];
			if ($post_action == "pemesanan") {
				if (isset($_POST['layanan']) AND isset($_POST['target'])) {
					$post_service = $db->real_escape_string(trim(filter($_POST['layanan'])));
					$post_data = $db->real_escape_string(trim(filter($_POST['target'])));
					if (empty($post_service) || empty($post_data)) {
						$array = array("error" => "Permintaan Tidak Sesuai");
					} else {
						$check_service = mysqli_query($db, "SELECT * FROM services_pulsa WHERE sid = '$post_service' AND status = 'Active'");
						$data_service = mysqli_fetch_assoc($check_service);
						
						$check_orders = mysqli_query($db, "SELECT * FROM orders_pulsa WHERE data = '$post_data' AND status = 'Pending'");
		                $data_orders = mysqli_fetch_assoc($check_orders);
		
						if (mysqli_num_rows($check_service) == 0) {
							$array = array("error" => "Layanan Tidak Tersedia");
						} else if (mysqli_num_rows($check_orders) == 1) {
							$array = array("error" => "Terdapat Pesanan Dengan Tujuan Yang Sama & Berstatus Pending");
						} else {
							$oid = random_number(7);
							$price = $data_service['price'];
							$service = $data_service['service'];
							$provider = $data_service['provider'];
							$pid = $data_service['sid'];
							if ($data_user['balance'] < $price) {
								$array = array("error" => "Saldo Tidak Mencukupi");
							} else {
								$check_provider = mysqli_query($db, "SELECT * FROM provider WHERE code = '$provider'");
								$data_provider = mysqli_fetch_assoc($check_provider);
								$provider_key = $data_provider['api_key'];
								$provider_link = $data_provider['link'];
	
								if ($provider == "MANUAL") {
									$api_postdata = "";
								} else if ($provider == "DP-PULSA") {
                                $api_postdata = "api_key=$provider_key&service=$pid&phone=$post_data";
                                
                                $ch = curl_init();
                                curl_setopt($ch, CURLOPT_URL, $provider_link);
                                curl_setopt($ch, CURLOPT_POST, 1);
                                curl_setopt($ch, CURLOPT_POSTFIELDS, $api_postdata);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                                $chresult = curl_exec($ch);
                                curl_close($ch);
                                $json_result = json_decode($chresult, true);
							    }
							    
			                    if ($provider == "DP-PULSA" AND $json_result['status'] == false) {
				                $array = array("error" => "Server Pusat Kami Sedang Mengalami Gangguan");
			                    } else {
									if ($provider == "DP-PULSA") {
										$poid = $json_result['data']['id'];
									}
			                        $check_top = mysqli_query($db, "SELECT * FROM top_users WHERE username = '$username'");
			                        $data_top = mysqli_fetch_assoc($check_top);	
									$update_user = mysqli_query($db, "UPDATE users SET balance = balance-$price WHERE username = '$username'");
									if ($update_user == TRUE) {
									    $insert_order = TRUE;
									    if (mysqli_num_rows($check_top) == 0) {
				                            $insert_order = mysqli_query($db, "INSERT INTO top_users (method, username, jumlah, total) VALUES ('Order', '$username', '$price', '1')");
				                        } else {
				                            $insert_order = mysqli_query($db, "UPDATE top_users SET jumlah = ".$data_top['jumlah']."+$price, total = ".$data_top['total']."+1 WHERE username = '$username' AND method = 'Order'");
				                        }			
				                        $insert_order = mysqli_query($db, "INSERT INTO balance_history (id, username, action, quantity, msg, date, time) VALUES ('', '$username', 'Cut Balance', '$price', 'Pemesanan Pulsa (VIA API) Dengan ID Pesanan : $oid', '$date', '$time')");
										$insert_order = mysqli_query($db, "INSERT INTO orders_pulsa (oid, poid, user, service, data, price, status, date, time, provider, place_from) VALUES ('$oid', '$poid', '$username', '$service', '$post_data', '$price', 'Pending', '$date', '$time', '$provider', 'API')");
										if ($insert_order == TRUE) {
											$array = array(
												"data" => array(
													"id" => "$oid",
											));
										} else {
											$array = array("error" => "System Error");
										}
									} else {
										$array = array("error" => "System Error");
									}
								}
							}
						}
					}
				
				} else {
					$array = array("error" => "Permintaan Tidak Sesuai");
				}
			} else {
				$array = array("error" => "Permintaan Salah");
			}
		} else {
			$array = array("error" => "API Key Salah");
		}
	}
} else {
	$array = array("error" => "Permintaan Tidak Sesuai");
}

$print = json_encode($array);
print_r($print);