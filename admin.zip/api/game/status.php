<?php
require("../../mainconfig.php");
header("Content-Type: application/json");

if (isset($_POST['api_key']) AND isset($_POST['action'])) {
	$post_key = $db->real_escape_string(trim(filter($_POST['api_key'])));
	$post_action = $_POST['action'];
	if (empty($post_key) || empty($post_action)) {
		$array = array("error" => "Permintaan Tidak Sesuai");
	} else {
		$check_user = mysqli_query($db, "SELECT * FROM users WHERE api_key = '$post_key'");
		$data_user = mysqli_fetch_assoc($check_user);
		if (mysqli_num_rows($check_user) == 1) {
			$username = $data_user['username'];
			if ($post_action == "status") {
				if (isset($_POST['id'])) {
					$post_oid = $_POST['id'];
					$post_oid = $_POST['id'];
					$check_order = mysqli_query($db, "SELECT * FROM orders_game WHERE oid = '$post_oid' AND user = '$username'");
					$data_order = mysqli_fetch_array($check_order);
					if (mysqli_num_rows($check_order) == 0) {
						$array = array("error" => "ID Pesanan Tidak Di Temukan");
					} else {
						$array = array(
							"data" => array(
								"target" => $data_order['data'], "status" => $data_order['status'], "catatan" => $data_order['catatan']
						));
					}
				} else {
					$array = array("error" => "Permintaan Tidak Sesuai");
				}
			} else {
				$array = array("error" => "Permintaan Salah");
			}
		} else {
			$array = array("error" => "API Key Salah");
		}
	}
} else {
	$array = array("error" => "Permintaan Tidak Sesuai");
}

$print = json_encode($array);
print_r($print);